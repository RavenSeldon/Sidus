C-end E1_relay mean 0.7702 sd 0.0031 | E2_calib_excess mean 0.0169 sd 0.0013 | E3_kappa_sens mean 0.5488 sd 0.0287 | E4_D11_agreement mean 0.0478 sd 0.0591
C-sup E1_relay mean 0.7942 sd 0.0013 | E2_calib_excess mean 0.0004 sd 0.0000 | E3_kappa_sens mean 0.0144 sd 0.0022 | E4_D11_agreement mean 0.9468 sd 0.0153
B0-am E1_relay mean 0.7872 sd 0.0052 | E2_calib_excess mean 0.0073 sd 0.0036 | E3_kappa_sens mean 1.9263 sd 0.0510 | E4_D11_agreement mean 0.6973 sd 0.1907
R-vec E1_relay mean 0.7672 sd 0.0018 | E2_calib_excess mean 0.0204 sd 0.0007 | E3_kappa_sens mean 1.2120 sd 0.0098 | E4_D11_agreement mean 0.0120 sd 0.0127
R-acc E1_relay mean 0.7463 sd 0.0020 | E2_calib_excess mean 0.0317 sd 0.0009 | E3_kappa_sens mean 0.7752 sd 0.0106 | E4_D11_agreement mean 0.0090 sd 0.0090
