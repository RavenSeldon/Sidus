# Sīdus E0-A — F1 pre-execution commitment

Frozen on 2026-09-06T21:04:29.169639+00:00, binding unchanged reviewed code v0.7 to FROZEN_CONFIG.json.

Freeze receipt SHA-256:

`5f8c2b3a32e61909c8c7b9e86972b2ed97e21a2a6246b3ce299b5bc7e7978deb`

Canonical config SHA-256:

`0678ffa97bba53813c0e3e81ec9472e9829a3501d0ca5f39847b7de90a95e1b0`

Original complete v0.7 archive SHA-256:

`d26a3fbeff7fbbd8dfdf2ba878fdb3dcc1bec37f0dffc2212e4637b878d93bed`

The 500 newly drawn seed identifiers have not been trained or evaluated during this preparation. The original 10000–10499 reservation is retired because the external review reports confirmation-kind training without identifying the seeds. No outcome-based selection was performed.

Retained decisions: tested R1; reviewed minimum effects and controls; all-seed replication guard; ≥.95 joint reliability target; two-sided familywise alpha=.05; 500 seeds; no restarts, replacements or optional extension. See DECISIONS.md for the statistical cost and limitations.

This record freezes a procedure, not a scientific conclusion. No E0-A, E1 or E0-B license is issued. Keep this commitment separately from future outcomes and use its receipt digest as the trusted input. A self-reported local timestamp alone is not external authentication. No confirmation run was started.
