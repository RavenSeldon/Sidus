# E0-B — Ledger E (corrections after the independent audit of the Final-State Report)

**8 October 2026 · the Final-State Report and its archive are preserved unchanged · this ledger records the audit's findings, the tests now executed, two further defects found while executing them, and the revised readiness**

All new values come from `e0b_ledgerE.py`, `e0b_ledgerE_s1e.py` and `e0b_assert.py`. All 17 automated assertions pass, including byte-identical deterministic re-runs. The environment is recorded in `ENVIRONMENT.txt` (Python 3.13.16, numpy 2.5.3, scipy 1.18.1).

---

## 1. Audit Findings — Verified

| Audit finding | Verified | Evidence |
|---|---|---|
| RR1e (matched transformations) not executed | ✔ | no RR1e code in `e0b_mb12.py` |
| P1c assigned `True` without an intervention | ✔ | the code returned a constant. My comment there ("no parameter-dependent encoding") was also **wrong in principle**: W6b breaks ties by training-identity order, which *is* label-dependent |
| P1d checked message sensitivity, not controlled substitution | ✔ | the code tested whether predictions vary across messages |
| P1b's 0.596178 is not an unconditional bound; 0.665140 if the decoder knows the held-out population | ✔ | E3: 0.596178 vs **0.665140** reproduced exactly |
| W5 reads the true mapping (oracle), so it shows feasibility, not trace-compliant validation | ✔ | E5 access audit: W3, W5, W6a, W6b, W7 and all B1 rivals use oracle access in the Shea/RR context |
| Power estimates approximate; small RR effects make Monte Carlo sample sizes fragile | ✔ | RR at k = 10: simulated μ 0.00143 vs exact 0.001998. Since N ∝ 1/μ², the reported 4,072 blocks would be about 2,090 with the exact μ |

## 2. Tests Now Executed

### E1 — RR1e matched transformations (mapping-oracle subproblem)

| Code | Linear without M | Linear with M | Gain |
|---|---|---|---|
| W1 regime code (θ-coupled) | 0.806250 | 0.825000 | **+0.018750** |
| same-target feature learner (Bayes feature for T from raw Z₁, Z₂ = parity) | 0.806250 | 0.825000 | **+0.018750** |
| W2 fixed parity | 0.806250 | 0.825000 | **+0.018750** |
| shuffled parity (matched support) | 0.806250 | 0.806250 | 0 |

**A matched transformation reproduces the entire accessibility gain.** The one clause that could separate redescription from feature engineering is RR1c, and it is non-identified (Report §4.4). This is exactly the case v2 §4.2 pre-registered: *bounded accessibility gain demonstrated; RR discrimination unresolved.*

### E2 — Process P1c (real relabelling intervention) and P1d (controlled substitution), k = 5

- **P1c.** All 24 relabellings of the training-identity order (which sets W6b's tie-breaking) and of the family labels used by W3 change **no** f(11) prediction; worst-case change mass 0. **P1c passes as an executed intervention.**
- **P1d.** The block (truth) is held fixed and the message is replaced by another block's message:

| Witness | Prediction follows SOURCE label | Follows HOST label |
|---|---|---|
| W3 process model | **0.596178** | 0.500000 |
| W6a per-cell tracker | 0.591577 | 0.500000 |
| W6b identity classifier | 0.564549 | 0.500000 |
| W5 token-φ | 0.517643 | 0.500000 |
| W1, W2 | 0.500000 | 0.500000 |

Predictions track the substituted content, not the host block. **P1d passes for W3 as a controlled causal substitution.** It does not discriminate on its own: every content-bearing code passes.

### E3 — P1b information contract

| Reference | Value | When it applies |
|---|---|---|
| (a) decoder **not** told the held-out population (full structured prior) | 0.596178 | **the registered P1b contract**: generalization to identities the decoder does not know are held out |
| (b) decoder told the held-out population is {((1,1),0), ((0,1),0)} | 0.665140 | an identity-informed upper bound; not the P1b contract |

The original figure is kept and relabelled with its contract. W3 attains (a) and stays below (b), as it should.

### E4 — Trace-compliant Shea witness (no oracle mapping access)

W5t computes φ from k-trace marginal-MAP estimates. Every clause was re-run with **contract-relative targets** (the correctness probability given the encoder's declared inputs), against rivals built from the same trace information.

| k | W5t token-φ (trace) | W1 regime | B1t-accept | B1t-invert | B1t-action-vector |
|---|---|---|---|---|---|
| 10 | **PASS all clauses** (relay 0.716503 > trace bound 0.706731; D11 55,296/55,296) | fail | fail | fail | fail (0.706731 = bound; D11 0/55,296) |
| 40 | **PASS all clauses** (relay 0.789530 > trace bound 0.763131; D11 55,296/55,296) | fail | fail | fail | fail (0.763131 = bound; D11 0/55,296) |

S1f is now tested on **genuinely endogenous** misrepresentation: the system's own inference errors (f̂ ≠ f) produce action-relevant misrepresentation of the oracle correctness probability, with mass 0.245 at k = 10 and 0.039 at k = 40.

Values at k = 40 use exact arithmetic on float-derived estimator probabilities, so rates such as 0.7499999999999777 should be read as 3/4.

### E5 — Strengthened access audit

Each witness is classified by mapping access:
- **trace-compliant:** W1, W2, B1-scalar, and every Process-context witness (posteriors from counts), plus W5t and the B1t rivals;
- **oracle feasibility only:** W3, W5, W6a, W6b, W7 and the B1 rivals in the Shea/RR context.

## 3. Two Further Defects Found While Executing the Corrections

1. **S1e (graded content, D10) was vacuous at its registered values.** In U1, every φ satisfies max(φ, 1 − φ) ≥ 0.7, so d′ ∈ {0.45, 0.65} never makes deferring optimal. An encoded policy bit therefore passes S1e as registered, and rival (iii) was never actually tested. With a policy-bit witness **W10** (M = optimal action at d = 0.55) and binding values d′ ∈ {0.75, 0.90}:

| Code | d′ = 0.75 (value / optimum) | d′ = 0.90 | Result |
|---|---|---|---|
| φ code, oracle | 0.850000 / 0.850000 | 0.926500 / 0.926500 | pass |
| W10 policy bit, oracle | 0.825000 / 0.850000 | 0.900000 / 0.926500 | **fail** |
| φ code, k = 40 trace | 0.814530 / 0.814530 | 0.914440 / 0.914440 | pass |
| W10 policy bit, k = 40 trace | 0.789530 / 0.814530 | 0.900000 / 0.914440 | **fail** |

**No earlier Shea verdict changes.** W10 would also fail S1a, since it isn't calibrated. But the registered d′ values must change to binding ones (proposed: {0.75, 0.90}; for D6/freeze), and W10 joins the witness register.

2. **The "holds by construction" claim for P1c** (§1) was wrong in principle. E2 now tests it empirically and finds no effect.

## 4. Revised Readiness

| Index | Status | Basis |
|---|---|---|
| **Shea** | `validated_operationalization` at exact scope for a **trace-compliant constructed** witness. This is the functional finding only, with S1e re-registered at binding d′ | W5t passes every clause at k = 10 and k = 40. Every trace-built rival fails for the named reason. The policy-bit rival is now tested and fails. **Still constructed, not learned**, and the correctness / correctness-contingent-value identity (Ledger D-II §3) still caps interpretation |
| **Process** | `validated_operationalization` at exact scope, under P1b contract (a) | P1c and P1d are now executed interventions. Witnesses are trace-based. Subject to D3 (separate held-out-input arm) and D4 (uniform criterion). The P1a separation from W6a stays weak (0.0046); P1b carries the structural discrimination |
| **RR** | **`inconclusive(non_identified)`**: *bounded accessibility gain demonstrated; RR discrimination unresolved* | RR1e shows matched transformations reproduce the full gain; RR1c is non-identified |
| **E0-B overall** | **Not complete** | D1–D6, independent learned pilot, MB0 freeze and conditional confirmation remain |

These statuses take on the auditor's conservative distinctions. The upgrades from the auditor's interim table rest **only** on tests executed in this round. For Shea, that is the trace-compliant witness the auditor named as the condition.

## 5. Recommendations on the Open Decisions (all remain Ben's)

- **D2 (RR1c).** I agree with the auditor: retain `inconclusive(non_identified)`. Adopt an alternative definition only if it is justified independently of the outcomes it produces. RR1e shows that even a permissive definition (option A) would leave RR unable to beat matched feature engineering on any clause except coupling.
- **D3.** Separate Process arm, balanced over three observed inputs, with the fourth held out.
- **D4.** The uniform exact-scope criterion, with P1b contract (a) as the registered reference.
- **D5.** Retain the functional Shea finding without asserting strict metarepresentation.
- **D6 (new item).** Re-register S1e at binding d′ (proposed {0.75, 0.90}). The other margins wait for pilot evidence.
- **D1.** The block budget stays open. Power planning should use the **exact** reference effects together with Monte Carlo variances; refine once B is fixed.

## 6. Provenance

New: `e0b_ledgerE.py` → `ledgerE_output.md`; `e0b_ledgerE_s1e.py` → `ledgerE_s1e_output.md`; `e0b_assert.py` → `assert_output.md`, `ENVIRONMENT.txt`. Archive v2 (`E0B_MB0-MB2_archive_v2.zip`) contains everything in v1 plus these files, with a fresh SHA-256 manifest. Archive v1 is retained unchanged.

*What remains is one decision round (D1–D6), the independent learned pilot, the freeze, and the conditional confirmation — the bounded programme the auditor described.*
