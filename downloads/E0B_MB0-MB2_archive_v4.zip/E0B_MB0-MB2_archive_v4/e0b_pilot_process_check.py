#!/usr/bin/env python3
"""Exact check (k=5) of the pilot's Process finding: on the six patterns the affine family can produce at the three
observed inputs, the LINEAR rule 'predict f(11)=1 iff fewer than two per-cell bits are 1' equals the parity
(structural) rule. So a per-cell tracker + linear readout implements the structure exactly; which linear decoder is
selected (0-1-loss optimum vs other admissible rules) decides P1b for W6a."""
from fractions import Fraction as F
from collections import defaultdict
from itertools import product
import e0b_mb12 as M
pats = {tuple(M.fval(wb, o) for o in M.OBS): M.fval(wb, (1, 1)) for wb in M.FAM}
print("allowed observed patterns -> f(11):", pats)
print("linear rule (sum <= 1) equals parity on every allowed pattern:", all((sum(p) <= 1) == bool(y) for p, y in pats.items()))
St = M.proc_states(5)
code = M.PROC['W6a per-cell tracker'][1]
def acc(S, rule):
    tot = sum(pr for pr, _, _ in S); return sum(pr * (rule(code(blk, tr)) == blk['y']) for pr, blk, tr in S) / tot
sumrule = lambda bits: int(sum(bits) <= 1)
Str = [x for x in St if x[1]['wb'] in M.TRAIN_IDS]; Sho = [x for x in St if x[1]['wb'] in M.HELDOUT_IDS]
print(f"W6a + 'sum<=1' linear readout: train {float(acc(Str, sumrule)):.6f}  held-out {float(acc(Sho, sumrule)):.6f}  (structured Bayes held-out 0.596178)")
fitted, rule = M.linear_acc(Sho, code, fit_on=Str)
print(f"W6a + train-0-1-optimal linear readout (Report X4): held-out {float(fitted):.6f}")
print(f"  its train accuracy: {float(acc(Str, lambda b: rule(M.enc(b)))):.6f}  vs 'sum<=1' train {float(acc(Str, sumrule)):.6f}")
