C-end 1 {'E1_relay': 0.769105, 'E2_calib_excess': 0.018075, 'E3_kappa_sens': 0.5724, 'E4_D11_agreement': 0.010323, 'E5_S1e_gap_0.75': 0.02158, 'E5_S1e_gap_0.8': 0.024058, 'ideal_relay': 0.796578} 13s
C-end 2 {'E1_relay': 0.763544, 'E2_calib_excess': 0.019962, 'E3_kappa_sens': 0.616465, 'E4_D11_agreement': 0.11984, 'E5_S1e_gap_0.75': 0.02441, 'E5_S1e_gap_0.8': 0.02583, 'ideal_relay': 0.794291} 11s
C-end 3 {'E1_relay': 0.769759, 'E2_calib_excess': 0.017094, 'E3_kappa_sens': 0.557015, 'E4_D11_agreement': 7.5e-05, 'E5_S1e_gap_0.75': 0.022487, 'E5_S1e_gap_0.8': 0.023922, 'ideal_relay': 0.794381} 12s
C-end 4 {'E1_relay': 0.770687, 'E2_calib_excess': 0.016452, 'E3_kappa_sens': 0.537544, 'E4_D11_agreement': 0.015495, 'E5_S1e_gap_0.75': 0.0228, 'E5_S1e_gap_0.8': 0.024822, 'ideal_relay': 0.79333} 11s
C-end 5 {'E1_relay': 0.775786, 'E2_calib_excess': 0.01539, 'E3_kappa_sens': 0.541877, 'E4_D11_agreement': 0.111384, 'E5_S1e_gap_0.75': 0.019645, 'E5_S1e_gap_0.8': 0.022404, 'ideal_relay': 0.795646} 11s
C-end 6 {'E1_relay': 0.772024, 'E2_calib_excess': 0.017088, 'E3_kappa_sens': 0.539804, 'E4_D11_agreement': 0.0003, 'E5_S1e_gap_0.75': 0.021993, 'E5_S1e_gap_0.8': 0.024826, 'ideal_relay': 0.797016} 11s
C-end 7 {'E1_relay': 0.770058, 'E2_calib_excess': 0.016116, 'E3_kappa_sens': 0.514047, 'E4_D11_agreement': 0.071903, 'E5_S1e_gap_0.75': 0.021102, 'E5_S1e_gap_0.8': 0.023284, 'ideal_relay': 0.793139} 12s
C-end 8 {'E1_relay': 0.769848, 'E2_calib_excess': 0.017123, 'E3_kappa_sens': 0.548381, 'E4_D11_agreement': 0.000446, 'E5_S1e_gap_0.75': 0.022677, 'E5_S1e_gap_0.8': 0.025398, 'ideal_relay': 0.793063} 12s
C-end 9 {'E1_relay': 0.768515, 'E2_calib_excess': 0.01646, 'E3_kappa_sens': 0.524204, 'E4_D11_agreement': 0.0, 'E5_S1e_gap_0.75': 0.021603, 'E5_S1e_gap_0.8': 0.023368, 'ideal_relay': 0.794171} 12s
C-end 10 {'E1_relay': 0.772369, 'E2_calib_excess': 0.015551, 'E3_kappa_sens': 0.536696, 'E4_D11_agreement': 0.148623, 'E5_S1e_gap_0.75': 0.02033, 'E5_S1e_gap_0.8': 0.022308, 'ideal_relay': 0.794497} 11s
C-sup 1 {'E1_relay': 0.796105, 'E2_calib_excess': 0.000502, 'E3_kappa_sens': 0.014077, 'E4_D11_agreement': 0.920503, 'E5_S1e_gap_0.75': 0.000347, 'E5_S1e_gap_0.8': 0.000846, 'ideal_relay': 0.796578} 9s
C-sup 2 {'E1_relay': 0.793908, 'E2_calib_excess': 0.000446, 'E3_kappa_sens': 0.013664, 'E4_D11_agreement': 0.943884, 'E5_S1e_gap_0.75': 0.000443, 'E5_S1e_gap_0.8': 0.000586, 'ideal_relay': 0.794291} 9s
C-sup 3 {'E1_relay': 0.794003, 'E2_calib_excess': 0.000386, 'E3_kappa_sens': 0.013719, 'E4_D11_agreement': 0.955769, 'E5_S1e_gap_0.75': 0.000465, 'E5_S1e_gap_0.8': 0.000286, 'ideal_relay': 0.794381} 9s
C-sup 4 {'E1_relay': 0.792895, 'E2_calib_excess': 0.000425, 'E3_kappa_sens': 0.0137, 'E4_D11_agreement': 0.967904, 'E5_S1e_gap_0.75': 0.000707, 'E5_S1e_gap_0.8': 0.000698, 'ideal_relay': 0.79333} 9s
C-sup 5 {'E1_relay': 0.795112, 'E2_calib_excess': 0.000488, 'E3_kappa_sens': 0.013525, 'E4_D11_agreement': 0.939949, 'E5_S1e_gap_0.75': 0.00041, 'E5_S1e_gap_0.8': 0.000686, 'ideal_relay': 0.795646} 9s
C-sup 6 {'E1_relay': 0.796377, 'E2_calib_excess': 0.000436, 'E3_kappa_sens': 0.012017, 'E4_D11_agreement': 0.931251, 'E5_S1e_gap_0.75': 0.000618, 'E5_S1e_gap_0.8': 0.000772, 'ideal_relay': 0.797016} 9s
C-sup 7 {'E1_relay': 0.792702, 'E2_calib_excess': 0.000443, 'E3_kappa_sens': 0.014119, 'E4_D11_agreement': 0.940715, 'E5_S1e_gap_0.75': 0.00068, 'E5_S1e_gap_0.8': 0.000612, 'ideal_relay': 0.793139} 9s
C-sup 8 {'E1_relay': 0.792909, 'E2_calib_excess': 0.000435, 'E3_kappa_sens': 0.016781, 'E4_D11_agreement': 0.959527, 'E5_S1e_gap_0.75': 0.000302, 'E5_S1e_gap_0.8': 0.000584, 'ideal_relay': 0.793063} 9s
C-sup 9 {'E1_relay': 0.794128, 'E2_calib_excess': 0.00042, 'E3_kappa_sens': 0.019633, 'E4_D11_agreement': 0.966349, 'E5_S1e_gap_0.75': 0.000758, 'E5_S1e_gap_0.8': 0.00058, 'ideal_relay': 0.794171} 9s
C-sup 10 {'E1_relay': 0.794265, 'E2_calib_excess': 0.000469, 'E3_kappa_sens': 0.013139, 'E4_D11_agreement': 0.942625, 'E5_S1e_gap_0.75': 0.000625, 'E5_S1e_gap_0.8': 0.00053, 'ideal_relay': 0.794497} 9s
R-vec 1 {'E1_relay': 0.769216, 'E2_calib_excess': 0.02012, 'E3_kappa_sens': 1.203135, 'E4_D11_agreement': 0.040313, 'E5_S1e_gap_0.75': 0.026748, 'E5_S1e_gap_0.8': 0.032388, 'ideal_relay': 0.796578} 9s
R-vec 2 {'E1_relay': 0.766636, 'E2_calib_excess': 0.021228, 'E3_kappa_sens': 1.228983, 'E4_D11_agreement': 0.010093, 'E5_S1e_gap_0.75': 0.02991, 'E5_S1e_gap_0.8': 0.033478, 'ideal_relay': 0.794291} 9s
R-vec 3 {'E1_relay': 0.767561, 'E2_calib_excess': 0.020473, 'E3_kappa_sens': 1.21508, 'E4_D11_agreement': 0.011337, 'E5_S1e_gap_0.75': 0.028537, 'E5_S1e_gap_0.8': 0.03213, 'ideal_relay': 0.794381} 9s
R-vec 4 {'E1_relay': 0.766867, 'E2_calib_excess': 0.019784, 'E3_kappa_sens': 1.208646, 'E4_D11_agreement': 0.006714, 'E5_S1e_gap_0.75': 0.029118, 'E5_S1e_gap_0.8': 0.03314, 'ideal_relay': 0.79333} 9s
R-vec 5 {'E1_relay': 0.769625, 'E2_calib_excess': 0.01971, 'E3_kappa_sens': 1.20932, 'E4_D11_agreement': 0.001639, 'E5_S1e_gap_0.75': 0.025927, 'E5_S1e_gap_0.8': 0.03223, 'ideal_relay': 0.795646} 9s
R-vec 6 {'E1_relay': 0.768398, 'E2_calib_excess': 0.021116, 'E3_kappa_sens': 1.218834, 'E4_D11_agreement': 0.009361, 'E5_S1e_gap_0.75': 0.02856, 'E5_S1e_gap_0.8': 0.033388, 'ideal_relay': 0.797016} 9s
R-vec 7 {'E1_relay': 0.764261, 'E2_calib_excess': 0.021221, 'E3_kappa_sens': 1.212336, 'E4_D11_agreement': 0.009035, 'E5_S1e_gap_0.75': 0.02867, 'E5_S1e_gap_0.8': 0.033322, 'ideal_relay': 0.793139} 9s
R-vec 8 {'E1_relay': 0.764447, 'E2_calib_excess': 0.020737, 'E3_kappa_sens': 1.222278, 'E4_D11_agreement': 0.002753, 'E5_S1e_gap_0.75': 0.027337, 'E5_S1e_gap_0.8': 0.032512, 'ideal_relay': 0.793063} 9s
R-vec 9 {'E1_relay': 0.767635, 'E2_calib_excess': 0.019404, 'E3_kappa_sens': 1.195361, 'E4_D11_agreement': 0.028365, 'E5_S1e_gap_0.75': 0.028728, 'E5_S1e_gap_0.8': 0.032616, 'ideal_relay': 0.794171} 9s
R-vec 10 {'E1_relay': 0.767489, 'E2_calib_excess': 0.01997, 'E3_kappa_sens': 1.20611, 'E4_D11_agreement': 7.5e-05, 'E5_S1e_gap_0.75': 0.027535, 'E5_S1e_gap_0.8': 0.031316, 'ideal_relay': 0.794497} 9s
R-acc 1 {'E1_relay': 0.74663, 'E2_calib_excess': 0.032138, 'E3_kappa_sens': 0.76928, 'E4_D11_agreement': 0.006556, 'E5_S1e_gap_0.75': 0.03924, 'E5_S1e_gap_0.8': 0.041526, 'ideal_relay': 0.796578} 9s
R-acc 2 {'E1_relay': 0.745698, 'E2_calib_excess': 0.032616, 'E3_kappa_sens': 0.78802, 'E4_D11_agreement': 0.014236, 'E5_S1e_gap_0.75': 0.040772, 'E5_S1e_gap_0.8': 0.04211, 'ideal_relay': 0.794291} 9s
R-acc 3 {'E1_relay': 0.74772, 'E2_calib_excess': 0.030657, 'E3_kappa_sens': 0.766931, 'E4_D11_agreement': 0.028716, 'E5_S1e_gap_0.75': 0.03785, 'E5_S1e_gap_0.8': 0.039262, 'ideal_relay': 0.794381} 9s
R-acc 4 {'E1_relay': 0.742888, 'E2_calib_excess': 0.032492, 'E3_kappa_sens': 0.785473, 'E4_D11_agreement': 0.000738, 'E5_S1e_gap_0.75': 0.041778, 'E5_S1e_gap_0.8': 0.041554, 'ideal_relay': 0.79333} 8s
R-acc 5 {'E1_relay': 0.749146, 'E2_calib_excess': 0.030978, 'E3_kappa_sens': 0.773595, 'E4_D11_agreement': 0.001416, 'E5_S1e_gap_0.75': 0.036953, 'E5_S1e_gap_0.8': 0.04126, 'ideal_relay': 0.795646} 9s
R-acc 6 {'E1_relay': 0.747751, 'E2_calib_excess': 0.032322, 'E3_kappa_sens': 0.774079, 'E4_D11_agreement': 0.001872, 'E5_S1e_gap_0.75': 0.039455, 'E5_S1e_gap_0.8': 0.041446, 'ideal_relay': 0.797016} 9s
R-acc 7 {'E1_relay': 0.74669, 'E2_calib_excess': 0.030568, 'E3_kappa_sens': 0.761749, 'E4_D11_agreement': 0.01568, 'E5_S1e_gap_0.75': 0.03875, 'E5_S1e_gap_0.8': 0.039626, 'ideal_relay': 0.793139} 9s
R-acc 8 {'E1_relay': 0.743308, 'E2_calib_excess': 0.032966, 'E3_kappa_sens': 0.793188, 'E4_D11_agreement': 7.4e-05, 'E5_S1e_gap_0.75': 0.040205, 'E5_S1e_gap_0.8': 0.042428, 'ideal_relay': 0.793063} 9s
R-acc 9 {'E1_relay': 0.747657, 'E2_calib_excess': 0.030867, 'E3_kappa_sens': 0.775961, 'E4_D11_agreement': 0.011689, 'E5_S1e_gap_0.75': 0.039403, 'E5_S1e_gap_0.8': 0.042526, 'ideal_relay': 0.794171} 9s
R-acc 10 {'E1_relay': 0.745696, 'E2_calib_excess': 0.031126, 'E3_kappa_sens': 0.76373, 'E4_D11_agreement': 0.008655, 'E5_S1e_gap_0.75': 0.038658, 'E5_S1e_gap_0.8': 0.041182, 'ideal_relay': 0.794497} 9s
B0-am 1 {'E1_relay': 0.78263, 'E2_calib_excess': 0.009983, 'E3_kappa_sens': 1.975514, 'E4_D11_agreement': 0.55881, 'E5_S1e_gap_0.75': 0.01762, 'E5_S1e_gap_0.8': 0.01539, 'ideal_relay': 0.796578} 22s
B0-am 2 {'E1_relay': 0.78056, 'E2_calib_excess': 0.011495, 'E3_kappa_sens': 1.936193, 'E4_D11_agreement': 0.464925, 'E5_S1e_gap_0.75': 0.01387, 'E5_S1e_gap_0.8': 0.013666, 'ideal_relay': 0.794291} 22s
B0-am 3 {'E1_relay': 0.79404, 'E2_calib_excess': 0.002043, 'E3_kappa_sens': 1.881664, 'E4_D11_agreement': 0.916654, 'E5_S1e_gap_0.75': 0.00109, 'E5_S1e_gap_0.8': 0.000886, 'ideal_relay': 0.794381} 23s
B0-am 4 {'E1_relay': 0.78728, 'E2_calib_excess': 0.008575, 'E3_kappa_sens': 1.980511, 'E4_D11_agreement': 0.774258, 'E5_S1e_gap_0.75': 0.012437, 'E5_S1e_gap_0.8': 0.012334, 'ideal_relay': 0.79333} 23s
B0-am 5 {'E1_relay': 0.78885, 'E2_calib_excess': 0.009074, 'E3_kappa_sens': 1.893968, 'E4_D11_agreement': 0.711199, 'E5_S1e_gap_0.75': 0.011618, 'E5_S1e_gap_0.8': 0.014476, 'ideal_relay': 0.795646} 22s
B0-am 6 {'E1_relay': 0.78115, 'E2_calib_excess': 0.011754, 'E3_kappa_sens': 1.87778, 'E4_D11_agreement': 0.358341, 'E5_S1e_gap_0.75': 0.015123, 'E5_S1e_gap_0.8': 0.016714, 'ideal_relay': 0.797016} 22s
B0-am 7 {'E1_relay': 0.78551, 'E2_calib_excess': 0.005414, 'E3_kappa_sens': 1.852958, 'E4_D11_agreement': 0.722536, 'E5_S1e_gap_0.75': 0.010567, 'E5_S1e_gap_0.8': 0.010848, 'ideal_relay': 0.793139} 23s
B0-am 8 {'E1_relay': 0.78444, 'E2_calib_excess': 0.008405, 'E3_kappa_sens': 1.92725, 'E4_D11_agreement': 0.664335, 'E5_S1e_gap_0.75': 0.010855, 'E5_S1e_gap_0.8': 0.010948, 'ideal_relay': 0.793063} 22s
B0-am 9 {'E1_relay': 0.79338, 'E2_calib_excess': 0.003442, 'E3_kappa_sens': 2.010947, 'E4_D11_agreement': 0.914796, 'E5_S1e_gap_0.75': 0.003175, 'E5_S1e_gap_0.8': 0.002976, 'ideal_relay': 0.794171} 22s
B0-am 10 {'E1_relay': 0.79409, 'E2_calib_excess': 0.003104, 'E3_kappa_sens': 1.926382, 'E4_D11_agreement': 0.887233, 'E5_S1e_gap_0.75': 0.013338, 'E5_S1e_gap_0.8': 0.003544, 'ideal_relay': 0.794497} 23s
P-struct 1 0.43401
P-struct 2 0.413222
P-struct 3 0.434127
P-struct 4 0.415363
P-struct 5 0.428507
P-struct 6 0.430605
P-struct 7 0.429038
P-struct 8 0.421897
P-struct 9 0.43572
P-struct 10 0.43425
P-cell-lin 1 0.66288
P-cell-lin 2 0.663595
P-cell-lin 3 0.66288
P-cell-lin 4 0.663427
P-cell-lin 5 0.663427
P-cell-lin 6 0.663427
P-cell-lin 7 0.66288
P-cell-lin 8 0.662713
P-cell-lin 9 0.663427
P-cell-lin 10 0.663427
P-cell-mlp 1 0.34992
P-cell-mlp 2 0.355073
P-cell-mlp 3 0.350635
P-cell-mlp 4 0.35524
P-cell-mlp 5 0.360613
P-cell-mlp 6 0.35524
P-cell-mlp 7 0.355073
P-cell-mlp 8 0.355237
P-cell-mlp 9 0.354592
P-cell-mlp 10 0.355073
identity-blind Bayes (held-out, MC): 0.704139
