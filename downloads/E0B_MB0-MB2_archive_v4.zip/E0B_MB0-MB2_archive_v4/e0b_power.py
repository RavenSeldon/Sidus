#!/usr/bin/env python3
"""E0-B power analysis as a function of the block budget (input to Ben's choice of B; no B is chosen here).

Design (approved defaults): per block, B_trace = 4k balanced inference trials, then B_score scored trials, mapping
estimate frozen before scoring. Units: blocks are independent; trials within a block share the mapping estimate.

Reference (ideal-system) contrasts — the best case a learned system could approach; learned gaps only add variance:
  Shea  S1h : per scored trial, relay payoff (phi code) minus relay payoff (Bayes-optimal B1-action-vector rival),
              same trial, same kappas; marginal-MAP trace estimator (hard-MAP reference condition).
  RR    RR1b: per scored trial, frozen linear consumer with the parity feature minus without (kappa-free, relay payoff),
              consumer conditioned on (o, fhat).
  Proc  P1a : per block, 1[structured Bayes prediction of f(11) correct] - 1/2 (prior-optimal), traces at the three
              observed inputs only (k_p per input).
Method: Monte Carlo estimate of block-level mean mu, between-block variance sb2 and within-block variance sw2
(float64, fixed seeds); then power for a one-sided z-test on block means with N blocks:
  power = Phi( (mu - margin) / sqrt((sb2 + sw2 / B_score) / N) - z_{1-alpha} ).
A direct-simulation check of one design point validates the normal approximation.
"""
import numpy as np
from math import erf, sqrt
from fractions import Fraction as F
from itertools import product
import e0b_contracts as C
import e0b_mb0 as M0

Dd = float(C.D); OSL = C.OS; FAM = C.FAM
pS = float(C.pS1)
TAB = np.array([[C.fval(wb, o) for o in OSL] for wb in FAM])          # 6 x 4 truth tables
def Phi(x): return 0.5 * (1 + erf(x / sqrt(2)))
ZQ = {0.05: 1.6448536269514722, 0.05 / 3: 2.1280452788}

def phi_table(k):
    """ideal encoder phi(o, r, T, fhat) under marginal-MAP traces with k per input (exact, from e0b_mb0)."""
    mb = C.map_bit_dist(k) if k <= 10 else C.map_bit_dist_float(k)
    S = list(M0.states_with(mb)); enc = C.encode(S, 'L', ['o', 'r', 'T', 'fhat'])
    tab = {}
    for _, s in S: tab[(OSL.index(s['o']), s['r'], s['T'], s['fhat'])] = float(enc(s))
    atoms = M0.atoms_from(S)
    A = np.array([[r, float(f), float(m), float(c)] for (r, f), (m, c) in atoms.items()])
    return tab, A

def rival_action(qa, qi, r, A):
    """Bayes-optimal relay action given the action-value vector (qa, qi) and R, using live atoms (vectorised)."""
    live = (A[None, :, 0] == r[:, None]) & (A[None, :, 1] <= qa[:, None]) & (qa[:, None] <= A[None, :, 1] + 1) \
           & (1 - A[None, :, 1] <= qi[:, None]) & (qi[:, None] <= 2 - A[None, :, 1])
    m = (live * A[None, :, 2]).sum(1); c = (live * A[None, :, 3]).sum(1)
    return np.argmax(np.stack([c, m - c, Dd * m], 1), 1)

def act_of(phi):
    return np.argmax(np.stack([phi, 1 - phi, np.full_like(phi, Dd)], 1), 1)

def simulate_blocks(k, n_blocks, b_score, rng, phitab, A, rrpol):
    wbi = rng.integers(0, 6, n_blocks)
    # traces: k per input; R=1 count at input o ~ Bin(k, pS if f=0 else 1-pS)
    f = TAB[wbi]                                                   # n x 4
    cnt = rng.binomial(k, np.where(f == 0, pS, 1 - pS))
    # marginal MAP of each f(o) under the structured (6-mapping) posterior given all four inputs' counts — the same
    # estimator as e0b_contracts.map_bit_dist, so the exact phi table is calibrated for it; ties broken at random
    ll = np.zeros((n_blocks, 6))
    for v in range(6):
        fv = TAB[v]
        ll[:, v] = np.where(fv == 0, cnt * np.log(pS) + (k - cnt) * np.log(1 - pS), cnt * np.log(1 - pS) + (k - cnt) * np.log(pS)).sum(1)
    post = np.exp(ll - ll.max(1, keepdims=True)); post /= post.sum(1, keepdims=True)
    m1 = post @ TAB                                                 # n x 4: P(f(o)=1 | counts)
    fhat = np.where(m1 > 0.5 + 1e-12, 1, np.where(m1 < 0.5 - 1e-12, 0, rng.integers(0, 2, m1.shape)))
    # scored trials
    n = n_blocks * b_score
    bi = np.repeat(np.arange(n_blocks), b_score)
    x = (rng.random(n) < float(C.P_X)).astype(int); z1 = rng.integers(0, 2, n); z2 = rng.integers(0, 2, n)
    T = z1 ^ z2; q = np.where(T == 0, float(C.QH), float(C.QL)); nn = (rng.random(n) >= q).astype(int)
    o = rng.integers(0, 4, n); fo = f[bi, o]; r = x ^ nn ^ fo; L = (r == x).astype(float)
    fh = fhat[bi, o]
    phi = np.array([phitab[(oo, rr, tt, ff)] for oo, rr, tt, ff in zip(o, r, T, fh)])
    pay = lambda a: np.where(a == 0, L, np.where(a == 1, 1 - L, Dd))
    ka = rng.random(n); ki = rng.random(n)
    d_shea = pay(act_of(phi)) - pay(rival_action(phi + ka, 1 - phi + ki, r, A))
    a_with = np.array([rrpol['with'][(oo, ff)][(rr, a1, a2)] for oo, ff, rr, a1, a2 in zip(o, fh, r, z1, z2)])
    a_wout = np.array([rrpol['without'][(oo, ff)][(rr, a1, a2)] for oo, ff, rr, a1, a2 in zip(o, fh, r, z1, z2)])
    d_rr = pay(a_with) - pay(a_wout)
    return bi, d_shea, d_rr

def rr_policies(k):
    """best linear-argmax policies with / without the parity feature, per (o, fhat), under k-trace marginal MAP."""
    import e0b_mb12 as M12
    mb = C.map_bit_dist(k) if k <= 10 else C.map_bit_dist_float(k)
    tabs = {}
    for pr, s in M0.states_with(mb):
        key = (OSL.index(s['o']), s['fhat']); cl = (s['r'], s['z1'], s['z2'])
        a = tabs.setdefault(key, {c: [F(0), F(0), None] for c in M12.CELLS})[cl]; a[0] += pr; a[1] += pr * s['L']; a[2] = s['z1'] ^ s['z2']
    out = {'with': {}, 'without': {}}
    for key, tab in tabs.items():
        for nm, use in (('with', True), ('without', False)):
            _, Wt = M12.best_linear(tab, use)
            out[nm][key] = {cl: M12.apply_w(Wt, list(cl) + ([float(tab[cl][2])] if use else [])) for cl in M12.CELLS}
    return out

def process_moments(kp, n_blocks, rng):
    wbi = rng.integers(0, 6, n_blocks); f = TAB[wbi]
    obs = [0, 1, 2]                                                 # inputs 00, 01, 10 (OS order); query index 3 = 11
    cnt = rng.binomial(kp, np.where(f[:, obs] == 0, pS, 1 - pS))
    ll = np.zeros((n_blocks, 6))
    for v in range(6):
        fv = TAB[v, obs]
        ll[:, v] = (np.where(fv == 0, cnt * np.log(pS) + (kp - cnt) * np.log(1 - pS),
                             cnt * np.log(1 - pS) + (kp - cnt) * np.log(pS))).sum(1)
    post = np.exp(ll - ll.max(1, keepdims=True)); post /= post.sum(1, keepdims=True)
    p11 = post @ TAB[:, 3]
    pred = np.where(p11 > 0.5, 1, np.where(p11 < 0.5, 0, rng.integers(0, 2, n_blocks)))
    return (pred == f[:, 3]).astype(float) - 0.5

def moments(bi, d, n_blocks):
    bm = np.bincount(bi, weights=d, minlength=n_blocks) / np.bincount(bi, minlength=n_blocks)
    resid = d - bm[bi]; b = np.bincount(bi, minlength=n_blocks)[0]
    sw2 = (resid ** 2).sum() / (len(d) - n_blocks)
    sb2 = max(bm.var(ddof=1) - sw2 / b, 0.0)
    return d.mean(), sb2, sw2

def n_required(mu, sb2, sw2, b_score, margin, alpha=0.05, power=0.8):
    eff = mu - margin
    if eff <= 0: return float('inf')
    zb = 0.8416212335729143
    return int(np.ceil(((ZQ[alpha] + zb) ** 2) * (sb2 + sw2 / b_score) / eff ** 2))

if __name__ == '__main__':
    rng = np.random.default_rng(20261008)
    print("# E0-B power analysis (reference contrasts; float64 Monte Carlo moments + normal approximation)\n")
    print("Consistency check: simulated per-trial means vs exact reference gaps are printed below each k.\n")
    print("Blocks needed for power 0.80, one-sided; alpha 0.05 (and 0.05/3 Holm-conservative); margin = 0 or half the reference effect.\n")
    print("| index | k per input | mu (per trial / block) | sb2 | sw2 | B_score | N blocks, margin 0 | N blocks, margin mu/2 | N at alpha/3, margin mu/2 |")
    print("|---|---|---|---|---|---|---|---|---|")
    for k in (10, 20, 40):
        phitab, A = phi_table(k); pol = rr_policies(k)
        nb, bs = 4000, 50
        bi, ds, dr = simulate_blocks(k, nb, bs, rng, phitab, A, pol)
        Ax = M0.atoms_from(M0.states_with(C.map_bit_dist(k) if k <= 10 else C.map_bit_dist_float(k)))
        ex_shea = float(M0.relay_phi(Ax) - M0.relay_rival(Ax, 'vector'))
        print(f"| (check k={k}) | exact Shea gap {ex_shea:.5f} vs simulated {ds.mean():.5f} | | | | | | | |")
        for nm, d in (('Shea S1h', ds), ('RR RR1b', dr)):
            mu, sb2, sw2 = moments(bi, d, nb)
            for b_score in (20, 50, 100, 200):
                print(f"| {nm} | {k} | {mu:.5f} | {sb2:.2e} | {sw2:.4f} | {b_score} | {n_required(mu, sb2, sw2, b_score, 0)} | "
                      f"{n_required(mu, sb2, sw2, b_score, mu / 2)} | {n_required(mu, sb2, sw2, b_score, mu / 2, 0.05 / 3)} |")
    for kp in (10, 20, 40):
        d = process_moments(kp, 200000, rng); mu, var = d.mean(), d.var(ddof=1)
        need = lambda margin, a=0.05: int(np.ceil(((ZQ[a] + 0.8416212335729143) ** 2) * var / (mu - margin) ** 2))
        print(f"| Process P1a | {kp} (3 inputs) | {mu:.5f} | {var:.4f} (block) | - | - | {need(0)} | {need(mu / 2)} | {need(mu / 2, 0.05 / 3)} |")
    # validation of the normal approximation at one design point (Shea, k=40, B_score=50, N=need at margin 0)
    k = 40; phitab, A = phi_table(k); pol = rr_policies(k)
    bi, ds, _ = simulate_blocks(k, 4000, 50, rng, phitab, A, pol); mu, sb2, sw2 = moments(bi, ds, 4000)
    N = n_required(mu, sb2, sw2, 50, 0); hits = 0; reps = 300
    for rep in range(reps):
        bi2, d2, _ = simulate_blocks(k, N, 50, rng, phitab, A, pol)
        bm = np.bincount(bi2, weights=d2) / 50
        z = bm.mean() / (bm.std(ddof=1) / np.sqrt(N)); hits += z > ZQ[0.05]
    print(f"\nValidation: Shea, k=40, B_score=50, N={N} blocks -> simulated power {hits / reps:.3f} over {reps} replications (target 0.80; t-statistic on block means).")
