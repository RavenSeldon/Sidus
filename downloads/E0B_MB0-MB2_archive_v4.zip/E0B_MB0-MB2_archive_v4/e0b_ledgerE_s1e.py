#!/usr/bin/env python3
"""Ledger E supplement — S1e (graded content, D10) was VACUOUS at d' in {0.45, 0.65}: in U1 every phi satisfies
max(phi, 1-phi) >= 0.7, so neither d' ever makes deferral optimal and an encoded policy bit is indistinguishable
from graded content. This script (i) demonstrates the vacuity, (ii) adds the policy-bit witness W10 (M = optimal
action at d = 0.55), and (iii) re-runs S1e at binding values d' in {0.75, 0.90} for W5 / W5t, W10 and W1.
Exact arithmetic (trace distributions float-derived for k > 10)."""
from fractions import Fraction as F
from collections import defaultdict
import e0b_contracts as C
import e0b_mb12 as M
import e0b_ledgerE as E
D = C.D
def s1e(S, code, target, dps):
    g = defaultdict(lambda: [F(0), F(0)])
    for pr, s in S: a = g[(code(s), s['r'])]; a[0] += pr; a[1] += pr * s['L']
    rows = []
    for dp in dps:
        v = sum(max(c, m - c, dp * m) for m, c in g.values()); o = sum(pr * max(target(s), 1 - target(s), dp) for pr, s in S)
        rows.append((dp, v, o))
    return rows
for tag, S, target in (('oracle', M.world(), lambda s: M.phi_cf(s['r'], s['o'], s['T'], s['f'], C.P_X)),
                       ('k=40 trace', E.trace_world(40), None)):
    if target is None:
        enc = C.encode(S, 'L', ['o', 'r', 'T', 'fhat']); target = lambda s, enc=enc: enc(s)
    mins = min(max(target(s), 1 - target(s)) for _, s in S)
    print(f"\n[{tag}] min over states of max(phi, 1-phi) = {float(mins):.4f}  -> any d' below this never binds")
    codes = {'phi code (W5 / W5t)': target,
             'W10 policy bit act(phi) at d=0.55': lambda s: M.act(target(s)),
             'W1 regime code': lambda s: s['T']}
    for nm, code in codes.items():
        rows = s1e(S, code, target, (F(45, 100), F(65, 100), F(75, 100), F(90, 100)))
        txt = '; '.join(f"d'={float(dp):.2f}: {float(v):.6f}/{float(o):.6f}{' ok' if v == o else ' NOT MET'}" for dp, v, o in rows)
        print(f"- {nm}: {txt}")
