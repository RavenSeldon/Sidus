
[oracle] min over states of max(phi, 1-phi) = 0.7000  -> any d' below this never binds
- phi code (W5 / W5t): d'=0.45: 0.825000/0.825000 ok; d'=0.65: 0.825000/0.825000 ok; d'=0.75: 0.850000/0.850000 ok; d'=0.90: 0.926500/0.926500 ok
- W10 policy bit act(phi) at d=0.55: d'=0.45: 0.825000/0.825000 ok; d'=0.65: 0.825000/0.825000 ok; d'=0.75: 0.825000/0.850000 NOT MET; d'=0.90: 0.900000/0.926500 NOT MET
- W1 regime code: d'=0.45: 0.700000/0.825000 NOT MET; d'=0.65: 0.700000/0.825000 NOT MET; d'=0.75: 0.750000/0.850000 NOT MET; d'=0.90: 0.900000/0.926500 NOT MET

[k=40 trace] min over states of max(phi, 1-phi) = 0.7000  -> any d' below this never binds
- phi code (W5 / W5t): d'=0.45: 0.789530/0.789530 ok; d'=0.65: 0.789530/0.789530 ok; d'=0.75: 0.814530/0.814530 ok; d'=0.90: 0.914440/0.914440 ok
- W10 policy bit act(phi) at d=0.55: d'=0.45: 0.789530/0.789530 ok; d'=0.65: 0.789530/0.789530 ok; d'=0.75: 0.789530/0.814530 NOT MET; d'=0.90: 0.900000/0.914440 NOT MET
- W1 regime code: d'=0.45: 0.700000/0.789530 NOT MET; d'=0.65: 0.700000/0.789530 NOT MET; d'=0.75: 0.750000/0.814530 NOT MET; d'=0.90: 0.900000/0.914440 NOT MET
