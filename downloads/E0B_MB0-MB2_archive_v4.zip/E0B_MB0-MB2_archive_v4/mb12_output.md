# E0-B MB1 + MB2 execution log

## MB1-B1 Contract audit (code is a function of declared inputs only)

- W1 regime code (theta-coupled): PASS
- W2 input parity (fixed): PASS
- W3 process model (truth table): PASS
- W5 token-phi monitor: PASS
- W6a per-cell tracker: PASS
- W6b identity classifier: PASS
- W7 bundle W1+W3+W5: PASS
- B1-scalar reliability q_T: PASS
- B1-accept-value: PASS
- B1-invert-value: PASS
- B1-action-vector: PASS
- NEGATIVE CONTROL: declares (o,r,z1,z2,theta,p) but reads f: VIOLATION detected (audit is sensitive)

## MB1-B2 RR consumer ladder (exact, mapping-oracle subproblem, relay payoff)

- linear-argmax: 0.806250
- one hidden threshold unit: 0.825000
- unrestricted: 0.825000
  (104 distinct hidden threshold units enumerated)

## MB1-B3 Optimization gaps (20 seeds, full-batch gradient ascent on exact expected payoff; greedy policy evaluated exactly)

- linear: rung optimum 0.806250; trained min 0.745313 / median 0.757812 / max 0.768969; seeds reaching optimum 0/20
- one-hidden: rung optimum 0.825000; trained min 0.746875 / median 0.759594 / max 0.771813; seeds reaching optimum 0/20

## MB2 Witness x predicate matrix (exact scope)

### W1 regime code (theta-coupled)

- Shea S1a calibration excess: 0.08207950367647059 -> NOT MET
- Shea S1b tracking rate: 0.0 -> NOT MET
- Shea S1b nuisance change mass: 0.0 -> ok
- Shea S1c directional substitution rate: 0.5 -> NOT MET
- Shea S1d transplant action-change mass: 0.0 -> NOT MET
- Shea S1e held-out d (value, optimum): [(0.7, 0.825), (0.7, 0.825)] -> NOT MET
- Shea S1f misrepresentation mass: 0.75 -> ok
- Shea S1h relay value (bound 0.804052): 0.7 -> NOT MET
- Shea S1h D11 separation (pairs separated / pairs): 9216/13824 -> NOT MET
- RR RR1b linear value without / with M (unrestricted optimum): (0.80625, 0.825, 0.825) -> ok
- RR RR1c post-rewire value, frozen consumer (pre 0.825) [ONE admissible consumer; identification in e0b_mb2_diag.py X1]: 0.825 -> ok
- RR RR1d substitution action-change mass: 0.37 -> ok
- RR RR1f relabelled value: 0.825 -> ok
- Process P1a linear-decoder accuracy / unrestricted / Bayes (prior 0.5): (0.5, 0.5, 0.5961779740558464) -> NOT MET
- Process P1b held-out-identity accuracy (structured Bayes on held-out): (0.5, 0.5961779740558464) -> NOT MET
- Process P1c relabel invariance: holds by construction (no parameter-dependent encoding in constructed witnesses) -> ok
- Process P1d prediction varies with M: False -> NOT MET
- Process P1e k=0 Bayes accuracy (must be labelled non_identified): 0.5

### W2 input parity (fixed)

- Shea S1a calibration excess: 0.08207950367647059 -> NOT MET
- Shea S1b tracking rate: 0.0 -> NOT MET
- Shea S1b nuisance change mass: 0.0 -> ok
- Shea S1c directional substitution rate: 0.5 -> NOT MET
- Shea S1d transplant action-change mass: 0.0 -> NOT MET
- Shea S1e held-out d (value, optimum): [(0.7, 0.825), (0.7, 0.825)] -> NOT MET
- Shea S1f misrepresentation mass: 0.75 -> ok
- Shea S1h relay value (bound 0.804052): 0.7 -> NOT MET
- Shea S1h D11 separation (pairs separated / pairs): 9216/13824 -> NOT MET
- RR RR1b linear value without / with M (unrestricted optimum): (0.80625, 0.825, 0.825) -> ok
- RR RR1c post-rewire value, frozen consumer (pre 0.825) [ONE admissible consumer; identification in e0b_mb2_diag.py X1]: 0.7125 -> NOT MET
- RR RR1d substitution action-change mass: 0.37 -> ok
- RR RR1f relabelled value: 0.825 -> ok
- Process P1a linear-decoder accuracy / unrestricted / Bayes (prior 0.5): (0.5, 0.5, 0.5961779740558464) -> NOT MET
- Process P1b held-out-identity accuracy (structured Bayes on held-out): (0.5, 0.5961779740558464) -> NOT MET
- Process P1c relabel invariance: holds by construction (no parameter-dependent encoding in constructed witnesses) -> ok
- Process P1d prediction varies with M: False -> NOT MET
- Process P1e k=0 Bayes accuracy (must be labelled non_identified): 0.5

### W3 process model (truth table)

- Shea S1a calibration excess: 0.08207950367647059 -> NOT MET
- Shea S1b tracking rate: 0.0 -> NOT MET
- Shea S1b nuisance change mass: 0.0 -> ok
- Shea S1c directional substitution rate: 0.5 -> NOT MET
- Shea S1d transplant action-change mass: 0.0 -> NOT MET
- Shea S1e held-out d (value, optimum): [(0.7, 0.825), (0.7, 0.825)] -> NOT MET
- Shea S1f misrepresentation mass: 0.75 -> ok
- Shea S1h relay value (bound 0.804052): 0.7 -> NOT MET
- Shea S1h D11 separation (pairs separated / pairs): 11520/13824 -> NOT MET
- RR RR1b linear value without / with M (unrestricted optimum): (0.80625, 0.80625, 0.825) -> NOT MET
- RR RR1c post-rewire value, frozen consumer (pre 0.825) [ONE admissible consumer; identification in e0b_mb2_diag.py X1]: 0.69375 -> NOT MET
- RR RR1d substitution action-change mass: 0.0 -> NOT MET
- RR RR1f relabelled value: 0.80625 -> ok
- Process P1a linear-decoder accuracy / unrestricted / Bayes (prior 0.5): (0.5961779740558464, 0.5961779740558464, 0.5961779740558464) -> ok
- Process P1b held-out-identity accuracy (structured Bayes on held-out): (0.5961779740558464, 0.5961779740558464) -> ok
- Process P1c relabel invariance: holds by construction (no parameter-dependent encoding in constructed witnesses) -> ok
- Process P1d prediction varies with M: True -> ok
- Process P1e k=0 Bayes accuracy (must be labelled non_identified): 0.5

### W5 token-phi monitor

- Shea S1a calibration excess: 0.0 -> ok
- Shea S1b tracking rate: 1.0 -> ok
- Shea S1b nuisance change mass: 0.0 -> ok
- Shea S1c directional substitution rate: 1.0 -> ok
- Shea S1d transplant action-change mass: 0.5 -> ok
- Shea S1e held-out d (value, optimum): [(0.825, 0.825), (0.825, 0.825)] -> ok
- Shea S1f misrepresentation mass: 0.5 -> ok
- Shea S1h relay value (bound 0.804052): 0.825 -> ok
- Shea S1h D11 separation (pairs separated / pairs): 13824/13824 -> ok
- RR RR1b linear value without / with M (unrestricted optimum): (0.80625, 0.825, 0.825) -> ok
- RR RR1c post-rewire value, frozen consumer (pre 0.825) [ONE admissible consumer; identification in e0b_mb2_diag.py X1]: 0.75 -> NOT MET
- RR RR1d substitution action-change mass: 0.5683333333333334 -> ok
- RR RR1f relabelled value: 0.825 -> ok
- Process P1a linear-decoder accuracy / unrestricted / Bayes (prior 0.5): (0.5176425685457506, 0.5542502407232844, 0.5961779740558464) -> NOT MET
- Process P1b held-out-identity accuracy (structured Bayes on held-out): (0.5176425685457506, 0.5961779740558464) -> ok
- Process P1c relabel invariance: holds by construction (no parameter-dependent encoding in constructed witnesses) -> ok
- Process P1d prediction varies with M: True -> ok
- Process P1e k=0 Bayes accuracy (must be labelled non_identified): 0.5

### W6a per-cell tracker

- Shea S1a calibration excess: 0.08207950367647059 -> NOT MET
- Shea S1b tracking rate: 0.0 -> NOT MET
- Shea S1b nuisance change mass: 0.0 -> ok
- Shea S1c directional substitution rate: 0.5 -> NOT MET
- Shea S1d transplant action-change mass: 0.0 -> NOT MET
- Shea S1e held-out d (value, optimum): [(0.7, 0.825), (0.7, 0.825)] -> NOT MET
- Shea S1f misrepresentation mass: 0.75 -> ok
- Shea S1h relay value (bound 0.804052): 0.7 -> NOT MET
- Shea S1h D11 separation (pairs separated / pairs): 11520/13824 -> NOT MET
- RR RR1b linear value without / with M (unrestricted optimum): (0.80625, 0.80625, 0.825) -> NOT MET
- RR RR1c post-rewire value, frozen consumer (pre 0.825) [ONE admissible consumer; identification in e0b_mb2_diag.py X1]: 0.69375 -> NOT MET
- RR RR1d substitution action-change mass: 0.0 -> NOT MET
- RR RR1f relabelled value: 0.80625 -> ok
- Process P1a linear-decoder accuracy / unrestricted / Bayes (prior 0.5): (0.5915774233712409, 0.5915774233712409, 0.5961779740558464) -> NOT MET
- Process P1b held-out-identity accuracy (structured Bayes on held-out): (0.518517350263204, 0.5961779740558464) -> ok
- Process P1c relabel invariance: holds by construction (no parameter-dependent encoding in constructed witnesses) -> ok
- Process P1d prediction varies with M: True -> ok
- Process P1e k=0 Bayes accuracy (must be labelled non_identified): 0.5

### W6b identity classifier

- Shea S1a calibration excess: 0.08207950367647059 -> NOT MET
- Shea S1b tracking rate: 0.0 -> NOT MET
- Shea S1b nuisance change mass: 0.0 -> ok
- Shea S1c directional substitution rate: 0.5 -> NOT MET
- Shea S1d transplant action-change mass: 0.0 -> NOT MET
- Shea S1e held-out d (value, optimum): [(0.7, 0.825), (0.7, 0.825)] -> NOT MET
- Shea S1f misrepresentation mass: 0.75 -> ok
- Shea S1h relay value (bound 0.804052): 0.7 -> NOT MET
- Shea S1h D11 separation (pairs separated / pairs): 9984/13824 -> NOT MET
- RR RR1b linear value without / with M (unrestricted optimum): (0.80625, 0.80625, 0.825) -> NOT MET
- RR RR1c post-rewire value, frozen consumer (pre 0.825) [ONE admissible consumer; identification in e0b_mb2_diag.py X1]: 0.69375 -> NOT MET
- RR RR1d substitution action-change mass: 0.0 -> NOT MET
- RR RR1f relabelled value: 0.80625 -> ok
- Process P1a linear-decoder accuracy / unrestricted / Bayes (prior 0.5): (0.5645485546137463, 0.5645485546137463, 0.5961779740558464) -> NOT MET
- Process P1b held-out-identity accuracy (structured Bayes on held-out): (0.4630341952298601, 0.5961779740558464) -> NOT MET
- Process P1c relabel invariance: holds by construction (no parameter-dependent encoding in constructed witnesses) -> ok
- Process P1d prediction varies with M: True -> ok
- Process P1e k=0 Bayes accuracy (must be labelled non_identified): 0.5

### W7 bundle W1+W3+W5

- Shea S1a calibration excess: 0.0 -> ok
- Shea S1b tracking rate: 1.0 -> ok
- Shea S1b nuisance change mass: 0.0 -> ok
- Shea S1c directional substitution rate: 1.0 -> ok
- Shea S1d transplant action-change mass: 0.5 -> ok
- Shea S1e held-out d (value, optimum): [(0.825, 0.825), (0.825, 0.825)] -> ok
- Shea S1f misrepresentation mass: 0.5 -> ok
- Shea S1h relay value (bound 0.804052): 0.825 -> ok
- Shea S1h D11 separation (pairs separated / pairs): 13824/13824 -> ok
- RR RR1b linear value without / with M (unrestricted optimum): (0.80625, 0.825, 0.825) -> ok
- RR RR1c post-rewire value, frozen consumer (pre 0.825) [ONE admissible consumer; identification in e0b_mb2_diag.py X1]: 0.825 -> ok
- RR RR1d substitution action-change mass: 0.36 -> ok
- RR RR1f relabelled value: 0.825 -> ok
- Process P1a linear-decoder accuracy / unrestricted / Bayes (prior 0.5): (0.5961779740558464, 0.6023392277512076, 0.5961779740558464) -> ok
- Process P1b held-out-identity accuracy (structured Bayes on held-out): (0.5961779740558464, 0.5961779740558464) -> ok
- Process P1c relabel invariance: holds by construction (no parameter-dependent encoding in constructed witnesses) -> ok
- Process P1d prediction varies with M: True -> ok
- Process P1e k=0 Bayes accuracy (must be labelled non_identified): 0.5

### B1-scalar reliability q_T

- Shea S1a calibration excess: 0.08207950367647059 -> NOT MET
- Shea S1b tracking rate: 0.0 -> NOT MET
- Shea S1b nuisance change mass: 0.0 -> ok
- Shea S1c directional substitution rate: 0.5 -> NOT MET
- Shea S1d transplant action-change mass: 0.0 -> NOT MET
- Shea S1e held-out d (value, optimum): [(0.7, 0.825), (0.7, 0.825)] -> NOT MET
- Shea S1f misrepresentation mass: 0.75 -> ok
- Shea S1h relay value (bound 0.804052): 0.7 -> NOT MET
- Shea S1h D11 separation (pairs separated / pairs): 9216/13824 -> NOT MET
- RR RR1b linear value without / with M (unrestricted optimum): (0.80625, 0.825, 0.825) -> ok
- RR RR1c post-rewire value, frozen consumer (pre 0.825) [ONE admissible consumer; identification in e0b_mb2_diag.py X1]: 0.825 -> ok
- RR RR1d substitution action-change mass: 0.41 -> ok
- RR RR1f relabelled value: 0.825 -> ok
- Process P1a linear-decoder accuracy / unrestricted / Bayes (prior 0.5): (0.5, 0.5, 0.5961779740558464) -> NOT MET
- Process P1b held-out-identity accuracy (structured Bayes on held-out): (0.5, 0.5961779740558464) -> NOT MET
- Process P1c relabel invariance: holds by construction (no parameter-dependent encoding in constructed witnesses) -> ok
- Process P1d prediction varies with M: False -> NOT MET
- Process P1e k=0 Bayes accuracy (must be labelled non_identified): 0.5

### B1-accept-value

- Shea S1a calibration excess: 0.03177425973705617 -> NOT MET
- Shea S1b tracking rate: 0.705 -> NOT MET
- Shea S1b nuisance change mass: 1.0 -> NOT MET
- Shea S1c directional substitution rate: 0.75 -> NOT MET
- Shea S1d transplant action-change mass: 0.5 -> ok
- Shea S1e held-out d (value, optimum): [(0.773828125, 0.825), (0.7909215073529412, 0.825)] -> NOT MET
- Shea S1f misrepresentation mass: 0.625 -> ok
- Shea S1h relay value (bound 0.804052): 0.773828125 -> NOT MET
- Shea S1h D11 separation (pairs separated / pairs): 0/13824 -> NOT MET
- RR: not evaluated: kappa-continuous code; the RR consumer class is defined on the finite cell set
- Process P1a upper bound via W5 (data processing) vs Bayes: (0.5542502407232844, 0.5961779740558464) -> NOT MET

### B1-invert-value

- Shea S1a calibration excess: 0.03177425973705617 -> NOT MET
- Shea S1b tracking rate: 0.705 -> NOT MET
- Shea S1b nuisance change mass: 1.0 -> NOT MET
- Shea S1c directional substitution rate: 0.75 -> NOT MET
- Shea S1d transplant action-change mass: 0.5 -> ok
- Shea S1e held-out d (value, optimum): [(0.773828125, 0.825), (0.7909215073529412, 0.825)] -> NOT MET
- Shea S1f misrepresentation mass: 0.625 -> ok
- Shea S1h relay value (bound 0.804052): 0.773828125 -> NOT MET
- Shea S1h D11 separation (pairs separated / pairs): 0/13824 -> NOT MET
- RR: not evaluated: kappa-continuous code; the RR consumer class is defined on the finite cell set
- Process P1a upper bound via W5 (data processing) vs Bayes: (0.5542502407232844, 0.5961779740558464) -> NOT MET

### B1-action-vector

- Shea S1a calibration excess: 0.01565475807796984 -> NOT MET
- Shea S1b tracking rate: 0.705 -> NOT MET
- Shea S1b nuisance change mass: 1.0 -> NOT MET
- Shea S1c directional substitution rate: 1.0 -> ok
- Shea S1d transplant action-change mass: 0.5 -> ok
- Shea S1e held-out d (value, optimum): [(0.804051513671875, 0.825), (0.8132957656723075, 0.825)] -> NOT MET
- Shea S1f misrepresentation mass: 0.5 -> ok
- Shea S1h relay value (bound 0.804052): 0.804051513671875 -> NOT MET
- Shea S1h D11 separation (pairs separated / pairs): 0/13824 -> NOT MET
- RR: not evaluated: kappa-continuous code; the RR consumer class is defined on the finite cell set
- Process P1a upper bound via W5 (data processing) vs Bayes: (0.5542502407232844, 0.5961779740558464) -> NOT MET

## MB2 summary: observed (predicted)

| witness | Shea | RR | Process | matches prediction |
|---|---|---|---|---|
| W1 regime code (theta-coupled) | fail (fail) | pass (pass) | fail (fail) | yes |
| W2 input parity (fixed) | fail (fail) | fail (fail) | fail (fail) | yes |
| W3 process model (truth table) | fail (fail) | fail (fail) | pass (pass) | yes |
| W5 token-phi monitor | pass (pass) | fail (fail) | fail (fail) | yes |
| W6a per-cell tracker | fail (fail) | fail (fail) | fail (fail) | yes |
| W6b identity classifier | fail (fail) | fail (fail) | fail (fail) | yes |
| W7 bundle W1+W3+W5 | pass (pass) | pass (pass) | pass (pass) | yes |
| B1-scalar reliability q_T | fail (fail) | pass (fail) | fail (fail) | NO |
| B1-accept-value | fail (fail) | n/e (n/e) | fail (fail) | yes |
| B1-invert-value | fail (fail) | n/e (n/e) | fail (fail) | yes |
| B1-action-vector | fail (fail) | n/e (n/e) | fail (fail) | yes |
