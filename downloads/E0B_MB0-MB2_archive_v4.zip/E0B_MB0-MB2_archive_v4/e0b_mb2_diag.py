#!/usr/bin/env python3
"""E0-B MB2 diagnostics for the two anomalies found in the first matrix run.

X1  RR1c identification: the frozen consumer is any weight vector realising a pre-rewire optimal linear policy.
    Different admissible weight vectors can behave differently after rewiring. For each witness that passes RR1b:
      (i)  does SOME admissible frozen consumer retain the post-rewire optimum?   (LP feasibility)
      (ii) does SOME admissible frozen consumer lose value after rewiring?      (LP feasibility per post cell/action)
X2  P1b criterion consistency: report held-out accuracy against the (normalised) held-out Bayes bound;
    original criterion (> 1/2) and the exact-scope criterion used by every other clause (attains the bound).
"""
from fractions import Fraction as F
from itertools import product
from collections import defaultdict
import numpy as np
from scipy.optimize import linprog
import e0b_mb12 as M

def feasible(cons, k):
    """cons: list of (feature vector, chosen action) requiring strict margin 1 over every other action."""
    rows = []
    for xv, a in cons:
        x = np.array(xv + [1.0])
        for o in range(3):
            if o != a:
                row = np.zeros(3 * k); row[o*k:(o+1)*k] = x; row[a*k:(a+1)*k] -= x; rows.append(row)
    r = linprog(np.zeros(3 * k), A_ub=np.array(rows), b_ub=-np.ones(len(rows)), bounds=[(None, None)] * (3 * k), method='highs')
    return r.status == 0

def optimal_policies(tab, feats):
    """all realisable linear policies attaining the best realisable value (ties enumerated)"""
    pay = {cl: (v[1], v[0] - v[1], M.D * v[0]) for cl, v in tab.items()}
    pols = sorted(product(range(3), repeat=8), key=lambda t: -sum(pay[cl][a] for cl, a in zip(M.CELLS, t)))
    best = None; out = []
    for t in pols:
        v = sum(pay[cl][a] for cl, a in zip(M.CELLS, t))
        if best is not None and v < best: break
        if feasible([(feats[cl], a) for cl, a in zip(M.CELLS, t)], len(next(iter(feats.values()))) + 1):
            best = v; out.append(t)
    return best, out

def rr1c_identification(name):
    w = M.W[name]
    pre = M.sub_tables(M.world(), w, M.CTX0); post = M.sub_tables(M.world(theta='z1'), w, dict(M.CTX0, theta='z1'))
    some_retain = True; some_fail = False; detail = []
    for key in pre:
        tpre, tpost = pre[key], post[key]
        fpre = {cl: list(cl) + M.enc(v[2]) for cl, v in tpre.items()}
        fpost = {cl: list(cl) + M.enc(v[2]) for cl, v in tpost.items()}
        k = len(next(iter(fpre.values()))) + 1
        _, prepols = optimal_policies(tpre, fpre)
        paypost = {cl: (v[1], v[0] - v[1], M.D * v[0]) for cl, v in tpost.items()}
        optact = {cl: {a for a in range(3) if paypost[cl][a] == max(paypost[cl])} for cl in M.CELLS}
        # (i) some admissible consumer reaches the post optimum: some pre-optimal policy + some post-optimal action per cell
        retain = False
        for t in prepols:
            for choice in product(*[sorted(optact[cl]) for cl in M.CELLS]):
                cons = [(fpre[cl], a) for cl, a in zip(M.CELLS, t)] + [(fpost[cl], a) for cl, a in zip(M.CELLS, choice)]
                if feasible(cons, k): retain = True; break
            if retain: break
        # (ii) some admissible consumer picks a strictly worse action in some post cell with positive mass
        fail = False
        for t in prepols:
            for cl in M.CELLS:
                if tpost[cl][0] == 0: continue
                for a in range(3):
                    if a in optact[cl]: continue
                    if feasible([(fpre[c], b) for c, b in zip(M.CELLS, t)] + [(fpost[cl], a)], k): fail = True; break
                if fail: break
            if fail: break
        some_retain &= retain; some_fail |= fail
        detail.append((key, retain, fail))
    return some_retain, some_fail, detail

if __name__ == '__main__':
    print("## X1 RR1c identification under admissible frozen consumers\n")
    print("| witness | some admissible consumer retains the post-rewire optimum (all subproblems) | some admissible consumer loses value | RR1c status |")
    print("|---|---|---|---|")
    for name in ['W1 regime code (theta-coupled)', 'W2 input parity (fixed)', 'W5 token-phi monitor',
                 'W7 bundle W1+W3+W5', 'B1-scalar reliability q_T']:
        r, f, _ = rr1c_identification(name)
        status = 'robust pass' if r and not f else ('robust fail' if not r else 'NOT IDENTIFIED (depends on which admissible consumer is frozen)')
        print(f"| {name} | {r} | {f} | {status} |")
    print("\n## X2 P1b against the normalised held-out Bayes bound (k = 5)\n")
    print("| witness | held-out accuracy | held-out structured Bayes | original criterion (> 1/2) | exact-scope criterion (attains bound) |")
    print("|---|---|---|---|---|")
    St = M.proc_states(5)
    Str = [x for x in St if x[1]['wb'] in M.TRAIN_IDS]; Sho = [x for x in St if x[1]['wb'] in M.HELDOUT_IDS]
    tot = sum(pr for pr, _, _ in Sho)
    bayes_ho = M.unrestricted_acc(Sho, M.PROC['W3 process model (truth table)'][1])[0] / tot
    for name, (lvl, code) in M.PROC.items():
        hb, _ = M.linear_acc(Sho, code, fit_on=Str)
        print(f"| {name} | {float(hb):.6f} | {float(bayes_ho):.6f} | {'pass' if hb > F(1, 2) else 'fail'} | {'pass' if hb == bayes_ho else 'fail'} |")
