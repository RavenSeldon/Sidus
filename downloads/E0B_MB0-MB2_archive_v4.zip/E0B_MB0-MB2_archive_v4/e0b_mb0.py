#!/usr/bin/env python3
"""E0-B MB0 — remaining reference work (R2.4 contract, v2.2 + Ledgers D, D-II, Completion Plan).

M1  Trace estimators: marginal-MAP bits, joint-MAP mapping, full posterior (relay phi-code value, k sweep).
M2  R2.4 channel-dependent reference tables: phi code vs registered rivals
      B1-accept-value (phi+ka), B1-invert-value (1-phi+ki), B1-action-vector (both),
    relay observes (M, R), never the kappas; marginal-replacement channel eps in {0, 1/10, 1/3}.
    By the dominance argument (Ledger D-II) each rival row bounds every code measurable w.r.t. that rival.
M3  D11 caliper rule: exact population eligibility for sampled pairs as a function of caliper delta.

Exact rational arithmetic except where marked float64. Imports e0b_contracts.py.
"""
from fractions import Fraction as F
from collections import defaultdict
from itertools import product
from math import comb, lgamma, log
import e0b_contracts as C

D = C.D
pay = lambda m, c: (c, m - c, D * m)

# ------------------------------------------------------------------ M1 estimators
def _grids(k):
    import numpy as np
    j = np.arange(k + 1); lc = np.array([lgamma(k+1)-lgamma(i+1)-lgamma(k-i+1) for i in j])
    p = float(C.pS1); ll = {0: j*log(p)+(k-j)*log(1-p), 1: j*log(1-p)+(k-j)*log(p)}
    g = np.meshgrid(j, j, j, j, indexing='ij')
    logL = np.stack([sum(ll[C.fval(wb, o)][g[i]] for i, o in enumerate(C.OS)) for wb in C.FAM]).reshape(6, -1)
    lm = sum(lc[g[i]] for i in range(4)).reshape(-1)
    return np, logL, lm

def joint_map_dist(k):
    """P(f_JMAP(o) = 1 | wb) where f_JMAP is the truth table of the single most likely mapping (ties uniform). float64."""
    np, logL, lm = _grids(k)
    best = logL.max(axis=0); winners = (logL >= best - 1e-12).astype(float); winners /= winners.sum(axis=0)
    out = {}
    for wi, wb in enumerate(C.FAM):
        pc = np.exp(lm + logL[wi])
        for o in C.OS:
            sel = sum(winners[vi] for vi, v in enumerate(C.FAM) if C.fval(v, o) == 1)
            out[(wb, o)] = F(float(np.sum(pc * sel))).limit_denominator(10**9)
    return out

def states_with(mb):
    """kappa-free U1 states with an estimator bit 'fhat' drawn from mb[(wb,o)] = P(fhat=1|wb). mb=None -> oracle."""
    for x, z1, z2, n, o, wb in product((0, 1), (0, 1), (0, 1), (0, 1), C.OS, C.FAM):
        T = z1 ^ z2; q = C.QH if T == 0 else C.QL
        pr = (C.P_X if x else 1 - C.P_X) * F(1, 4) * ((1 - q) if n else q) * F(1, 4) * F(1, 6)
        f = C.fval(wb, o); r = (x ^ n) ^ f
        s = dict(x=x, z1=z1, z2=z2, T=T, o=o, wb=wb, f=f, r=r, L=int(r == x))
        if mb is None:
            yield pr, dict(s, fhat=f)
        else:
            p1 = mb[(wb, o)]
            for fh, pf in ((1, p1), (0, 1 - p1)):
                if pf: yield pr * pf, dict(s, fhat=fh)

def atoms_from(S):
    """(R, phi) -> [mass, correct mass], phi = E[L | o, R, T, fhat] (ideal encoder under the declared contract)."""
    S = list(S); phi = C.encode(S, 'L', ['o', 'r', 'T', 'fhat']); A = defaultdict(lambda: [F(0), F(0)])
    for pr, s in S: a = A[(s['r'], phi(s))]; a[0] += pr; a[1] += pr * s['L']
    return dict(A)

def relay_phi(A, eps=F(0)):
    marg = defaultdict(F)
    for (r, f), (m, c) in A.items(): marg[f] += m
    tot = {r: [sum(pay(m, c)[j] for (rr, f), (m, c) in A.items() if rr == r) for j in range(3)] for r in (0, 1)}
    return sum(max((1-eps) * pay(*A.get((r, f), (F(0), F(0))))[j] + eps * pm * tot[r][j] for j in range(3))
               for f, pm in marg.items() for r in (0, 1))

# ------------------------------------------------------------------ M2 rivals under the channel
def relay_rival(A, kind, eps=F(0)):
    """kind: 'accept' (phi+U), 'invert' (1-phi+U), 'vector' ((phi+U1, 1-phi+U2)). Piecewise-exact."""
    it = [(r, f, m, c) for (r, f), (m, c) in A.items()]
    tot = {r: [sum(pay(m, c)[j] for rr, f, m, c in it if rr == r) for j in range(3)] for r in (0, 1)}
    if kind in ('accept', 'invert'):
        sh = (lambda f: f) if kind == 'accept' else (lambda f: 1 - f)
        bps = sorted({sh(f) for _, f, _, _ in it} | {sh(f) + 1 for _, f, _, _ in it}); v = F(0)
        for lo, hi in zip(bps, bps[1:]):
            mid = (lo + hi) / 2; live = [x for x in it if sh(x[1]) <= mid <= sh(x[1]) + 1]
            dens = sum(x[2] for x in live)
            for r in (0, 1):
                sig = [sum(pay(m, c)[j] for rr, f, m, c in live if rr == r) for j in range(3)]
                v += (hi - lo) * max((1-eps) * sig[j] + eps * dens * tot[r][j] for j in range(3))
        return v
    bx = sorted({f for _, f, _, _ in it} | {f + 1 for _, f, _, _ in it})
    by = sorted({1 - f for _, f, _, _ in it} | {2 - f for _, f, _, _ in it}); v = F(0)
    for x0, x1 in zip(bx, bx[1:]):
        mx = (x0 + x1) / 2; colx = [x for x in it if x[1] <= mx <= x[1] + 1]
        for y0, y1 in zip(by, by[1:]):
            my = (y0 + y1) / 2; live = [x for x in colx if 1 - x[1] <= my <= 2 - x[1]]
            dens = sum(x[2] for x in live)
            for r in (0, 1):
                sig = [sum(pay(m, c)[j] for rr, f, m, c in live if rr == r) for j in range(3)]
                v += (x1 - x0) * (y1 - y0) * max((1-eps) * sig[j] + eps * dens * tot[r][j] for j in range(3))
    return v

# ------------------------------------------------------------------ M3 D11 caliper eligibility
def d11_eligibility(A, delta, kind='vector'):
    """Probability that two independently sampled trials with the SAME R are caliper-matched on the rival code
    (|dQ_a| <= delta, and |dQ_i| <= delta for the vector rival) AND have different relay-optimal actions under phi.
    Exact: for atoms phi1, phi2 with uniform independent kappas, P(|phi1+U1-(phi2+U2)| <= delta) = P(|U1-U2-(phi2-phi1)| <= delta)."""
    def p_absdiff(shift, dl):    # P(|W - shift| <= dl), W = U1 - U2 triangular on [-1, 1]
        cdf = lambda w: F(0) if w <= -1 else F(1) if w >= 1 else ((w + 1)**2 / 2 if w <= 0 else 1 - (1 - w)**2 / 2)
        return cdf(shift + dl) - cdf(shift - dl)
    act = lambda m, c: max(range(3), key=lambda j: pay(m, c)[j])
    it = [(r, f, m, c) for (r, f), (m, c) in A.items()]
    tot = F(0); elig = F(0)
    for (r1, f1, m1, c1), (r2, f2, m2, c2) in product(it, it):
        if r1 != r2: continue
        w = m1 * m2; tot += w
        if act(m1, c1) == act(m2, c2): continue
        pa = p_absdiff(f2 - f1, delta)
        pm = pa * (p_absdiff(f1 - f2, delta) if kind == 'vector' else 1)
        elig += w * pm
    return elig / tot

if __name__ == '__main__':
    fmt = lambda v: f"{float(v):.6f}"
    print("## M1 Trace estimators — relay (M,R) value of the ideal phi code, R2.4 kappa-free\n")
    print("| k | marginal-MAP bits | joint-MAP mapping | full posterior (Ledger D, D7) |")
    print("|---|---|---|---|")
    FULL = {10: 0.734616, 20: 0.762713, 40: 0.794698}
    estim = {}
    for k in (10, 20, 40, 80):
        mm = C.map_bit_dist(k) if k <= 10 else C.map_bit_dist_float(k)
        jm = joint_map_dist(k)
        Am, Aj = atoms_from(states_with(mm)), atoms_from(states_with(jm))
        estim[k] = (Am, Aj)
        print(f"| {k} | {fmt(relay_phi(Am))} | {fmt(relay_phi(Aj))} | {FULL.get(k, 'not computed')} |")
    A0 = atoms_from(states_with(None))
    print(f"| oracle | {fmt(relay_phi(A0))} | {fmt(relay_phi(A0))} | 0.825000 |")

    print("\n## M2 R2.4 channel-dependent references — relay observes (M, R)\n")
    print("| access | eps | phi code | B1-accept bound | B1-invert bound | B1-action-vector bound | phi minus vector |")
    print("|---|---|---|---|---|---|---|")
    for tag, A in (('oracle', A0), ('k=40 marginal-MAP', estim[40][0]), ('k=40 joint-MAP', estim[40][1])):
        for eps in (F(0), F(1, 10), F(1, 3)):
            pv = relay_phi(A, eps); va = relay_rival(A, 'accept', eps); vi = relay_rival(A, 'invert', eps); vv = relay_rival(A, 'vector', eps)
            print(f"| {tag} | {eps} | {fmt(pv)} | {fmt(va)} | {fmt(vi)} | {fmt(vv)} | {float(pv - vv):+.6f} |")

    print("\n## M3 D11 caliper eligibility (population probability that a random same-R pair is caliper-matched on the rival code AND phi-optimal relay actions differ)\n")
    print("| access | delta | accept-rival caliper | vector-rival caliper |")
    print("|---|---|---|---|")
    for tag, A in (('oracle', A0), ('k=40 joint-MAP', estim[40][1])):
        for dl in (F(1, 100), F(1, 50), F(1, 20)):
            print(f"| {tag} | {dl} | {fmt(d11_eligibility(A, dl, 'accept'))} | {fmt(d11_eligibility(A, dl, 'vector'))} |")
