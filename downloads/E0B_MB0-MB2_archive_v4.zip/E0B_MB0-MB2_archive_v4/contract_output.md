
### Contract table — beta = 2/5 (v2.1)

| id | encoder [declared inputs] | mapping access | consumer | consumer observes | value |
|---|---|---|---|---|---|
| C0 | none | - | relay | o,R | 0.700000 |
| C1 | phi[o,R,T,f,kappa] | mapping oracle | relay | M | 0.825000 |
| C2 | Q[o,R,T,f,kappa] | mapping oracle | relay | M | 0.775000 |
| C3 | phi[o,R,T,f,kappa] | mapping oracle | relay | M,R | 0.825000 |
| C4 | Q[o,R,T,f,kappa] | mapping oracle | relay | M,R | 0.825000 |
| C5 | Q[o,R,T,f] (no kappa: v2.1 contract) | mapping oracle | relay | M | 0.825000 |
| C6 | phi[...] via channel eps=1/3 | mapping oracle | relay | M | 0.716667 |
| C7 | phi[...] via channel eps=1/3 | mapping oracle | relay | M,R | 0.772667 |
| C8 | Q[...] via channel eps=1/3 | mapping oracle | relay | M | 0.685417 |
| C9 | Q[...] via channel eps=1/3 | mapping oracle | relay | M,R | 0.772667 |
| C10 | none (full information) | - | accept_consumer | o,R,T,f,kappa | 0.841000 |
| C11 | none (full info, kappa hidden) | - | accept_consumer | o,R,T,f | 0.841000 |
| C12 | phi[o,R,T,fhat,kappa] | k=10 traces | relay | M | 0.716503 |
| C13 | Q[o,R,T,fhat,kappa] | k=10 traces | relay | M | 0.666503 |
| C14 | Q[o,R,T,fhat,kappa] | k=10 traces | relay | M,R | 0.716503 |

Fixed-R Q collisions with different phi: none
R=0,T=1,f=0: phi = 3/10;  Q with kappa = 3/10 / 7/10;  'Q' encoder without kappa emits 1/2 for both

### Contract table — beta = 189/320 (fixed-R collision, v2.2)

| id | encoder [declared inputs] | mapping access | consumer | consumer observes | value |
|---|---|---|---|---|---|
| C0 | none | - | relay | o,R | 0.700000 |
| C1 | phi[o,R,T,f,kappa] | mapping oracle | relay | M | 0.825000 |
| C2 | Q[o,R,T,f,kappa] | mapping oracle | relay | M | 0.793750 |
| C3 | phi[o,R,T,f,kappa] | mapping oracle | relay | M,R | 0.825000 |
| C4 | Q[o,R,T,f,kappa] | mapping oracle | relay | M,R | 0.793750 |
| C5 | Q[o,R,T,f] (no kappa: v2.1 contract) | mapping oracle | relay | M | 0.825000 |
| C6 | phi[...] via channel eps=1/3 | mapping oracle | relay | M | 0.716667 |
| C7 | phi[...] via channel eps=1/3 | mapping oracle | relay | M,R | 0.772667 |
| C8 | Q[...] via channel eps=1/3 | mapping oracle | relay | M | 0.697833 |
| C9 | Q[...] via channel eps=1/3 | mapping oracle | relay | M,R | 0.754500 |
| C10 | none (full information) | - | accept_consumer | o,R,T,f,kappa | 0.872453 |
| C11 | none (full info, kappa hidden) | - | accept_consumer | o,R,T,f | 0.848625 |
| C12 | phi[o,R,T,fhat,kappa] | k=10 traces | relay | M | 0.716503 |
| C13 | Q[o,R,T,fhat,kappa] | k=10 traces | relay | M | 0.716503 |
| C14 | Q[o,R,T,fhat,kappa] | k=10 traces | relay | M,R | 0.716503 |

Fixed-R Q collisions with different phi: {(0, Fraction(57, 64)): ['3/10', '57/64']}
R=0,T=1,f=0: phi = 3/10;  Q with kappa = 3/10 / 57/64;  'Q' encoder without kappa emits 381/640 for both

False-fail, m clauses at alpha=0.05: independence 1-(0.95)^m vs union bound m*alpha
  m=3: 0.143 (independent)  0.15 (no dependence assumption)
  m=6: 0.265 (independent)  0.30 (no dependence assumption)
  m=10: 0.401 (independent)  0.50 (no dependence assumption)

### Trace-budget sweep (mapping known only through k traces per input; beta = 189/320)

| k | P(fhat=f) | relay: phi code, M | relay: Q code, M | relay: Q code, M+R | phi minus Q (M+R) | RR gap (linear+parity minus linear) |
|---|---|---|---|---|---|---|
| 10 | 0.7500 | 0.716503 | 0.716503 | 0.716503 | 0.000000 | 0.001998 |
| 20 | 0.8339 | 0.750250 | 0.750250 | 0.750250 | 0.000000 | 0.007815 |
| 40 | 0.9212 | 0.789530 | 0.789530 | 0.789530 | 0.000000 | 0.018028 |
| 80 | 0.9812 | 0.816540 | 0.816540 | 0.816540 | 0.000000 | 0.018750 |

### Shea discriminator under capacity limits (kappa uniform on {0,1/8,...,1}, beta = 1; relay observes M and R)

| mapping access | L bins | relay: phi code (own-optimal) | relay: Q code (own-optimal) | gap | Q code on its own consumer |
|---|---|---|---|---|---|
| mapping oracle | 2 | 0.825000 | 0.762500 | 0.062500 | 0.909028 |
| mapping oracle | 4 | 0.825000 | 0.769083 | 0.055917 | 0.914444 |
| mapping oracle | unlimited | 0.825000 | 0.825000 | 0.000000 | - |
| k=40 traces | 2 | 0.789530 | 0.744765 | 0.044765 | 0.880947 |
| k=40 traces | 4 | 0.789530 | 0.745923 | 0.043607 | 0.883703 |
| k=40 traces | unlimited | 0.789530 | 0.789530 | 0.000000 | - |

### RR accessibility (kappa=0 trials, linear-argmax over (R,Z1,Z2)); consumer conditioned on the stated mapping access

| mapping access | linear raw | linear + parity | unrestricted | gap |
|---|---|---|---|---|
| mapping oracle (f known) | 0.806250 | 0.825000 | 0.825000 | 0.018750 |
| k=10 traces (fhat known) | 0.714505 | 0.716503 | 0.716503 | 0.001998 |
| no mapping information | 0.700000 | 0.700000 | 0.700000 | 0.000000 |
