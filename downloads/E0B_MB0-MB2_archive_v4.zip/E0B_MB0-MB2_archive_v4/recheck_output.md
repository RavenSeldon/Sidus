RECHECK C-sup 1 {'relay': 0.796105, 'calib_excess': 0.000502, 'kappa_sens': 0.014077, 'kappa_R2': 0.009115, 'D11_agreement': 0.920748, 'S1e_gap_0.75': 0.000347, 'S1e_gap_0.8': 0.000846} 12s
RECHECK C-end 1 {'relay': 0.769105, 'calib_excess': 0.018075, 'kappa_sens': 0.5724, 'kappa_R2': 0.322408, 'D11_agreement': 0.00653, 'S1e_gap_0.75': 0.02158, 'S1e_gap_0.8': 0.024058} 13s
RECHECK B0-am 1 {'relay': 0.78263, 'calib_excess': 0.009983, 'kappa_sens': 1.975514, 'kappa_R2': 0.91119, 'D11_agreement': 0.400422, 'S1e_gap_0.75': 0.017312, 'S1e_gap_0.8': 0.01529} 24s
RECHECK R-vec 1 {'relay': 0.769216, 'calib_excess': 0.02012, 'kappa_sens': 1.203135, 'kappa_R2': 0.656667, 'D11_agreement': 0.012355, 'S1e_gap_0.75': 0.026748, 'S1e_gap_0.8': 0.032388} 11s
RECHECK R-acc 1 {'relay': 0.74663, 'calib_excess': 0.032138, 'kappa_sens': 0.76928, 'kappa_R2': 0.326076, 'D11_agreement': 0.005417, 'S1e_gap_0.75': 0.03924, 'S1e_gap_0.8': 0.041526} 10s
RECHECK IDEAL 1 {'relay': 0.796392, 'calib_excess': 0.000331, 'kappa_sens': 0.0, 'kappa_R2': -0.007603, 'D11_agreement': 0.923716, 'S1e_gap_0.75': 0.000295, 'S1e_gap_0.8': 0.000244}
RECHECK C-sup 2 {'relay': 0.793908, 'calib_excess': 0.000446, 'kappa_sens': 0.013664, 'kappa_R2': 0.003331, 'D11_agreement': 0.93514, 'S1e_gap_0.75': 0.000443, 'S1e_gap_0.8': 0.000586} 10s
RECHECK C-end 2 {'relay': 0.763544, 'calib_excess': 0.019962, 'kappa_sens': 0.616465, 'kappa_R2': 0.324694, 'D11_agreement': 0.03769, 'S1e_gap_0.75': 0.02441, 'S1e_gap_0.8': 0.02583} 13s
RECHECK B0-am 2 {'relay': 0.78056, 'calib_excess': 0.011495, 'kappa_sens': 1.936193, 'kappa_R2': 0.763702, 'D11_agreement': 0.485764, 'S1e_gap_0.75': 0.013567, 'S1e_gap_0.8': 0.013778} 23s
RECHECK R-vec 2 {'relay': 0.766636, 'calib_excess': 0.021228, 'kappa_sens': 1.228983, 'kappa_R2': 0.660522, 'D11_agreement': 0.007262, 'S1e_gap_0.75': 0.02991, 'S1e_gap_0.8': 0.033478} 10s
RECHECK R-acc 2 {'relay': 0.745698, 'calib_excess': 0.032616, 'kappa_sens': 0.78802, 'kappa_R2': 0.325947, 'D11_agreement': 0.003784, 'S1e_gap_0.75': 0.040772, 'S1e_gap_0.8': 0.04211} 10s
RECHECK IDEAL 2 {'relay': 0.79403, 'calib_excess': 0.000314, 'kappa_sens': 0.0, 'kappa_R2': -0.005405, 'D11_agreement': 0.923939, 'S1e_gap_0.75': 0.000177, 'S1e_gap_0.8': 0.000176}
RECHECK C-sup 3 {'relay': 0.794003, 'calib_excess': 0.000386, 'kappa_sens': 0.013719, 'kappa_R2': 0.009549, 'D11_agreement': 0.951533, 'S1e_gap_0.75': 0.000465, 'S1e_gap_0.8': 0.000286} 10s
RECHECK C-end 3 {'relay': 0.769759, 'calib_excess': 0.017094, 'kappa_sens': 0.557015, 'kappa_R2': 0.327989, 'D11_agreement': 0.005047, 'S1e_gap_0.75': 0.022487, 'S1e_gap_0.8': 0.023922} 13s
RECHECK B0-am 3 {'relay': 0.79404, 'calib_excess': 0.002043, 'kappa_sens': 1.881664, 'kappa_R2': 0.8052, 'D11_agreement': 0.917219, 'S1e_gap_0.75': 0.000975, 'S1e_gap_0.8': 0.00076} 23s
RECHECK R-vec 3 {'relay': 0.767561, 'calib_excess': 0.020473, 'kappa_sens': 1.21508, 'kappa_R2': 0.659873, 'D11_agreement': 0.012297, 'S1e_gap_0.75': 0.028537, 'S1e_gap_0.8': 0.03213} 10s
RECHECK R-acc 3 {'relay': 0.74772, 'calib_excess': 0.030657, 'kappa_sens': 0.766931, 'kappa_R2': 0.327797, 'D11_agreement': 0.008907, 'S1e_gap_0.75': 0.03785, 'S1e_gap_0.8': 0.039262} 10s
RECHECK IDEAL 3 {'relay': 0.79424, 'calib_excess': 0.000333, 'kappa_sens': 0.0, 'kappa_R2': -0.001525, 'D11_agreement': 0.921695, 'S1e_gap_0.75': 0.000595, 'S1e_gap_0.8': 0.000104}
RECHECK C-sup 4 {'relay': 0.792895, 'calib_excess': 0.000425, 'kappa_sens': 0.0137, 'kappa_R2': 0.016452, 'D11_agreement': 0.964495, 'S1e_gap_0.75': 0.000707, 'S1e_gap_0.8': 0.000698} 10s
RECHECK C-end 4 {'relay': 0.770687, 'calib_excess': 0.016452, 'kappa_sens': 0.537544, 'kappa_R2': 0.32749, 'D11_agreement': 0.013763, 'S1e_gap_0.75': 0.0228, 'S1e_gap_0.8': 0.024822} 13s
RECHECK B0-am 4 {'relay': 0.78728, 'calib_excess': 0.008575, 'kappa_sens': 1.980511, 'kappa_R2': 0.791167, 'D11_agreement': 0.766987, 'S1e_gap_0.75': 0.012138, 'S1e_gap_0.8': 0.012522} 24s
RECHECK R-vec 4 {'relay': 0.766867, 'calib_excess': 0.019784, 'kappa_sens': 1.208646, 'kappa_R2': 0.659993, 'D11_agreement': 0.012992, 'S1e_gap_0.75': 0.029118, 'S1e_gap_0.8': 0.03314} 11s
RECHECK R-acc 4 {'relay': 0.742888, 'calib_excess': 0.032492, 'kappa_sens': 0.785473, 'kappa_R2': 0.329198, 'D11_agreement': 0.004173, 'S1e_gap_0.75': 0.041778, 'S1e_gap_0.8': 0.041554} 11s
RECHECK IDEAL 4 {'relay': 0.79319, 'calib_excess': 0.000326, 'kappa_sens': 0.0, 'kappa_R2': -0.00205, 'D11_agreement': 0.917204, 'S1e_gap_0.75': 0.000225, 'S1e_gap_0.8': 0.000354}
RECHECK C-sup 5 {'relay': 0.795112, 'calib_excess': 0.000488, 'kappa_sens': 0.013525, 'kappa_R2': 0.007503, 'D11_agreement': 0.941988, 'S1e_gap_0.75': 0.00041, 'S1e_gap_0.8': 0.000686} 10s
RECHECK C-end 5 {'relay': 0.775786, 'calib_excess': 0.01539, 'kappa_sens': 0.541877, 'kappa_R2': 0.328506, 'D11_agreement': 0.059347, 'S1e_gap_0.75': 0.019645, 'S1e_gap_0.8': 0.022404} 14s
RECHECK B0-am 5 {'relay': 0.78885, 'calib_excess': 0.009074, 'kappa_sens': 1.893968, 'kappa_R2': 0.702267, 'D11_agreement': 0.700456, 'S1e_gap_0.75': 0.01164, 'S1e_gap_0.8': 0.014538} 24s
RECHECK R-vec 5 {'relay': 0.769625, 'calib_excess': 0.01971, 'kappa_sens': 1.20932, 'kappa_R2': 0.661597, 'D11_agreement': 0.010722, 'S1e_gap_0.75': 0.025927, 'S1e_gap_0.8': 0.03223} 11s
RECHECK R-acc 5 {'relay': 0.749146, 'calib_excess': 0.030978, 'kappa_sens': 0.773595, 'kappa_R2': 0.327184, 'D11_agreement': 0.007047, 'S1e_gap_0.75': 0.036953, 'S1e_gap_0.8': 0.04126} 11s
RECHECK IDEAL 5 {'relay': 0.79533, 'calib_excess': 0.000321, 'kappa_sens': 0.0, 'kappa_R2': -0.002042, 'D11_agreement': 0.925519, 'S1e_gap_0.75': 0.000363, 'S1e_gap_0.8': 2e-06}
RECHECK C-sup 6 {'relay': 0.796377, 'calib_excess': 0.000436, 'kappa_sens': 0.012017, 'kappa_R2': 0.020049, 'D11_agreement': 0.926862, 'S1e_gap_0.75': 0.000618, 'S1e_gap_0.8': 0.000772} 11s
RECHECK C-end 6 {'relay': 0.772024, 'calib_excess': 0.017088, 'kappa_sens': 0.539804, 'kappa_R2': 0.320954, 'D11_agreement': 0.011894, 'S1e_gap_0.75': 0.021993, 'S1e_gap_0.8': 0.024826} 13s
RECHECK B0-am 6 {'relay': 0.78115, 'calib_excess': 0.011754, 'kappa_sens': 1.87778, 'kappa_R2': 0.8123, 'D11_agreement': 0.409349, 'S1e_gap_0.75': 0.01471, 'S1e_gap_0.8': 0.016304} 25s
RECHECK R-vec 6 {'relay': 0.768398, 'calib_excess': 0.021116, 'kappa_sens': 1.218834, 'kappa_R2': 0.659667, 'D11_agreement': 0.012848, 'S1e_gap_0.75': 0.02856, 'S1e_gap_0.8': 0.033388} 10s
RECHECK R-acc 6 {'relay': 0.747751, 'calib_excess': 0.032322, 'kappa_sens': 0.774079, 'kappa_R2': 0.328872, 'D11_agreement': 0.005171, 'S1e_gap_0.75': 0.039455, 'S1e_gap_0.8': 0.041446} 11s
RECHECK IDEAL 6 {'relay': 0.79698, 'calib_excess': 0.000341, 'kappa_sens': 0.0, 'kappa_R2': -0.00238, 'D11_agreement': 0.922798, 'S1e_gap_0.75': 0.0008, 'S1e_gap_0.8': 0.000408}
RECHECK C-sup 7 {'relay': 0.792702, 'calib_excess': 0.000443, 'kappa_sens': 0.014119, 'kappa_R2': 0.003398, 'D11_agreement': 0.938273, 'S1e_gap_0.75': 0.00068, 'S1e_gap_0.8': 0.000612} 11s
RECHECK C-end 7 {'relay': 0.770058, 'calib_excess': 0.016116, 'kappa_sens': 0.514047, 'kappa_R2': 0.320899, 'D11_agreement': 0.037201, 'S1e_gap_0.75': 0.021102, 'S1e_gap_0.8': 0.023284} 14s
RECHECK B0-am 7 {'relay': 0.78551, 'calib_excess': 0.005414, 'kappa_sens': 1.852958, 'kappa_R2': 0.768368, 'D11_agreement': 0.69913, 'S1e_gap_0.75': 0.00976, 'S1e_gap_0.8': 0.01133} 26s
RECHECK R-vec 7 {'relay': 0.764261, 'calib_excess': 0.021221, 'kappa_sens': 1.212336, 'kappa_R2': 0.660485, 'D11_agreement': 0.008176, 'S1e_gap_0.75': 0.02867, 'S1e_gap_0.8': 0.033322} 10s
RECHECK R-acc 7 {'relay': 0.74669, 'calib_excess': 0.030568, 'kappa_sens': 0.761749, 'kappa_R2': 0.329021, 'D11_agreement': 0.01575, 'S1e_gap_0.75': 0.03875, 'S1e_gap_0.8': 0.039626} 10s
RECHECK IDEAL 7 {'relay': 0.79298, 'calib_excess': 0.00034, 'kappa_sens': 0.0, 'kappa_R2': -0.003276, 'D11_agreement': 0.921473, 'S1e_gap_0.75': 0.000472, 'S1e_gap_0.8': -6.2e-05}
RECHECK C-sup 8 {'relay': 0.792909, 'calib_excess': 0.000435, 'kappa_sens': 0.016781, 'kappa_R2': 0.016992, 'D11_agreement': 0.954349, 'S1e_gap_0.75': 0.000302, 'S1e_gap_0.8': 0.000584} 11s
RECHECK C-end 8 {'relay': 0.769848, 'calib_excess': 0.017123, 'kappa_sens': 0.548381, 'kappa_R2': 0.322972, 'D11_agreement': 0.012586, 'S1e_gap_0.75': 0.022677, 'S1e_gap_0.8': 0.025398} 13s
RECHECK B0-am 8 {'relay': 0.78444, 'calib_excess': 0.008405, 'kappa_sens': 1.92725, 'kappa_R2': 0.868631, 'D11_agreement': 0.608147, 'S1e_gap_0.75': 0.010975, 'S1e_gap_0.8': 0.010582} 25s
RECHECK R-vec 8 {'relay': 0.764447, 'calib_excess': 0.020737, 'kappa_sens': 1.222278, 'kappa_R2': 0.65772, 'D11_agreement': 0.009087, 'S1e_gap_0.75': 0.027337, 'S1e_gap_0.8': 0.032512} 11s
RECHECK R-acc 8 {'relay': 0.743308, 'calib_excess': 0.032966, 'kappa_sens': 0.793188, 'kappa_R2': 0.330179, 'D11_agreement': 0.004915, 'S1e_gap_0.75': 0.040205, 'S1e_gap_0.8': 0.042428} 11s
RECHECK IDEAL 8 {'relay': 0.79271, 'calib_excess': 0.000331, 'kappa_sens': 0.0, 'kappa_R2': -0.002349, 'D11_agreement': 0.916592, 'S1e_gap_0.75': 0.000292, 'S1e_gap_0.8': 0.000352}
RECHECK C-sup 9 {'relay': 0.794128, 'calib_excess': 0.00042, 'kappa_sens': 0.019633, 'kappa_R2': 0.058058, 'D11_agreement': 0.956675, 'S1e_gap_0.75': 0.000758, 'S1e_gap_0.8': 0.00058} 11s
RECHECK C-end 9 {'relay': 0.768515, 'calib_excess': 0.01646, 'kappa_sens': 0.524204, 'kappa_R2': 0.326681, 'D11_agreement': 0.007551, 'S1e_gap_0.75': 0.021603, 'S1e_gap_0.8': 0.023368} 13s
RECHECK B0-am 9 {'relay': 0.79338, 'calib_excess': 0.003442, 'kappa_sens': 2.010947, 'kappa_R2': 0.776332, 'D11_agreement': 0.905955, 'S1e_gap_0.75': 0.00309, 'S1e_gap_0.8': 0.002984} 24s
RECHECK R-vec 9 {'relay': 0.767635, 'calib_excess': 0.019404, 'kappa_sens': 1.195361, 'kappa_R2': 0.65689, 'D11_agreement': 0.015365, 'S1e_gap_0.75': 0.028728, 'S1e_gap_0.8': 0.032616} 11s
RECHECK R-acc 9 {'relay': 0.747657, 'calib_excess': 0.030867, 'kappa_sens': 0.775961, 'kappa_R2': 0.32847, 'D11_agreement': 0.005718, 'S1e_gap_0.75': 0.039403, 'S1e_gap_0.8': 0.042526} 11s
RECHECK IDEAL 9 {'relay': 0.79374, 'calib_excess': 0.000318, 'kappa_sens': 0.0, 'kappa_R2': -0.005421, 'D11_agreement': 0.921193, 'S1e_gap_0.75': 0.000642, 'S1e_gap_0.8': 0.000318}
RECHECK C-sup 10 {'relay': 0.794265, 'calib_excess': 0.000469, 'kappa_sens': 0.013139, 'kappa_R2': 0.025269, 'D11_agreement': 0.944432, 'S1e_gap_0.75': 0.000625, 'S1e_gap_0.8': 0.00053} 11s
RECHECK C-end 10 {'relay': 0.772369, 'calib_excess': 0.015551, 'kappa_sens': 0.536696, 'kappa_R2': 0.322345, 'D11_agreement': 0.071327, 'S1e_gap_0.75': 0.02033, 'S1e_gap_0.8': 0.022308} 12s
RECHECK B0-am 10 {'relay': 0.79409, 'calib_excess': 0.003104, 'kappa_sens': 1.926382, 'kappa_R2': 0.834594, 'D11_agreement': 0.901076, 'S1e_gap_0.75': 0.012622, 'S1e_gap_0.8': 0.00373} 25s
RECHECK R-vec 10 {'relay': 0.767489, 'calib_excess': 0.01997, 'kappa_sens': 1.20611, 'kappa_R2': 0.657672, 'D11_agreement': 0.011104, 'S1e_gap_0.75': 0.027535, 'S1e_gap_0.8': 0.031316} 11s
RECHECK R-acc 10 {'relay': 0.745696, 'calib_excess': 0.031126, 'kappa_sens': 0.76373, 'kappa_R2': 0.329322, 'D11_agreement': 0.008664, 'S1e_gap_0.75': 0.038658, 'S1e_gap_0.8': 0.041182} 11s
RECHECK IDEAL 10 {'relay': 0.79409, 'calib_excess': 0.000341, 'kappa_sens': 0.0, 'kappa_R2': -0.001678, 'D11_agreement': 0.925312, 'S1e_gap_0.75': 0.000247, 'S1e_gap_0.8': 8.2e-05}
THRESHOLDS {
 "thr_cal": 0.002340831924495496,
 "thr_s1e_0.75": 0.002729125000000008,
 "thr_s1e_0.8": 0.0023836999999998537,
 "thr_inv": 0.01840574489857795,
 "thr_ret": 0.09840574489857795,
 "thr_d11": 0.8168672887360647,
 "relay_margin": 0.01299
}
EXPLORATORY pilot-seed adjudication (n=10, not confirmatory):
  H1 inconclusive
  H2 confirmed
  H3 confirmed
