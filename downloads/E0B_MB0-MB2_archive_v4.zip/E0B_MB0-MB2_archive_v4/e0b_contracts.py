#!/usr/bin/env python3
"""E0-B MB0 executable contract table (v2.2).

Every encoder and consumer is declared by the exact variables it observes. Reference values are
computed from those same variables, so no row can silently use an input its contract withholds.

  * An ideal encoder for target Y with declared inputs I emits M = E[Y | I] (exact, by grouping).
    Hence a Q-encoder that is not given kappa *cannot* emit the kappa-dependent Q.
  * A consumer with declared observations J (M plus J) earns the Bayes-optimal value
    sum over groups of max over actions of E[payoff | M, J].
  * Optional stochastic channel: with prob eps, M is replaced by an independent draw from M's marginal.

Core is pure Python (fractions). The RR linear-argmax rows need numpy+scipy and are skipped without them.
Run: python3 e0b_contracts.py   (writes the markdown table to stdout)
"""
from fractions import Fraction as F
from itertools import product
from math import comb

# ---------------------------------------------------------------- U1 (v2.1 affine family) + kappa
P_X, QH, QL, D = F(7, 10), F(19, 20), F(1, 2), F(11, 20)
OS = list(product((0, 1), repeat=2))
FAM = [(w, b) for w in [(0, 1), (1, 0), (1, 1)] for b in (0, 1)]
fval = lambda wb, o: ((wb[0][0] * o[0] + wb[0][1] * o[1]) + wb[1]) % 2
pS1 = P_X * (QH + QL) / 2 + (1 - P_X) * (1 - (QH + QL) / 2)   # P(S=1), T unobserved in traces

def map_bit_dist(k):
    """Exact P(fhat(o) | mapping wb) where fhat is the MAP of f(o) from k i.i.d. report samples at each
    of the 4 inputs (X, N, T unobserved; ties broken uniformly). Returns {(wb, o): P(fhat = 1)}."""
    lik = lambda f, j: pS1 ** j * (1 - pS1) ** (k - j) if f == 0 else (1 - pS1) ** j * pS1 ** (k - j)
    out = {(wb, o): F(0) for wb in FAM for o in OS}
    for js in product(range(k + 1), repeat=4):
        L = {wb: 1 for wb in FAM}
        for wb in FAM:
            for o, j in zip(OS, js): L[wb] *= lik(fval(wb, o), j)
        mult = 1
        for j in js: mult *= comb(k, j)
        for o in OS:
            p1 = sum(L[wb] for wb in FAM if fval(wb, o) == 1); p0 = sum(L[wb] for wb in FAM if fval(wb, o) == 0)
            pick1 = F(1) if p1 > p0 else F(0) if p1 < p0 else F(1, 2)
            for wb in FAM: out[(wb, o)] += mult * L[wb] * pick1
    return out

def map_bit_dist_float(k):
    """Same quantity as map_bit_dist, vectorised in float64 (numpy) for larger k. Values are float-derived."""
    import numpy as np
    from math import lgamma, log
    j = np.arange(k + 1); lc = np.array([lgamma(k + 1) - lgamma(i + 1) - lgamma(k - i + 1) for i in j])
    p = float(pS1)
    ll = {0: j * log(p) + (k - j) * log(1 - p), 1: j * log(1 - p) + (k - j) * log(p)}
    grids = np.meshgrid(j, j, j, j, indexing='ij')
    logL = {wb: sum(ll[fval(wb, o)][grids[i]] for i, o in enumerate(OS)) for wb in FAM}
    lmult = sum(lc[grids[i]] for i in range(4))
    out = {}
    for o in OS:
        a1 = np.logaddexp.reduce([logL[wb] for wb in FAM if fval(wb, o) == 1], axis=0)
        a0 = np.logaddexp.reduce([logL[wb] for wb in FAM if fval(wb, o) == 0], axis=0)
        pick1 = np.where(a1 > a0 + 1e-12, 1.0, np.where(a0 > a1 + 1e-12, 0.0, 0.5))
        for wb in FAM:
            out[(wb, o)] = F(float(np.sum(np.exp(lmult + logL[wb]) * pick1))).limit_denominator(10**9)
    return out

_MB = {}
def states(beta, k=None, theta=lambda a, b: a ^ b):
    if k and k not in _MB:
        try: _MB[k] = map_bit_dist(k) if k <= 10 else map_bit_dist_float(k)
        except ImportError: _MB[k] = map_bit_dist(k)   # exact but slow without numpy
    mb = _MB.get(k) if k else None
    for x, z1, z2, n, o, wb, kap in product((0, 1), (0, 1), (0, 1), (0, 1), OS, FAM, (0, 1)):
        T = theta(z1, z2); q = QH if T == 0 else QL
        pr = (P_X if x else 1 - P_X) * F(1, 4) * ((1 - q) if n else q) * F(1, 4) * F(1, 6) * F(1, 2)
        f = fval(wb, o); r = (x ^ n) ^ f; L = int(r == x)
        base = dict(x=x, z1=z1, z2=z2, T=T, o=o, wb=wb, f=f, r=r, kappa=kap, L=L,
                    acc_pay=L + beta * kap * (r == 0))
        if mb is None:
            yield pr, base
        else:
            p1 = mb[(wb, o)]
            for fh, pf in ((1, p1), (0, 1 - p1)):
                if pf: yield pr * pf, dict(base, fhat=fh)

def encode(S, target, inputs):
    g = {}
    for pr, s in S:
        key = tuple(s[i] for i in inputs); a = g.setdefault(key, [F(0), F(0)]); a[0] += pr; a[1] += pr * s[target]
    return lambda s: g[tuple(s[i] for i in inputs)][1] / g[tuple(s[i] for i in inputs)][0]

PAY = {'accept_consumer': lambda s: {'accept': s['acc_pay'], 'invert': 1 - s['L'], 'defer': D},
       'relay':           lambda s: {'accept': s['L'], 'invert': 1 - s['L'], 'defer': D}}

def consumer_value(S, msg, obs, payoff, eps=F(0)):
    S = list(S); g = {}
    marg = {}
    if msg is not None and eps:
        for pr, s in S: m = msg(s); marg[m] = marg.get(m, 0) + pr
    for pr, s in S:
        pay = PAY[payoff](s); J = tuple(s[i] for i in obs)
        emitted = [(None, 1)] if msg is None else [(msg(s), 1)] if not eps else \
                  [(m, (1 - eps) * (m == msg(s)) + eps * pm) for m, pm in marg.items()]
        for m, w in emitted:
            if not w: continue
            a = g.setdefault((m if msg else None, J), {k: F(0) for k in pay})
            for kk, v in pay.items(): a[kk] += pr * w * v
    return sum(max(a.values()) for a in g.values())

# ---------------------------------------------------------------- contract rows
ENC_BASE = ['o', 'r', 'T', 'f']            # T available via theta access; f is the MAPPING ORACLE (label!)
ENC_TRACE = ['o', 'r', 'T', 'fhat']        # mapping known only through k traces (MAP bit)
def rows(beta, k_trace=10):
    S = list(states(beta)); St = list(states(beta, k=k_trace))
    phi = encode(S, 'L', ENC_BASE); phiK = encode(S, 'L', ENC_BASE + ['kappa'])
    Qk = encode(S, 'acc_pay', ENC_BASE + ['kappa']); Qnok = encode(S, 'acc_pay', ENC_BASE)
    phiT = encode(St, 'L', ENC_TRACE + ['kappa']); QT = encode(St, 'acc_pay', ENC_TRACE + ['kappa'])
    R = []
    add = lambda *a: R.append(a)
    add('C0', 'none', '-', 'relay', 'o,R', consumer_value(S, None, ['o', 'r'], 'relay'))
    add('C1', 'phi[o,R,T,f,kappa]', 'mapping oracle', 'relay', 'M', consumer_value(S, phiK, [], 'relay'))
    add('C2', 'Q[o,R,T,f,kappa]', 'mapping oracle', 'relay', 'M', consumer_value(S, Qk, [], 'relay'))
    add('C3', 'phi[o,R,T,f,kappa]', 'mapping oracle', 'relay', 'M,R', consumer_value(S, phiK, ['r'], 'relay'))
    add('C4', 'Q[o,R,T,f,kappa]', 'mapping oracle', 'relay', 'M,R', consumer_value(S, Qk, ['r'], 'relay'))
    add('C5', 'Q[o,R,T,f] (no kappa: v2.1 contract)', 'mapping oracle', 'relay', 'M', consumer_value(S, Qnok, [], 'relay'))
    add('C6', 'phi[...] via channel eps=1/3', 'mapping oracle', 'relay', 'M', consumer_value(S, phiK, [], 'relay', F(1, 3)))
    add('C7', 'phi[...] via channel eps=1/3', 'mapping oracle', 'relay', 'M,R', consumer_value(S, phiK, ['r'], 'relay', F(1, 3)))
    add('C8', 'Q[...] via channel eps=1/3', 'mapping oracle', 'relay', 'M', consumer_value(S, Qk, [], 'relay', F(1, 3)))
    add('C9', 'Q[...] via channel eps=1/3', 'mapping oracle', 'relay', 'M,R', consumer_value(S, Qk, ['r'], 'relay', F(1, 3)))
    add('C10', 'none (full information)', '-', 'accept_consumer', 'o,R,T,f,kappa', consumer_value(S, None, ['o', 'r', 'T', 'f', 'kappa'], 'accept_consumer'))
    add('C11', 'none (full info, kappa hidden)', '-', 'accept_consumer', 'o,R,T,f', consumer_value(S, None, ['o', 'r', 'T', 'f'], 'accept_consumer'))
    add('C12', f'phi[o,R,T,fhat,kappa]', f'k={k_trace} traces', 'relay', 'M', consumer_value(St, phiT, [], 'relay'))
    add('C13', f'Q[o,R,T,fhat,kappa]', f'k={k_trace} traces', 'relay', 'M', consumer_value(St, QT, [], 'relay'))
    add('C14', f'Q[o,R,T,fhat,kappa]', f'k={k_trace} traces', 'relay', 'M,R', consumer_value(St, QT, ['r'], 'relay'))
    return R, S, phi, Qk, Qnok

def collisions(S, phi, Q):
    """Q collisions at FIXED R with different phi: the condition under which a relay seeing (M,R) cannot recover phi."""
    seen = {}
    for pr, s in S:
        seen.setdefault((s['r'], Q(s)), set()).add(phi(s))
    return {k: sorted(v) for k, v in seen.items() if len(v) > 1}

def rr_rows(k_trace=10):
    try:
        import numpy as np
        from scipy.optimize import linprog
    except ImportError:
        return None
    cells = list(product((0, 1), repeat=3)); A = ['accept', 'invert', 'defer']
    def realizable(pol, fe):
        kk = len(fe(cells[0])) + 1; rws = []
        for cl in cells:
            xv = np.array(list(fe(cl)) + [1.0]); a = A.index(pol[cl])
            for oo in range(3):
                if oo != a:
                    row = np.zeros(3 * kk); row[oo*kk:(oo+1)*kk] = xv; row[a*kk:(a+1)*kk] -= xv; rws.append(row)
        return linprog(np.zeros(3*kk), A_ub=np.array(rws), b_ub=-np.ones(len(rws)), bounds=[(None, None)]*(3*kk), method='highs').status == 0
    def best(S, cond):  # consumer sees (R,Z1,Z2) given the conditioning key; kappa=0 trials (correctness payoff)
        groups = {}
        for pr, s in S:
            if s['kappa'] != 0: continue
            gk = cond(s); cl = (s['r'], s['z1'], s['z2'])
            a = groups.setdefault(gk, {c: [F(0), F(0)] for c in cells})[cl]; a[0] += pr; a[1] += pr * s['L']
        tot_all = {'raw': F(0), 'par': F(0), 'opt': F(0)}; Z = F(0)
        for gk, g in groups.items():
            pay = {c: {'accept': a[1], 'invert': a[0] - a[1], 'defer': D * a[0]} for c, a in g.items()}
            Z += sum(a[0] for a in g.values())
            pols = sorted(product(A, repeat=8), key=lambda t: -sum(pay[c][x] for c, x in zip(cells, t)))
            tot_all['opt'] += sum(pay[c][x] for c, x in zip(cells, pols[0]))
            for nm, fe in (('raw', lambda c: c), ('par', lambda c: (*c, c[1] ^ c[2]))):
                tot_all[nm] += next(sum(pay[c][x] for c, x in zip(cells, t)) for t in pols if realizable(dict(zip(cells, t)), fe))
        return {kk: v / Z for kk, v in tot_all.items()}
    S0 = list(states(F(0))); St = list(states(F(0), k=k_trace))
    return {'mapping oracle (f known)': best(S0, lambda s: (s['o'], s['f'])),
            f'k={k_trace} traces (fhat known)': best(St, lambda s: (s['o'], s['fhat'])),
            'no mapping information': best(S0, lambda s: (s['o'],))}


# ---------------------------------------------------------------- v2.2 Shea discriminator: graded kappa + capacity-limited codes
# In an exact finite fixture, a relay seeing (M, R) inverts any code whose values do not collide at fixed R,
# so exact-collision designs (e.g. beta=189/320) are brittle: they vanish once phi is estimated from traces.
# Collisions become generic when kappa is graded AND each code is capacity-limited (L bins). The rival is
# given its own optimal contiguous L-bin quantizer (optimised for the acceptance consumer, which sees M,R,kappa).
def states_grid(beta, K, k=None):
    base = list(states(F(0), k=k))
    for pr, s in base:
        if s['kappa'] != 0: continue          # drop binary kappa; re-expand on a grid
        for i in range(K + 1):
            kap = F(i, K)
            yield pr * 2 * F(1, K + 1), dict(s, kappa=kap, acc_pay=s['L'] + beta * kap * (s['r'] == 0))

def opt_quant(S, fn, obs, payoff, L):
    vals = sorted({fn(s) for _, s in S}); n = len(vals); idx = {v: i for i, v in enumerate(vals)}
    # per-value, per-J payoff sums
    from collections import defaultdict
    tab = [defaultdict(lambda: None) for _ in range(n)]
    for pr, s in S:
        pay = PAY[payoff](s); J = tuple(s[i] for i in obs); t = tab[idx[fn(s)]]
        if t[J] is None: t[J] = {k: F(0) for k in pay}
        for k2, v in pay.items(): t[J][k2] += pr * v
    def binval(i, j):
        acc = {}
        for t in tab[i:j]:
            for J, d in t.items():
                a = acc.setdefault(J, {k: F(0) for k in d})
                for k2, v in d.items(): a[k2] += v
        return sum(max(a.values()) for a in acc.values())
    bv = {(i, j): binval(i, j) for i in range(n) for j in range(i + 1, n + 1)}
    best = [[None] * (n + 1) for _ in range(L + 1)]; cut = [[None] * (n + 1) for _ in range(L + 1)]
    best[0][0] = F(0)
    for l in range(1, L + 1):
        for j in range(1, n + 1):
            for i in range(j):
                if best[l - 1][i] is None: continue
                v = best[l - 1][i] + bv[(i, j)]
                if best[l][j] is None or v > best[l][j]: best[l][j], cut[l][j] = v, i
    lv = max(range(1, L + 1), key=lambda l: best[l][n] if best[l][n] is not None else -1)
    edges = []; j = n; l = lv
    while l > 0: i = cut[l][j]; edges.append((i, j)); j = i; l -= 1
    binof = {}
    for b, (i, j) in enumerate(sorted(edges)):
        for v in vals[i:j]: binof[v] = b
    return (lambda s: binof[fn(s)]), best[lv][n]

if __name__ == '__main__':
    fmt = lambda v: f"{float(v):.6f}"
    for beta, label in ((F(2, 5), 'beta = 2/5 (v2.1)'), (F(189, 320), 'beta = 189/320 (fixed-R collision, v2.2)')):
        R, S, phi, Qk, Qnok = rows(beta)
        print(f"\n### Contract table — {label}\n")
        print("| id | encoder [declared inputs] | mapping access | consumer | consumer observes | value |")
        print("|---|---|---|---|---|---|")
        for r in R: print(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} | {r[4]} | {fmt(r[5])} |")
        col = collisions(S, phi, Qk)
        print(f"\nFixed-R Q collisions with different phi: {({k: [str(x) for x in v] for k, v in col.items()}) or 'none'}")
        # the v2.1 encoder-contract defect, shown directly
        s0 = next(s for _, s in S if s['r'] == 0 and s['T'] == 1 and s['f'] == 0)
        print(f"R=0,T=1,f=0: phi = {phi(s0)};  Q with kappa = {Qk(dict(s0, kappa=0))} / {Qk(dict(s0, kappa=1))};"
              f"  'Q' encoder without kappa emits {Qnok(s0)} for both")
    print("\nFalse-fail, m clauses at alpha=0.05: independence 1-(0.95)^m vs union bound m*alpha")
    for m in (3, 6, 10): print(f"  m={m}: {1-0.95**m:.3f} (independent)  {min(1, 0.05*m):.2f} (no dependence assumption)")
    print("\n### Trace-budget sweep (mapping known only through k traces per input; beta = 189/320)\n")
    print("| k | P(fhat=f) | relay: phi code, M | relay: Q code, M | relay: Q code, M+R | phi minus Q (M+R) | RR gap (linear+parity minus linear) |")
    print("|---|---|---|---|---|---|---|")
    B = F(189, 320); rrk = None
    for k in (10, 20, 40, 80):
        St = list(states(B, k=k))
        acc = sum(pr for pr, s_ in St if s_['fhat'] == s_['f'])
        ph = encode(St, 'L', ENC_TRACE + ['kappa']); qq = encode(St, 'acc_pay', ENC_TRACE + ['kappa'])
        a = consumer_value(St, ph, [], 'relay'); b = consumer_value(St, qq, [], 'relay'); c = consumer_value(St, qq, ['r'], 'relay')
        rrk = rr_rows(k)
        g = fmt(rrk[f'k={k} traces (fhat known)']['par'] - rrk[f'k={k} traces (fhat known)']['raw']) if rrk else 'n/a'
        print(f"| {k} | {float(acc):.4f} | {fmt(a)} | {fmt(b)} | {fmt(c)} | {fmt(a - c)} | {g} |")
    print("\n### Shea discriminator under capacity limits (kappa uniform on {0,1/8,...,1}, beta = 1; relay observes M and R)\n")
    print("| mapping access | L bins | relay: phi code (own-optimal) | relay: Q code (own-optimal) | gap | Q code on its own consumer |")
    print("|---|---|---|---|---|---|")
    for kk in (None, 40):
        S = list(states_grid(F(1), 8, kk)); enc = ENC_BASE if kk is None else ENC_TRACE
        ph = encode(S, 'L', enc + ['kappa']); qq = encode(S, 'acc_pay', enc + ['kappa'])
        for L in (2, 4):
            qopt, own = opt_quant(S, qq, ['r', 'kappa'], 'accept_consumer', L); popt, _ = opt_quant(S, ph, ['r'], 'relay', L)
            a = consumer_value(S, popt, ['r'], 'relay'); b = consumer_value(S, qopt, ['r'], 'relay')
            print(f"| {'mapping oracle' if kk is None else f'k={kk} traces'} | {L} | {fmt(a)} | {fmt(b)} | {fmt(a-b)} | {fmt(own)} |")
        b_un = consumer_value(S, qq, ['r'], 'relay'); a_un = consumer_value(S, ph, ['r'], 'relay')
        print(f"| {'mapping oracle' if kk is None else f'k={kk} traces'} | unlimited | {fmt(a_un)} | {fmt(b_un)} | {fmt(a_un-b_un)} | - |")
    rr = rr_rows()
    print("\n### RR accessibility (kappa=0 trials, linear-argmax over (R,Z1,Z2)); consumer conditioned on the stated mapping access\n")
    if rr is None:
        print("skipped: numpy/scipy unavailable")
    else:
        print("| mapping access | linear raw | linear + parity | unrestricted | gap |")
        print("|---|---|---|---|---|")
        for k, v in rr.items():
            print(f"| {k} | {fmt(v['raw'])} | {fmt(v['par'])} | {fmt(v['opt'])} | {fmt(v['par'] - v['raw'])} |")
