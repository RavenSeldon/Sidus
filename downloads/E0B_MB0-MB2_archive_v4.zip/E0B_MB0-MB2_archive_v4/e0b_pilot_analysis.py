#!/usr/bin/env python3
"""Apply the pre-specified derivation rules of E0B_Pilot_Protocol_P0.md to the pilot results (no new choices)."""
import json, numpy as np
R = json.load(open('pilot_shea_results.json')); PR = json.load(open('pilot_process_results.json'))
seeds = range(1, 11)
get = lambda sysn, key: np.array([R[f'{sysn}|{s}'][key] for s in seeds])
best_rival = lambda key, higher: (np.maximum if higher else np.minimum)(get('R-vec', key), get('R-acc', key))
print("# Pilot P0 analysis (pre-specified rules)\n\n## Per-system summaries (median [min, max] over 10 pilot seeds)\n")
print("| system | E1 relay | E2 calib excess | E3 kappa-sens | E4 D11 agreement | E5 S1e gap 0.75 | E5 S1e gap 0.80 |")
print("|---|---|---|---|---|---|---|")
keys = ['E1_relay', 'E2_calib_excess', 'E3_kappa_sens', 'E4_D11_agreement', 'E5_S1e_gap_0.75', 'E5_S1e_gap_0.8']
for sysn in ('C-end', 'C-sup', 'B0-am', 'R-vec', 'R-acc'):
    cells = []
    for k in keys:
        v = get(sysn, k); cells.append(f"{np.median(v):.4f} [{v.min():.4f}, {v.max():.4f}]")
    print(f"| {sysn} | " + " | ".join(cells) + " |")
ideal = get('C-end', 'ideal_relay'); print(f"\nideal phi_post relay (same test sets): median {np.median(ideal):.4f}")
print("\n## Direction-adjusted effects vs the best rival (paired by seed) and the pre-specified margin rule\n")
print("| candidate | measure | effect median | 10th percentile | margin (half of P10) | status |")
print("|---|---|---|---|---|---|")
spec = [('E1_relay', True), ('E2_calib_excess', False), ('E3_kappa_sens', False), ('E4_D11_agreement', True), ('E5_S1e_gap_0.75', False), ('E5_S1e_gap_0.8', False)]
margins = {}
for cand in ('C-end', 'C-sup', 'B0-am'):
    for k, higher in spec:
        eff = (get(cand, k) - best_rival(k, True)) if higher else (best_rival(k, False) - get(cand, k))
        p10 = np.percentile(eff, 10)
        status = 'positive margin defensible' if p10 > 0 else 'NOT reliably achieved at pilot scale'
        if cand == 'C-end': margins[k] = p10 / 2 if p10 > 0 else None
        print(f"| {cand} | {k} | {np.median(eff):+.5f} | {p10:+.5f} | {(p10 / 2 if p10 > 0 else float('nan')):+.5f} | {status} |")
print("\n## Optimization reliability (relay >= 95% of ideal relay on the same test set)\n")
for sysn in ('C-end', 'C-sup', 'B0-am', 'R-vec', 'R-acc'):
    ok = (get(sysn, 'E1_relay') >= 0.95 * ideal).sum(); print(f"- {sysn}: {ok}/10")
# block budget for the primary contrast (E1, T-end candidate) per the pre-specified rule
print("\n## Block budget (pre-specified rule: primary contrast E1, T-end candidate)\n")
if margins['E1_relay'] is None:
    print("- E1 10th-percentile effect is not positive: no block budget can be derived for the T-end candidate under the rule.")
else:
    d = []
    for s in seeds:
        c = np.load(f'pilot_trials_C-end_{s}.npy')[0]
        rv = np.load(f'pilot_trials_R-vec_{s}.npy')[0]; ra = np.load(f'pilot_trials_R-acc_{s}.npy')[0]
        r = rv if rv.mean() >= ra.mean() else ra
        d.append(c - r)
    d = np.concatenate(d); mu = d.mean(); sw2 = d.var()
    print(f"- pooled per-trial paired difference: mean {mu:.5f}, var {sw2:.5f}; margin {margins['E1_relay']:.5f}")
    zq, zb = 2.1280452788, 1.2815515655
    for bs in (20, 50, 100, 200):
        eff = mu - margins['E1_relay']
        N = int(np.ceil((zq + zb) ** 2 * (sw2 / bs) / eff ** 2)) if eff > 0 else None
        if N is not None and N < 30: N += 3
        print(f"  - B_score {bs}: N blocks = {N} (between-block variance not separable in the pilot design; see note)")
print("\n## Process arm (k_p = 20; held-out identities)\n")
print(f"- identity-blind Bayes bound (MC): {PR['bayes_identity_blind_heldout']:.4f}")
for kind in ('P-struct', 'P-cell-lin', 'P-cell-mlp'):
    v = np.array([PR[f'{kind}|{s}'] for s in seeds]); print(f"- {kind}: median {np.median(v):.4f} [{v.min():.4f}, {v.max():.4f}]")
