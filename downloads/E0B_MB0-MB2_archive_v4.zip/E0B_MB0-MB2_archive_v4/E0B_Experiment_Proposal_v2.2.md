# Sīdus E0-B — Definition-Indexed Discrimination Experiment (v2.2)

**Development specification · 8 October 2026 · status: NOT frozen; no operationalization is validated; the Shea discriminator is explicitly NOT validated; authorized scope is MB0–MB2 only**

> **v2.2 note.** v2.2 is v2.1 plus the corrections in Appendix C, which answer the third external review (two access-contract defects in the S1h repair, plus labelling and statistics corrections). v2.1 is kept unchanged as the record. Every value in this version comes from **`e0b_contracts.py`**. That script declares, for each encoder and consumer, exactly which variables it observes, and computes every reference value from those same variables. Its output is `E0B_MB0_Contract_Table.md`. The contract table **precedes** any interpretation of S1h and any margin setting.

v2.1 replaced v2 as the working account (the v2.1 text below is kept; v2.2 changes are marked **[R2.2]**). v2 and its review are kept unchanged as the record. v2.1 answers the second external review of v2. That review confirmed the v2 arithmetic and found five substantive defects plus three matters to settle before freezing. All eight were checked independently and **all are upheld** (`e0b_reference.py`, Part C). One further defect was found during the repair (D8 confounds access with organization; see §4.2).

**Labels:** [SRC] source requirement · [OPS] operational choice · [FRZ] decision to freeze · [REF] exact reference value under stated assumptions, not a trained-system result · **[R2.1]** change in this version.

---

## 0. Claim boundary and scope

E0-B asks whether a synthetic experiment can distinguish a candidate property/process metarepresentation from simpler alternatives under explicitly stated operational criteria [SRC]. It is definition-indexed: **E0-B[Shea], E0-B[RR], E0-B[Process]**, all evaluated on one shared fixture (U1) [SRC + v2].

**[R2.1] Scope relative to the programme.** E0-B is a separately scoped investigation. It is **not a gate on E1**. The project record holds that E0-A met the E1 prerequisite, and the external reviewer reads Document IV's scope and decision rule the same way. (Document IV's live text was not re-read for this revision.) E0-B therefore runs at development pace and must not delay E1 scarcity work.

**[R2.1] What E0-B can at most conclude.** E0-B tests which **functional distinctions** are present and which simpler rivals they defeat. Which representational interpretation those distinctions warrant is a separate, argued step [FRZ interpretation decision]. Reproducing the arithmetic does not settle it. Where the rival interpretations of §4 cannot be separated, the narrower functional finding is reported, e.g. *causally used token-correctness monitoring under this operationalization*.

No outcome licenses *strict metarepresentation*, *consciousness* or *natural kind*, and none addresses C5 novelty [SRC].

---

## 1. Decision structure

| Axis | Values |
|---|---|
| `readiness` | `proposal` → `validated_operationalization` → `frozen_for_confirmation` |
| `outcome` | `not_evaluated` → `pass` / `fail` / `inconclusive(reason)` |

**[R2.1] `inconclusive` always carries a reason code.** Only one of the codes refers to power:
- `underpowered` — the interval straddles the margin and more data could resolve it;
- `non_identified` — the permitted observations do not identify the target (e.g. version-space ambiguity);
- `invalid_support` — eligibility, overlap or preservation evidence fails;
- `operational_equivalence` — candidate and rival make identical predictions under every registered intervention;
- `empty_clause_set`.

**Global outcomes:**
1. **Conjunctive pass.** One system passes all three frozen indices. Reported as conjoint satisfaction only. W7 (three independent modules) shows this is achievable without unified organization.
2. **Unified fail.** Every index fails or is matched by a declared rival.
3. **Split.** Index *i* = `pass` and index *j* = established `fail`, with the fail declaration subject to the false-fail control in §8. Pass/`inconclusive(any reason)` is not a split and is reported with its reason code.
4. **Equivalence.** Reported as `inconclusive(operational_equivalence)`, with the witness.
5. **[R2.1] Panel description, no unity verdict.** The learned panel is analysed descriptively: the overlap pattern of index passes, reproducible dissociations, and shared failure modes (capacity, optimization, threshold effects). **No "unified/disunified" verdict is issued.** The v2 rules could classify one population both ways. Example [REF, C5]: half of systems pass all three, a quarter pass Shea only, a quarter fail all three. Every pairwise association is positive, *and* splits recur. Independent modules also need not yield independent pass indicators. A unity verdict is deferred until competing explanations of association (shared capacity, training difficulty, optimization success, common thresholds) are specified with a model that separates them from the construct.

---

## 2. Architecture panel, data contracts, training arms

| System | Permitted data | Role |
|---|---|---|
| **B0-public** | \(o\), \(R\), declared output history | shortcut |
| **B0-access-matched** | everything B2 receives, matched compute | control **and** scored candidate |
| **B1-scalar** | B2's telemetry reduced to one scalar | simple monitor |
| **B1-action-value** [R2.1, R2.2] | same inputs as B2 **including κ**; trained to predict the acceptance consumer's expected payoff | **rival interpretation for Shea** |
| **B1-process-state** | per-cell tracker / training-identity classifier | non-structural process alternative |
| **B2-candidate** | see the trace contract below | registered target per index |
| **B-oracle** | exact \(\varphi\), \(T\), \(f\) | feasibility only |

**[R2.1] Trace and parameter contract.** This resolves the v2 conflict between "procedure-parameter access" and the prohibition on supplying process identity.
- B2 and B0-access-matched may read the **regime procedure's** parameters \(\theta\) (the lookup \(h_\theta\) over \((Z_1, Z_2)\)) and \(Z_1, Z_2\).
- They may **never** read the mapping parameters \((w, b)\).
- Process information arrives only through **traces**. A trace is one report sample \(R\) at a public input \(o\). \(X\), \(N\) and \(T\) are unobserved, samples are i.i.d. within a block, and there are \(k\) per observed cell. Ties are broken uniformly at random.

**Training arms (kept from v2).** *T-sup* supervises the meta-target and is an engineering check only. *T-end* trains on consumer reward only and carries the scientific claim.

**[R2.1] Consumer ladder, qualified.** Representational capacity fixes the optimal value achievable at each rung, so equal optima are established by exact computation. A trained model need not reach its optimum. A persistent learned gap at a rung whose optimum equals the next rung's is reported as an **optimization gap**, not as a software bug, unless the exact-reference check also fails.

---

## 3. Unified fixture U1 (revised)

**Generative model.**
- \(X \sim \mathrm{Bern}(7/10)\).
- \(Z_1, Z_2\) fair. Regime \(T = h_\theta(Z_1, Z_2)\), by default XOR, implemented as a lookup.
- \(N \sim \mathrm{Bern}(1 - q_T)\) with \(q_0 = 19/20\) and \(q_1 = 1/2\). \(S = X \oplus N\).
- Public \(o \in \{0,1\}^2\), uniform.
- **[R2.1] Process family: affine and reliability-matched.** \(f_{w,b}(o) = w \cdot o \oplus b\) with \(w \in \{01, 10, 11\}\) and \(b \in \{0, 1\}\), giving 6 mappings with a uniform prior. Every mapping inverts exactly half the inputs, so aggregate accuracy is 1/2 for all of them [REF]. The held-out label \(f(11)\) is balanced at 1/2 under the prior [REF].
- \(R = S \oplus f(o)\).

**Consumers.**
- **Acceptance consumer:** accept (pays \(\mathbb 1[R=X] + \beta\,\kappa\,\mathbb 1[R=0]\)) / invert (pays \(\mathbb 1[R \neq X]\)) / defer (pays \(d = 11/20\)).
- ~~[R2.1] Payoff context κ ∈ {0,1}, visible only to the acceptance consumer, β = 2/5.~~ **Superseded [R2.2].** The B1-action-value encoder could not compute Q without κ: at \(R=0, T=1, f=0\) a κ-blind "Q" encoder emits 1/2 for both κ values while the true Q is 0.3 / 0.7, so κ-invariance would have been trivial.
- **[R2.2] Payoff context.** \(\kappa\) is uniform on \(\{0, 1/8, \dots, 1\}\) with bonus \(\beta\kappa\) (\(\beta = 1\)) for accepting when \(R=0\). κ is visible to **both competing encoders** and to the acceptance consumer, and hidden from the relay. κ-invariance is therefore something a correctness code must show *despite having access*.
- **[R2.2] Capacity-limited codes.** Each competing code is an \(L\)-bin code (\(L \in \{2, 4\}\) [FRZ]). Each uses **its own optimal contiguous quantizer**, optimised for its own consumer: the Q code for the acceptance consumer (sees M, R, κ), the φ code for the relay.
- **[R2.1, R2.2] Relay consumer:** paid on correctness only (same actions, no bonus). It observes **M and the public report R**, never κ. The v2.1 relay value (0.775) held only for an M-only relay. Once R is visible, Q together with R identifies φ exactly in the finite fixture (0.825 = 0.825).

**Targets.**
- Shea: \(\varphi_t = P(R_t = X_t \mid R_t, o_t, T_t, f)\).
- Action-value rival: \(Q_t = \mathbb E[\text{acceptance payoff} \mid R_t, o_t, T_t, f, \kappa_t] = \varphi_t + \beta\,\kappa_t\,\mathbb 1[R_t = 0]\).
- RR: \(T\).
- Process: \(f\) at held-out inputs and identities.

**Reference values [REF]** (the v2 process rows are superseded). **[R2.2]** Every row must state consumer, inputs, payoff condition and mapping access; `e0b_contracts.py` is authoritative and the rows below are amended accordingly:

| Quantity | Value |
|---|---|
| B0-public \((o,R)\) / regime only \((o,R,T)\) / process only \((o,R,f)\) | 0.7000 / 0.7000 / 0.7330 (affine family; v2's linear family gave 0.7083 / 0.7312 / 0.7330) |
| \((o, R, T, f)\), relay / correctness-only payoff, mapping oracle | **0.8250** |
| acceptance consumer with the binary-κ bonus (β = 2/5), full information incl. κ [R2.2] | 0.8410 |
| ~~"token advantage" 0.075 over \((o,T,f)\)~~ | **withdrawn**: that comparator withheld \(R\). A regime+process monitor whose consumer also sees \(R\) reaches 0.825 [C2a] |
| \(\varphi = \mathbb E[\text{accept payoff}]\) at \(\kappa = 0\), every cell | identity holds [C2a] |
| matched-Q / different-φ pair: \((T{=}1, f{=}0, R{=}1, \kappa{=}0)\) vs \((T{=}1, f{=}0, R{=}0, \kappa{=}1)\) | φ 0.7 vs 0.3; Q 0.7 vs 0.7 |
| matched-φ / different-Q pair: second cell at \(\kappa = 0\) vs 1 | φ 0.3 both; Q 0.3 vs 0.7 |
| ~~relay reading a φ code / a Q code: 0.825 / 0.775~~ | **[R2.2] M-only relay only.** With R visible: 0.825 / 0.825 (no separation) |
| **[R2.2]** relay (M, R), graded κ, own-optimal L=4 codes, mapping oracle: φ code / Q code | **0.8250 / 0.7691** (gap 0.0559) |
| **[R2.2]** same, mapping from k=40 traces | **0.7895 / 0.7459** (gap 0.0436) |
| **[R2.2]** same with unlimited code capacity | 0.825 / 0.825 (no separation: the discriminator is capacity-relative) |
| D7 token transplant action-change mass (token code / regime code) | 1/2 / 0 |
| prior shift 7/10→1/2, frozen M: misrepresentation mass | 1/2 |
| linear decode of \(T\) from raw \((Z_1, Z_2)\) | **3/4** (not chance) [C1] |
| RR, **mapping-oracle subproblem**: linear-argmax over raw \((R, Z_1, Z_2)\) / + parity / unrestricted | 0.80625 / 0.825 / 0.825 |
| **[R2.2]** RR gap when the mapping is known only from k traces: k = 10 / 20 / 40 / 80 | 0.0020 / 0.0078 / 0.0180 / 0.0188 |
| \(T\) from W5's scalar φ: interval decoder / best single threshold | 1 / 3/4 [C3] |
| D8 rewiring: θ-using code / θ-ignoring parity code | 0.825 / 0.7125 |
| held-out \(f(11)\) from \(k\) traces at 00, 01, 10: exact Bayes, k = 5/10/20/40 | 0.596 / 0.637 / 0.701 / 0.794 |
| prior-optimal (no traces) and per-cell tracker at \(f(11)\) | 0.5 and 0.5 |
| token-φ value through a stochastic channel, **relay observing M only**, ε = 0 / 0.1 / 0.2 / 1/3 | 0.825 / 0.7925 / 0.760 / 0.717 |
| **[R2.2]** same at ε = 1/3, relay observing M and R | 0.7727 |

**Record of the v2 process figures [C4a].** Under v2's family \(\{01, 10, 11\}\), \(f(11)\) was 1, 1, 0. "Always answer 1" scored 2/3, so v2's plug-in 0.667 at \(k = 20\) was at baseline (exact Bayes 0.770). The affine family removes the imbalance.

**[R2.1] Noiseless vs achievable.** Every value above is noiseless unless an ε is stated. Primary interventions use stochastic channels with overlapping support, and the achievable gap shrinks with ε: at ε = 1/3 the token-φ value (0.717) is barely above B0-public (0.700) **for an M-only relay; a relay that also keeps R reaches 0.773 [R2.2]**. Margins (§10) are set against the **achievable values under the registered channel**, never against the noiseless table.

---

## 4. Index-specific predicates

### 4.1 E0-B[Shea]

**Rival interpretations that must be separated before any Shea reading** [R2.1]:
- (i) token-correctness content \(\varphi\);
- (ii) first-order action-value content \(Q\) — the probability-of-reward reading;
- (iii) an encoded policy bit.

This follows the method of Shea (2014, *Noûs* 48(2), §5.3). There, first-order payoff readings are considered as alternatives, and content is fixed by what explains the signal's downstream use.

- **S1a calibration** against \(\varphi\) and against \(L\) (kept).
- **S1b selective tracking**, MU-1/MU-2 (kept).
- **S1c consumer causality**, MU-3 (kept).
- **S1d token locus (D7).** Kept, with its claim narrowed. D7 shows *where* token content sits (in M, not computed by the consumer from \(R\)). It does not show M's content is correctness rather than action value: both are token-dependent.
- **S1e graded content (D10).** Kept, narrowed to rival (iii). A held-out \(d'\) separates graded content from a policy bit. It does **not** separate φ from Q, because changing \(d'\) leaves \(\varphi = Q\) at \(\kappa = 0\).
- **[R2.1] S1h correctness vs action value (D11, MU-13).** Run a factorial over correctness and acceptance payoff using the matched pairs in §3.
  - Under (i), M separates matched-Q/different-φ pairs and stays fixed across matched-φ/different-Q pairs.
  - Under (ii), the reverse.
  - ~~The relay consumer, which does not see κ, must retain value when reading M: reference 0.825 vs 0.775.~~ **[R2.2]** Under the corrected contract the relay sees M and R but not κ; both encoders see κ; each code is capacity-limited with its own-optimal quantizer. Reference: 0.825 vs 0.769 (mapping oracle) and 0.790 vs 0.746 (k = 40 traces).
  - B1-action-value is the matched rival.
  - **[R2.2] Brittleness record.** A fixed-R exact collision (binary κ, β = 189/320) separates codes at the oracle (0.825 vs 0.794) but **vanishes completely under trace estimation** at every k tested (10–80), because estimated φ values no longer coincide. Exact-coincidence designs are therefore not used. Generic collisions come from graded κ with finite code capacity.
- **S1f endogenous misrepresentation** (kept).
- **S1g simpler explanations:** B1-scalar, W1 and now B1-action-value.

**Residual [R2.1, R2.2].** With unlimited code capacity, (M, R) recovers φ from a Q code and S1h returns equivalence. The discriminator is **capacity-relative**, and this is stated as a scope condition, not hidden. If M carries φ and κ separably, or the relay consumer can see κ, S1h cannot discriminate and returns `inconclusive(operational_equivalence)`. Then report the narrower finding. "One scalar channel" cannot define the simpler alternative, because φ is itself a scalar.

### 4.2 E0-B[RR]

- **[R2.1] RR1a implicitness, consumer-relative.** v2 required a linear probe "at chance" on \(T = Z_1 \oplus Z_2\). That requirement **rejected its own fixture**: the best linear threshold scores 3/4 [C1]. Implicitness is now defined relative to the declared primary consumer class. The exact optimum without M must be strictly below the exact optimum with M (0.80625 < 0.825), and the redescription's improvement is reported as that difference. Linear *non-separability*, not linear *unpredictability*, is what the fixture supplies.
- **RR1b accessibility gain** over the consumer ladder, with the §2 qualification on trained gaps.
- **[R2.1] RR1c procedure coupling (D8), access-matched.** In v2, the procedure-coupled code read θ and the parity comparator did not, so D8 tested a **data-access difference, not organization** (found during this revision). Now every comparator, W2 included, receives θ. D8 asks whether M's dependence on θ is what preserves consumer value after rewiring: 0.825 for a θ-using code vs 0.7125 for a θ-ignoring one. Feedback stays withheld.
- **RR1d–f** (selective use, matched transformations, code relabelling) are kept.

### 4.3 E0-B[Process]

- **[R2.1] P1a held-out input.** Traces at \(o \in \{00, 01, 10\}\) with \(k\) per cell; query \(f(11)\). The evaluation population is all 6 mappings with equal weight, and the label is balanced at 1/2. Comparators: the **prior-optimal predictor** (0.5), the per-cell tracker (0.5), and the **exact trace-conditioned Bayes bound** (§3 table). Loss is reported as a fraction of the Bayes-minus-prior gap.
- **[R2.1] P1b held-out identity.** Train on 4 mappings, test on the remaining 2. Choose the held-out pair so that \(f(11)\) stays balanced within the test set, e.g. \(\{(11,0), (01,0)\}\), which gives labels 0 and 1. Fix the split [FRZ].
- **P1c–e** (functional specificity, consumer causality, misrepresentation vs ambiguity) are kept. Insufficient traces → `inconclusive(non_identified)`.
- W3 remains the expected positive case, not a counterexample.

---

## 5. Discriminator battery

D1–D10 are kept. **[R2.1] D11** is the correctness × acceptance-payoff factorial (S1h). Each discriminator records its eligible pairs, kernel, support, channel ε, and predicted sign **under each rival interpretation**, not only under the construct.

---

## 6. Witness panel — executed matrix before any gate [R2.1]

The v2 gate ("W1, W3, W5 each pass exactly their own index") is **withdrawn**. Distinct criteria may legitimately overlap. A witness passing two indices does not show the indices are non-discriminating, and v2's stated reason for W5 failing RR ("no accessible T code") is false: T is perfectly interval-decodable from φ, and 3/4 linearly decodable [C3].

**Procedure.**
1. Execute the complete witness × predicate matrix (W1–W7 plus B1-action-value) at exact scope, under each registered decoder, consumer rung and channel ε.
2. Record every cell, predicted and observed.
3. Treat an unexpected cross-pass as a **finding to diagnose**, including the possibility that the witness prediction was wrong. Keep the record, then correct the specification.

**Revised gate to `validated_operationalization` (per index):**
- (a) at least one constructed system passes the index while another constructed system fails it *for the reason the index names*;
- (b) every declared rival for that index is either defeated or recorded as `operational_equivalence`;
- (c) the executed matrix is archived.

Exclusivity across indices is not required.

---

## 7. Manipulation register

MU-1 to MU-12 are kept. MU-12 now uses the affine family and the balanced held-out split. **[R2.1] MU-13:** a κ manipulation that crosses payoff with correctness, using matched-Q and matched-φ pairs, with κ hidden from the relay consumer.

---

## 8. Estimands, tiers, uncertainty, decision algebra

Tiers and estimands are as in v2, with additions: S1h dissociation (matched-pair M differences), relay retention, and Bayes-gap fraction (Process).

**Decision algebra:**
- **Superiority:** pass / fail / `inconclusive(reason)`.
- **Equivalence:** TOST.
- **[R2.1] False-fail control.** The intersection–union argument protects a conjunctive **pass**. It does not protect a **fail** chosen from whichever of *m* clauses fails first. False-fail rates at α = 0.05 are 0.143, 0.265 and 0.401 for *m* = 3, 6 and 10 **under independence**. Without dependence assumptions the union bound gives 0.15, 0.30 and 0.50 **[R2.2 correction: v2.1 called the independence figures "worst-case"]** [C6]. An index-level `fail` therefore requires either a single preregistered primary failure clause at α, or Holm control across that index's failure tests. Split declarations (§1.3) inherit this.
- **Across reported vector entries:** Holm (kept).

---

## 9. Outcome reporting

As in v2, plus the following.
- Every `inconclusive` carries its reason code.
- Every result carries its channel ε and consumer rung.
- Shea results state which rival interpretations were defeated.
- Panel results are descriptive only (§1.5).

---

## 10. Freeze register [FRZ] — additions

- β, the κ distribution and κ's visibility per consumer.
- The matched-pair sets for D11.
- Relay-consumer specification.
- Affine-family held-out identity split.
- Trace budget \(k\), justified against the Bayes table. At k = 20 even the Bayes-optimal predictor reaches only 0.701, i.e. 40% of the distance from the prior (0.5) to certainty; confirmatory use probably needs k ≥ 40.
- **Registered channel ε per intervention**, with margins set below the achievable gap at that ε.
- The primary failure clause per index, or the Holm family.
- The interpretation decision mapping functional findings to content attributions.

---

## 11. Limitations — additions

1. **Rival interpretations may be operationally equivalent** on any finite fixture. Then E0-B reports the functional finding without the representational reading. This is an expected outcome, not a failure.
2. **Payoff decoupling presupposes κ's visibility contract.** If the contract is relaxed, S1h collapses to equivalence.
3. **The achievable effects are small.** Token-φ value is close to public at ε = 1/3, and the RR gap is 0.019 noiseless. Underpowered outcomes are likely and will be labelled as such.
4. **Construct unity is out of scope** until a model of shared-cause association exists.

---

## 12. Milestones and stop conditions

**Authorized now: MB0–MB2 only.** Larger learned panels wait until MB2 passes.

| Id | Deliverable | Exit artifact |
|---|---|---|
| MB0 | U1 (affine family, κ, relay), sub-fixtures, W1–W7 and B1-action-value executable; `e0b_reference.py` in CI | exact tables, including channel-ε tables |
| MB1 | consumer-relative implicitness; access-matched contracts; consumer ladder with optimization-gap accounting | contract and comparator tables |
| MB2 | **executed witness × predicate matrix**; D1–D11 feasibility; rival-interpretation predictions per discriminator | archived matrix, diagnosed cross-passes, revised spec |
| MB3+ | as v2, conditional on MB2 | — |

**Stop / revise conditions [R2.1]:**
- A designated negative witness passes a complete frozen predicate → stop.
- An unexpected cross-pass by a positive witness → **diagnose and revise**, not stop.
- Every Shea rival is operationally equivalent on U1 → narrow the Shea claim; do not proceed to a learned Shea panel.
- Support or preservation cannot be made valid → stop.

---

## Appendix B — v2 → v2.1 change ledger

| # | Finding (second external review) | Verified | Repair | Residual |
|---|---|---|---|---|
| 1 | RR1a "chance" contradicts XOR (3/4 linearly) | ✔ C1 | consumer-relative implicitness; ladder optima ≠ trained optima | none known |
| 2 | φ = expected accept payoff; 0.750 comparator withheld R | ✔ C2a | B1-action-value; κ factorial D11; relay 0.825 vs 0.775; 0.075 claim withdrawn | equivalence if κ is visible to the relay |
| 3 | W5 decodes T (disjoint φ sets); exclusivity gate too strong | ✔ C3 | executed matrix first; revised gate | witness predictions are hypotheses |
| 4 | Process baseline 2/3, not 0.5; assumptions unstated | ✔ C4a | affine balanced family; exact Bayes; trace contract; θ vs (w,b) access split | small k is weak |
| 5 | Outcome 5 admits contradictory verdicts | ✔ C5 | descriptive panel; unity verdict deferred | needs a shared-cause model |
| m1 | inconclusive ≠ underpowered | ✔ | reason codes | — |
| m2 | IUT does not control false fails | ✔ C6 | primary failure clause or Holm | — |
| m3 | noiseless vs achievable | ✔ C7 | registered-ε tables; margins under the achievable gap | — |
| self | D8 compared different data access | found in revision | access-matched D8 | — |

*v2 is retained unchanged as the record. Every [REF] here is produced by `e0b_reference.py` Parts B–C. All U1 rows in §3 were recomputed under the affine family (Part C8).*


## Appendix C — v2.1 → v2.2 change ledger (third external review)

| # | Finding | Verified (`e0b_contracts.py`) | Repair | Residual |
|---|---|---|---|---|
| 1 | B1-action-value could not compute Q: κ was withheld from it | ✔ κ-blind encoder emits 1/2 where Q = 0.3 / 0.7 | κ given to both encoders, hidden from the relay | — |
| 2 | Hiding κ is insufficient: Q with R identifies φ | ✔ relay (M,R): 0.825 / 0.825; noisy ε=1/3: M-only 0.7167, M+R 0.7727 | relay contract made explicit (sees M,R); graded κ + capacity-limited own-optimal codes: 0.825 vs 0.769 (oracle), 0.790 vs 0.746 (k=40) | discriminator is capacity-relative; rival quantizer family [FRZ] |
| 3 | Table rows lacked consumer, input and payoff labels; 0.825 is correctness-only; κ-bonus optimum 0.841 | ✔ 0.8410 | every row labelled; contract table authoritative | — |
| 4 | RR 0.80625→0.825 is a mapping-oracle subproblem | ✔ | trace-budget sweep: RR gap 0.002 / 0.008 / 0.018 / 0.019 at k = 10 / 20 / 40 / 80 | RR is uninformative unless k ≳ 40 |
| 5 | 0.265 is the independence figure, not the worst case | ✔ union bound 0.30 | corrected; Holm kept | — |
| self | exact fixed-R collision (β=189/320) separates at the oracle but disappears under traces at every k tested | found in repair | exact-coincidence designs dropped | — |
| self | all effects scale steeply with trace budget: relay φ value 0.717 / 0.750 / 0.790 / 0.817 at k = 10 / 20 / 40 / 80 vs public 0.700 | found in repair | block length / k must be fixed in MB0 before any margin | — |

*Next MB0 check, in order: (1) freeze the contract table (who observes what); (2) fix k from the intended block length; (3) fix the rival-quantizer family and L; (4) only then interpret S1h or set margins.*
