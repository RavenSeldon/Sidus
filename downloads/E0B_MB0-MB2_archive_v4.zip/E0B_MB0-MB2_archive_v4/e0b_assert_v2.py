#!/usr/bin/env python3
"""E0-B assertions v2 (Ledger F): the 17 v1 assertions plus direct assertions of the Ledger E/F outcomes.
Usage: python3 e0b_assert_v2.py [--full]   (--full adds the trace-compliant Shea matrix, ~10 min). Exits non-zero on failure."""
import sys, subprocess
from fractions import Fraction as F
import e0b_mb12 as M, e0b_ledgerE as E, e0b_ledgerF as LF

r = subprocess.run([sys.executable, 'e0b_assert.py'], capture_output=True, text=True); print(r.stdout)
fails = [] if r.returncode == 0 else ['v1 assertion suite']
def check(label, cond, detail=''):
    print(f"[{'PASS' if cond else 'FAIL'}] {label} {detail}")
    if not cond: fails.append(label)

pc = E.p1c_intervention()
check('P1c relabelling: no W6b prediction changes', pc['W6b permutations (of 24) changing any f(11) prediction'] == 0)
check('P1c relabelling: no W3 prediction changes', pc['W3 permutations (of 24) changing any f(11) prediction'] == 0)
fs, fh, _ = E.p1d_controlled('W3 process model (truth table)')
check('P1d W3 follows source content', abs(float(fs) - 0.596178) < 5e-7, f'({float(fs):.6f})')
check('P1d W3 does not follow host', fh == F(1, 2))
spec = LF.f3()
check('P1c specificity W3 > 0', spec['W3 process model (truth table)'][1] > 0, f"({float(spec['W3 process model (truth table)'][1]):+.6f})")
check('P1c specificity W1 == 0', spec['W1 regime code (theta-coupled)'][1] == 0)
for tag, dp, a, b in LF.f1():
    if dp in LF.S1E_BINDING: check(f'S1e binding separation {tag} d={float(dp):.2f}', a > b, f'({float(a - b):+.6f})')
if '--full' in sys.argv:
    for k in (10, 40):
        res = LF.f2(k)
        check(f'trace Shea k={k}: W5t passes every clause', all(res['W5t token-phi (trace-compliant)'][1].values()))
        for nm in ('W10 policy bit act(phi) at d=0.55', 'W1 regime code', 'B1t-accept-value', 'B1t-invert-value', 'B1t-action-vector'):
            check(f'trace Shea k={k}: {nm} fails', not all(res[nm][1].values()))
        check(f'trace Shea k={k}: W10 fails S1e', not res['W10 policy bit act(phi) at d=0.55'][1]["S1e binding d' (value, contract optimum)"])
print(f"\n{len(fails)} failed" + (": " + ", ".join(fails) if fails else ""))
sys.exit(1 if fails else 0)
