# E0-B — Ledger F, Learned Pilot P0, and Draft MB0 Freeze

**8 October 2026 · decisions by Ben: D2–D6 approved as recommended; finish path "learned pilot, then pause" · Ledger E, the Final-State Report, and archives v1–v2 are preserved unchanged · the freeze below is a DRAFT submitted for external audit; no confirmatory run has been made**

---

## 1. Decisions Recorded (Ben, 8 Oct 2026)

| # | Decision |
|---|---|
| D2 | RR remains `inconclusive(non_identified)` |
| D3 | Separate Process arm: balanced over three observed inputs, fourth held out |
| D4 | Uniform exact-scope criterion; P1b reference = identity-blind contract (a) |
| D5 | Report the functional Shea finding; no strict-metarepresentation claim |
| D6 | S1e re-registered at defer payoffs **0.75 and 0.80**; statistical margins from pilot evidence |
| Path | Learned pilot now, then pause for external audit before any confirmatory run |

## 2. Ledger F — Implementation Corrections

- **S1e binding pair verified** (`e0b_ledgerF.py`, F1). Ledger E's {0.75, 0.90} fails to discriminate at k = 10 (0.90: φ code 0.900000 = policy bit 0.900000), as the reviewer said. {0.75, 0.80} separates the φ code from the policy-bit witness W10 in every context: oracle +0.025 / +0.050; k = 10 +0.025 / +0.0178; k = 40 +0.025 / +0.0470.
- **Trace-compliant Shea matrix re-run with S1e at {0.75, 0.80} and W10 as a full witness** (F2).
  - W5t passes every clause at k = 10 and k = 40. W1, W10 and all trace-built B1 rivals fail.
  - **W10 passes S1h (value and D11)** but fails S1a, S1b-tracking and S1e. The graded-content clause now carries real weight.
- **P1c specificity arm executed** (F3) and joined to the relabelling-invariance arm (Ledger E E2). The two arms together make up v2.1's P1c ("matched anchor output and reliability, different predictions where mappings differ; relabelling-invariant").
  - Specificity: W3 +0.192, W6a +0.183, W6b +0.102, W5 +0.035; W1, W2 and q_T exactly 0.
  - Like P1d, the specificity arm passes for every content-bearing code and does not discriminate on its own.
- **Assertions:** `e0b_assert_v2.py --full` — **43/43 pass**. These are the 17 v1 checks plus direct assertions of P1c (both arms), P1d, S1e binding separation, and the trace-compliant Shea outcomes.

## 3. Learned Pilot P0

The protocol was written, then committed by SHA-256 **before any run**: `25cb3989…507483a`, at 2026-10-08T12:37:37Z.
- Pilot seeds 1–10; confirmation seeds 1001+ untouched.
- Numpy MLPs (one hidden layer, 32 units, Adam, 4,000 steps).
- Shea arm at k = 40, with trace-compliant encoder inputs.
- Evaluation on 100k fresh trials (fit split) + 100k (test split) per system.

### 3.1 Shea arm — results (median [min, max], 10 seeds)

| System | Relay value | Calibration excess | κ-sensitivity | D11 agreement | S1e gap 0.75 / 0.80 |
|---|---|---|---|---|---|
| **C-end** (candidate, reward-only T-end) | 0.7700 [0.7635, 0.7758] | 0.0168 | 0.541 | **0.013** [0.000, 0.149] | 0.022 / 0.024 |
| **C-sup** (candidate, supervised T-sup) | 0.7941 [0.7927, 0.7964] | 0.0004 | 0.014 | **0.943** | 0.0005 / 0.0006 |
| **B0-am** (access-matched, 4-d, end-to-end) | 0.7864 [0.7806, 0.7941] | 0.0085 | 1.93 | 0.717 [0.358, 0.917] | 0.012 / 0.012 |
| R-vec (B1-action-vector) | 0.7675 | 0.0203 | 1.21 | 0.009 | 0.029 / 0.033 |
| R-acc (B1-accept-value) | 0.7467 | 0.0316 | 0.77 | 0.008 | 0.039 / 0.042 |
| ideal φ_post (same test sets) | 0.7943 | 0 | 0 | 1 | 0 |

### 3.2 Applying the pre-specified rules (no new choices)

| Candidate | Clause | Effect vs best rival, median / P10 | Status |
|---|---|---|---|
| C-end | E1 relay (**primary**) | +0.0037 / **−0.0004** | **not reliably achieved at pilot scale** |
| C-end | E4 D11 | +0.0032 / **−0.0288** | **not reliably achieved** |
| C-end | E2, E3, E5 | positive P10 | margins derivable, but see §4.3 |
| C-sup | all six | P10 > 0 throughout (e.g. E1 +0.026, E4 +0.918) | margins defensible |
| B0-am | E1, E2, E4, E5 | P10 > 0 | margins defensible |
| B0-am | E3 κ-invariance | −1.21 | not achieved: carries κ |

**Block-budget rule:** the T-end primary-contrast P10 is negative, so **no block budget can be derived for the reward-only candidate** under the pre-specified rule.

**Optimization reliability** (relay ≥ 95 % of ideal): C-end, C-sup, B0-am and R-vec 10/10; R-acc 0/10. See §4.3 on this criterion's weakness.

### 3.3 Process arm (k_p = 20, held-out identities)

| System | Held-out accuracy (median [min, max]) |
|---|---|
| identity-blind Bayes bound (MC) | 0.7041 |
| P-struct (MLP on joint counts) | **0.4298** [0.4132, 0.4357], *below chance* |
| P-cell-lin (per-cell MAP bits, logistic readout) | **0.6634** [0.6627, 0.6636] |
| P-cell-mlp (per-cell bits, MLP readout) | 0.3551 [0.3499, 0.3606] |

## 4. What the Pilot Found

### 4.1 Shea: the profile does not emerge under reward-only training at pilot scale

The scalar candidate trained only on acceptance reward behaves like an **action-value code**:
- it is κ-mixed (κ-sensitivity 0.54);
- it is miscalibrated relative to φ (excess 0.017, close to R-vec's 0.020);
- it fails D11 (agreement 0.013, against 0.943 for C-sup);
- its relay value (0.770) is close to the learned action-vector rival (0.768).

The supervised candidate realizes the profile almost ideally. The 4-d end-to-end system often recovers φ (D11 up to 0.92), but it carries κ separately, which is exactly the residual named in Ledger D-II.

**Reading:** in this architecture and at this scale, reward pressure on the acceptance task does not produce a correctness code. The functional organization E0-B can detect has to be trained for, or allowed through extra capacity. This is a substantive pilot finding, not a defect. It is pilot-scale and architecture-specific.

### 4.2 Process: the designed contrast is not identified in U1 (newly discovered defect)

The pilot exposed a property, now **proved exactly** (`e0b_pilot_process_check.py`).
- The six-map family can produce only six observed patterns at the three traced inputs.
- On those six patterns, the **linear** rule "predict f(11) = 1 iff fewer than two per-cell bits are 1" coincides with the parity (structural) rule. So a per-cell tracker with a linear readout implements the family structure exactly.
  - At k = 5 it scores **0.591577** on held-out identities, against the structured bound 0.596178.
  - The Final-State Report's P1b separation (W6a 0.518517) arose because the 0-1-loss-optimal decoder **overfit the training identities** (train 0.6007 vs 0.5916). It did not arise from W6a lacking structure.
- Learned flexible models extrapolate badly to the unseen held-out patterns (0.43 and 0.36, below chance).
- The remaining exact-scope gap (0.0046) comes from binarizing counts, not from structure.

**Disposition:**
- The strict exact-scope verdicts stand (W6a still falls short of the bound).
- **The designed contrast, a structured process model versus a non-structural per-cell tracker, is not identified in U1.** The per-cell tracker is not a valid non-structural negative witness in this family.
- Process readiness is **downgraded** from `validated_operationalization` to **`proposal` (fixture amendment required)**.
- The original Report and Ledger E statuses are preserved, as the amendment rule requires.

**Exploratory probe (not adopted; for audit)** — `e0b_process_family_probe.py`:
- Adding the two constant maps (8 maps) makes every pattern possible, so f(11) is parity of three bits, which is *not* a threshold function.
- At k = 20: structured Bayes 0.596; best linear per-cell readout 0.549; unrestricted per-cell readout 0.596.
- This gives a genuine structural contrast for bounded readouts. The cost is that the constant maps **break reliability matching** (inversion rates 0 and 1), so a scalar reliability cue would carry identity information. The trade-off needs an audited decision.

### 4.3 Weaknesses in my own pre-specified pilot rules (recorded, not repaired after the fact)

1. **Margins relative to the best rival misfit invariance and calibration clauses.** C-end gets "positive" E3 and E2 margins only because the rivals are worse. In absolute terms it is clearly κ-dependent and miscalibrated, so it fails S1b-nuisance and S1a as clauses.
2. **The 95 %-of-ideal reliability criterion is too lax:** rivals pass it. A criterion tied to each system's own exact optimum is needed.
3. **Pilot evaluation used one scored trial per block** (independent blocks). The between-block variance assumed by the Report's power analysis is therefore absent here; see D1 below.

## 5. Draft MB0 Freeze (for external audit — NOT frozen)

| Element | Draft |
|---|---|
| **RR** | Final determination: `inconclusive(non_identified)`. Bounded accessibility gain demonstrated; matched transformations reproduce it; RR1c non-identified. No confirmation run. *Satisfies stopping-criterion item 1 by justified determination.* |
| **Process** | Excluded from confirmation pending a fixture amendment (e.g. the 8-map family) and fresh exact-scope validation. |
| **Shea confirmation units** | Trained systems. 20 confirmation seeds per system (1001–1020). Each evaluated on 100k + 100k fresh independent blocks. |
| **D1 (block budget), proposed** | B_trace = 160 (k = 40 × 4), **B_score = 1** (independent blocks), N = 100k blocks per evaluation split. Simulation cost is negligible, so independent blocks remove between-block variance and the seed is the unit of inference. Seed-level sds from the pilot are small (e.g. C-sup relay 0.0013, D11 0.015; C-end D11 0.059), so 20 seeds give power ≫ 0.9 for every effect larger than about two seed-level sds. Exact power is to be computed in the confirmation plan once the audit settles the hypotheses |
| **Shea hypotheses, pilot-informed (flagged as such)** | **H1 (engineering):** C-sup passes all Shea clauses with margins of half the pilot P10. **H2 (scientific, directional):** C-end, the reward-only scalar candidate, *fails* the Shea profile, with D11 agreement ≤ 0.2 and κ-sensitivity ≥ 0.25, i.e. an action-value-like code. **H3:** B0-am recovers φ (D11 ≥ 0.3), yet fails κ-invariance. |
| **Absolute clause criteria (fixing §4.3.1)** | Calibration excess ≤ 0.002; κ-sensitivity ≤ 0.05; S1e gap ≤ 0.002, in addition to the relative margins |
| **Reliability criterion (fixing §4.3.2)** | Report each system's relay value as a fraction of its own exact contract optimum. No seed exclusion |
| **Amendment rule, stopping criterion, decision algebra** | As approved (Completion Plan §§2, 6; v2.2 §8) |

## 6. Questions for the External Audit (the pause point)

1. Process: adopt the 8-map amendment (accepting broken reliability matching, with a scalar-cue control added), find another remedy, or record Process as `inconclusive(non_identified)` in U1?
2. Are **pilot-informed directional hypotheses** (H2, H3) acceptable for confirmation, given that confirmation seeds are untouched?
3. D1: is **B_score = 1** (independent blocks) acceptable, with the training seed as the unit of inference?
4. Are the absolute clause thresholds in §5 appropriate, or should they come from exact-scope references?
5. Should a second architecture family be added before confirmation (v2.1 MB4 called for ≥ 2)?

## 7. Stopping-Criterion Status

| Item | Status |
|---|---|
| 1. Each index tested or justified non-identifiable | RR: **met** (determination). Shea: exact-scope met; learned confirmation pending audit. Process: **not met** (fixture amendment needed) |
| 2. Conclusions survive rivals and uncertainty controls | met for exact-scope conclusions; pending for learned |
| 3. Discrepancies dispositioned | met: all recorded (Ledgers D–F, this document) |
| 4. Empirical findings separated from interpretation | met |
| 5. No necessary experiment unfinished; artifacts archived | not met (Shea confirmation, Process amendment) |

**E0-B is not complete.** Its open items are now three: the external audit of this draft, the Process fixture decision, and the Shea confirmation run.

## 8. Provenance

New in archive v3:
- **Scripts:** `e0b_ledgerF.py`, `e0b_assert_v2.py`, `e0b_pilot.py`, `e0b_pilot_analysis.py`, `e0b_pilot_process_check.py`, `e0b_process_family_probe.py`
- **Protocol:** `E0B_Pilot_Protocol_P0.md`, with its commitment hash
- **Logs, results and per-trial arrays:** `ledgerF_output.md`, `assert_v2_output.md`, `pilot_output.md`, `pilot_analysis.md`, `pilot_seed_sd.md`, `pilot_process_check.md`, `process_family_probe.md`, the JSON results and `pilot_trials_*.npy`

Archive v3 has a fresh SHA-256 manifest. Archives v1 and v2 are unchanged.
