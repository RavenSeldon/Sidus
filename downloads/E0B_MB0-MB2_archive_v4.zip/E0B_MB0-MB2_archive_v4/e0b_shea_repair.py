#!/usr/bin/env python3
"""E0-B — response to the independent audit of v2.2 (Ledger D).

Sections
  D1  Q-quantizer ties: all contiguous 4-bin partitions, acceptance-optimal ties, relay range   [audit §2]
  D2  phi-quantizer ties too, under the replacement channel: symmetric comparison                [audit §4]
  D3  3-label NON-contiguous Q-measurable code attaining both optima (graph colouring)          [audit §6]
  D4  D11 exact matched-pair eligibility in the graded-kappa fixture                              [audit §5]
  D5  marginal-MAP bits outside the affine family (k=10)                                          [audit §3]
  D6  REPAIR: continuous kappa ~ U[0,1], accept pays L + kappa for any R. Exact Q is the strongest
      Q-measurable code for a noiseless relay (data-processing), so the gap holds against EVERY
      Q-measurable code, contiguous or not, any capacity. Piecewise-exact integration.
  D7  full-trace Bayes reference (float64; slow, ~3 min) — run with --full-trace                  [audit §3]
Requires e0b_contracts.py alongside (D7 also needs numpy).
"""
import sys
from fractions import Fraction as F
from itertools import combinations, product
from collections import defaultdict
from math import comb
import e0b_contracts as C
A3 = ['accept', 'invert', 'defer']
def hdr(s): print("\n== " + s)

def value_tables(S, code_of, obs, payoff):
    vals = sorted({code_of(s) for _, s in S}); idx = {v: i for i, v in enumerate(vals)}
    T = [dict() for _ in vals]; mass = [F(0)] * len(vals)
    for pr, s in S:
        i = idx[code_of(s)]; mass[i] += pr; pay = C.PAY[payoff](s)
        d = T[i].setdefault(tuple(s[o] for o in obs), [F(0)] * 3)
        for j, a in enumerate(A3): d[j] += pr * pay[a]
    return vals, T, mass
def totals(S, obs, payoff):
    t = defaultdict(lambda: [F(0)] * 3)
    for pr, s in S:
        pay = C.PAY[payoff](s); d = t[tuple(s[o] for o in obs)]
        for j, a in enumerate(A3): d[j] += pr * pay[a]
    return t
def part_value(bins, T, mass, tot, eps):
    v = F(0)
    for i0, i1 in bins:
        m = sum(mass[i0:i1]); agg = defaultdict(lambda: [F(0)] * 3)
        for i in range(i0, i1):
            for J, d in T[i].items():
                for j in range(3): agg[J][j] += d[j]
        for J in tot:
            sig = agg.get(J, [F(0)] * 3)
            v += max((1 - eps) * sig[j] + eps * m * tot[J][j] for j in range(3))
    return v
def contiguous_ties(n, val):
    best, ties = None, []
    for c in combinations(range(1, n), 3):
        bins = [(0, c[0]), (c[0], c[1]), (c[1], c[2]), (c[2], n)]; v = val(bins)
        if best is None or v > best: best, ties = v, [bins]
        elif v == best: ties.append(bins)
    return best, ties

def d1_d2():
    for tag, k in (('mapping oracle', None), ('k=40 marginal-MAP traces', 40)):
        S = list(C.states_grid(F(1), 8, k)); enc = C.ENC_BASE if k is None else C.ENC_TRACE
        ph = C.encode(S, 'L', enc + ['kappa']); qq = C.encode(S, 'acc_pay', enc + ['kappa'])
        qv, TA, mA = value_tables(S, qq, ['r', 'kappa'], 'accept_consumer'); _, TRq, mq = value_tables(S, qq, ['r'], 'relay')
        totA = totals(S, ['r', 'kappa'], 'accept_consumer'); totR = totals(S, ['r'], 'relay')
        bestA, qties = contiguous_ties(len(qv), lambda b: part_value(b, TA, mA, totA, F(0)))
        pv, TRp, mp = value_tables(S, ph, ['r'], 'relay')
        bestP, pties = contiguous_ties(len(pv), lambda b: part_value(b, TRp, mp, totR, F(0)))
        hdr(f"D1/D2 [{tag}] Q values {len(qv)} -> {comb(len(qv)-1, 3)} partitions, {len(qties)} acceptance-optimal; "
            f"phi values {len(pv)} -> {len(pties)} relay-optimal phi partitions")
        print("  eps    | phi ties (min..max)    | Q ties (min..max)      | gap range [phi_min-Q_max, phi_max-Q_min] | best-vs-best")
        for eps in (F(0), F(1, 10), F(1, 3)):
            P = [part_value(b, TRp, mp, totR, eps) for b in pties]; Q = [part_value(b, TRq, mq, totR, eps) for b in qties]
            print(f"  {str(eps):6s} | {float(min(P)):.6f}..{float(max(P)):.6f} | {float(min(Q)):.6f}..{float(max(Q)):.6f} | "
                  f"[{float(min(P)-max(Q)):+.6f}, {float(max(P)-min(Q)):+.6f}] | {float(max(P)-max(Q)):+.6f}")

def d3_d4():
    S = list(C.states_grid(F(1), 8, None))
    ph = C.encode(S, 'L', C.ENC_BASE + ['kappa']); qq = C.encode(S, 'acc_pay', C.ENC_BASE + ['kappa'])
    def argset(d): m = max(d.values()); return frozenset(a for a, v in d.items() if v == m)
    ctx = defaultdict(lambda: defaultdict(lambda: defaultdict(F)))
    for pr, s in S:
        q = qq(s)
        for a, v in C.PAY['relay'](s).items(): ctx[('relay', s['r'])][q][a] += pr * v
        for a, v in C.PAY['accept_consumer'](s).items(): ctx[('acc', s['r'], s['kappa'])][q][a] += pr * v
    qs = sorted({qq(s) for _, s in S}); conf = {q: set() for q in qs}
    for c in ctx.values():
        opt = {q: argset(d) for q, d in c.items()}
        for a, b in combinations(opt, 2):
            if not (opt[a] & opt[b]): conf[a].add(b); conf[b].add(a)
    order = sorted(qs, key=lambda q: -len(conf[q])); col = {}
    def bt(i, K):
        if i == len(order): return True
        q = order[i]
        for c in range(K):
            if all(col.get(n) != c for n in conf[q]):
                col[q] = c
                if bt(i + 1, K): return True
                del col[q]
        return False
    hdr("D3 non-contiguous Q-measurable witness (mapping oracle, graded kappa)")
    for K in (2, 3):
        col.clear()
        if not bt(0, K): print(f"  K={K}: none"); continue
        code = lambda s: col[qq(s)]
        print(f"  K={K}: relay {float(C.consumer_value(S, code, ['r'], 'relay')):.6f}  "
              f"acceptance {float(C.consumer_value(S, code, ['r', 'kappa'], 'accept_consumer')):.6f}  "
              f"(optima 0.825000 / {float(C.consumer_value(S, None, ['o','r','T','f','kappa'], 'accept_consumer')):.6f})")
    hdr("D4 D11 exact matched classes in the graded-kappa fixture")
    for tag, k in (('mapping oracle', None), ('k=10', 10), ('k=40', 40)):
        S2 = list(C.states_grid(F(1), 8, k)); enc = C.ENC_BASE if k is None else C.ENC_TRACE
        ph2 = C.encode(S2, 'L', enc + ['kappa']); qq2 = C.encode(S2, 'acc_pay', enc + ['kappa'])
        byQ = defaultdict(set); byP = defaultdict(set)
        for _, s in S2: byQ[qq2(s)].add(ph2(s)); byP[ph2(s)].add(qq2(s))
        print(f"  {tag:15s} matched-Q/different-phi classes {sum(len(v) > 1 for v in byQ.values())};  "
              f"matched-phi/different-Q classes {sum(len(v) > 1 for v in byP.values())}")

def d5():
    k = 10; p = C.pS1; fam = {tuple(C.fval(wb, o) for o in C.OS) for wb in C.FAM}
    lik = lambda f, j: p**j * (1-p)**(k-j) if f == 0 else (1-p)**j * p**(k-j)
    mass = F(0); n_bad = 0
    for js in product(range(k + 1), repeat=4):
        L = {wb: 1 for wb in C.FAM}
        for wb in C.FAM:
            for o, j in zip(C.OS, js): L[wb] *= lik(C.fval(wb, o), j)
        bits = []
        for o in C.OS:
            a1 = sum(L[wb] for wb in C.FAM if C.fval(wb, o)); a0 = sum(L[wb] for wb in C.FAM if not C.fval(wb, o))
            bits.append(1 if a1 > a0 else 0 if a0 > a1 else None)
        if None not in bits and tuple(bits) not in fam:
            n_bad += 1; mult = 1
            for j in js: mult *= comb(k, j)
            mass += mult * sum(L.values()) / 6
    hdr(f"D5 marginal-MAP bit patterns outside the affine family, k=10: {n_bad} count vectors, probability {float(mass):.4f}")

def d6():
    D = C.D
    def atoms(k):
        S = [(pr, s) for pr, s in C.states(F(0), k=k) if s['kappa'] == 0]
        ph = C.encode(S, 'L', C.ENC_BASE if k is None else C.ENC_TRACE); A = defaultdict(lambda: [F(0), F(0)])
        for pr, s in S: a = A[(s['r'], ph(s))]; a[0] += 2 * pr; a[1] += 2 * pr * s['L']
        return A
    pay = lambda m, c: (c, m - c, D * m)
    def phi_relay(A, eps):
        marg = defaultdict(F)
        for (r, f), (m, c) in A.items(): marg[f] += m
        tot = {r: [sum(pay(m, c)[j] for (rr, f), (m, c) in A.items() if rr == r) for j in range(3)] for r in (0, 1)}
        return sum(max((1-eps) * pay(*A.get((r, f), (F(0), F(0))))[j] + eps * pm * tot[r][j] for j in range(3))
                   for f, pm in marg.items() for r in (0, 1))
    def q_relay(A, eps, spread_R=(0, 1)):
        items = [(r, f, m, c) for (r, f), (m, c) in A.items()]
        fixed = sum(max(pay(m, c)) for r, f, m, c in items if r not in spread_R)   # R where Q = phi exactly (noiseless only)
        items = [it for it in items if it[0] in spread_R]
        bps = sorted({f for _, f, _, _ in items} | {f + 1 for _, f, _, _ in items})
        tot = {r: [sum(pay(m, c)[j] for rr, f, m, c in items if rr == r) for j in range(3)] for r in spread_R}
        v = F(0); amb = F(0)
        for lo, hi in zip(bps, bps[1:]):
            mid = (lo + hi) / 2; w = hi - lo; live = [it for it in items if it[1] <= mid <= it[1] + 1]
            dens = sum(it[2] for it in live)
            for r in spread_R:
                sig = [sum(pay(m, c)[j] for rr, f, m, c in live if rr == r) for j in range(3)]
                v += w * max((1-eps) * sig[j] + eps * dens * tot[r][j] for j in range(3))
                acts = {max(range(3), key=lambda j: pay(m, c)[j]) for rr, f, m, c in live if rr == r}
                if len(acts) > 1: amb += w * sum(m for rr, f, m, c in live if rr == r)
        return fixed + v, amb
    hdr("D6 REPAIR — continuous kappa ~ U[0,1], accept pays L + kappa (any R); relay observes (M, R), never kappa")
    print("  access            eps    | phi code  | exact Q (strongest Q-measurable, eps=0) | gap      | D11 matched-Q/different-action mass")
    for tag, k in (('mapping oracle', None), ('k=40 traces', 40)):
        A = atoms(k)
        for eps in (F(0), F(1, 10), F(1, 3)):
            qv, amb = q_relay(A, eps); pv = phi_relay(A, eps)
            print(f"  {tag:16s} {str(eps):6s} | {float(pv):.6f} | {float(qv):.6f}                                | {float(pv-qv):+.6f} |"
                  + (f" {float(amb):.4f}" if eps == 0 else ""))
    A = atoms(None); qv, _ = q_relay(A, F(0), spread_R=(0,))
    print(f"  auditor's variant (bonus only at R=0, continuous kappa): exact-Q relay {float(qv):.6f}")

def d7():
    import numpy as np
    from math import lgamma, log
    p = float(C.pS1); D = float(C.D)
    hdr("D7 full-trace Bayes reference (encoder keeps the complete trace counts; float64)")
    for k in (10, 20, 40):
        j = np.arange(k + 1); lc = np.array([lgamma(k+1)-lgamma(i+1)-lgamma(k-i+1) for i in j])
        ll = {0: j*log(p)+(k-j)*log(1-p), 1: j*log(1-p)+(k-j)*log(p)}
        g = np.meshgrid(j, j, j, j, indexing='ij')
        logL = np.stack([sum(ll[C.fval(wb, o)][g[i]] for i, o in enumerate(C.OS)) for wb in C.FAM]).reshape(6, -1)
        lm = sum(lc[g[i]] for i in range(4)).reshape(-1)
        post = np.exp(logL - np.logaddexp.reduce(logL, axis=0)); pc = np.exp(lm + logL)
        ev = defaultdict(lambda: np.zeros(6))
        for c in range(post.shape[1]): ev[tuple(np.round(post[:, c], 12))] += pc[:, c]
        groups = defaultdict(lambda: [0.0, 0.0])
        for kk, pw in ev.items():
            for x, z1, z2, n, o in product((0, 1), (0, 1), (0, 1), (0, 1), C.OS):
                T = z1 ^ z2; q = float(C.QH if T == 0 else C.QL)
                base = (0.7 if x else 0.3) * 0.25 * ((1-q) if n else q) * 0.25 / 6
                for wi, wb in enumerate(C.FAM):
                    r = (x ^ n) ^ C.fval(wb, o); gg = groups[(kk, o, r, T)]; gg[0] += base * pw[wi]; gg[1] += base * pw[wi] * (r == x)
        print(f"  k={k}: {sum(max(c, m - c, D * m) for m, c in groups.values()):.6f}")

if __name__ == '__main__':
    d1_d2(); d3_d4(); d5(); d6()
    if '--full-trace' in sys.argv: d7()
    else: print("\n(D7 full-trace reference skipped; run with --full-trace, ~3 min)")
