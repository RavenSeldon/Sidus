# Sīdus E0 Experiment v0.4 — Independent Validation Review

**Date:** 2026-09-06 · **Reviewer:** Kimi Work agent · **Package:** `Sidus_E0_Experiment_v0.4.zip` + pilot post-mortem notes · **Protocol source:** https://sidus.quest (frozen snapshot pinned inside the package at `runbook_reference/source_snapshot/`)

---

## 1. What was validated

| Check | Result |
|---|---|
| `experiment.cli integrity` (original, read-only) | `release_intact: true`, exit 0 |
| Independent SHA-256 re-verification of all 5 manifests (PACKAGE 287 files, EXPERIMENTAL 36, PILOT 183, runbook PACKAGE 35, SOURCE 4) | **All pass, zero mismatches** |
| Adapter unit tests | **106 tests, OK** — matches shipped `TEST_OUTPUT.txt` |
| Pinned runbook reference tests | **73 tests, OK** — matches pinned expectation |
| `regressions` | 30/30 checks pass, `full_scientific_acceptance: false` (as documented) |
| `mutations` | 6 legacy evaluator mutations × 30 cases, all detected |
| `bundle` → `verify-run` → `replay-run` | All valid, exit 0; `claim_license: false` |
| `audit config/preregistration.template.json` | Exit **3** exactly as documented ("valid but incomplete": 60 blockers, no errors) |
| `verify-pilot pilot_examples` | Valid, exit 0 |
| `replay-pilot pilot_examples` | **Zero differences** from archived pilot within declared tolerances (float abs_tol 1e-10 / rel_tol 1e-9; all other fields exact) — includes full retrain of all 60 runs |
| Fresh `pilot` batch | Reproduces archived aggregates exactly: 60/60 executed, seeds [0,1,2,4] pass engineering A1–A4, 35/35 controls |
| Independent arithmetic on `PILOT_EVIDENCE.json` | 60 runs = 25 learned + 35 controls ✓; m = 1−ρ exact on all 21 non-collapsed learned runs ✓; B_obs = (1−ρ)/2 ✓ (4 runs differ by 1 ulp ≈ 1.1e-16) ✓; ρ=1 rows all A1/A2-fail, A3-inconclusive ✓ |

### Discrepancies / notes found (none blocking)

1. **macOS portability wart (environment, not logic):** the manifest-containment check in `runbook_reference/reference/audit.py` compares a `Path.resolve()`d path against an unresolved tempdir root. On macOS `/var` → `/private/var` symlink makes 7 tests/checks fail unless `TMPDIR` is set to a realpath-consistent directory (e.g. `TMPDIR=/private/tmp/...`). With that, everything passes. Worth a one-line fix or a documented platform note.
2. **`encoder_collapsed` flag count:** evidence flags **4** collapsed learned runs — the 3 narrated below full observability (seed 3 @ ρ=.5; seeds 0/4 @ ρ=.75) **plus** seed 3 @ ρ=1. The narrative ("3 of 20 runs below full observability collapse") is accurate; the extra flag sits at the ρ=1 endpoint where A1/A2 failure is structurally expected. Consistent, but the report could state the 4th explicitly.
3. **B_obs formula:** the after-pilot note says "B observed = ρ/2" decline from baseline; the data is exactly B_obs = (1−ρ)/2 (i.e. 0.5 − ρ/2). Consistent with headroom = (1−ρ)/2; just a wording precision.

**Verdict on engineering validity: the package is internally consistent, byte-intact, fully reproducible, and its self-reported results are accurate.** The honest-reporting claims (withdrawn "30/30", retained failures, `claim_license: false` everywhere, N/A rather than fake passes) all check out under independent re-execution.

---

## 2. What the pilot results mean for E0-A

### What is now supported (development-scope)

- **The measurement instrument works.** The exact finite evaluator, gate scorer (A1–A4 with pass/fail/inconclusive/N-A semantics), intervention kernel with on-support rejection conditioning, preservation monitoring, and the 7-system control battery (35/35 expectations met) demonstrably discriminate useful channels from collapsed/shortcut/irrelevant ones. This was the main construct-validity risk, and it is retired.
- **Finite-task feasibility of the learned channel.** A two-probability encoder trained by projected gradient ascent, with *no* information objective and no identity-initialization, converges to a perfect (or equivalent) monitoring channel in 17 of 20 sub-full-observability runs; at the primary condition (ρ=.5) 4/5 seeds pass all engineering A1–A4 clauses with m = 1−ρ exactly and zero joint optimization gap.
- **The failure mode is characterized, not hidden.** All 3 sub-full-observability collapses are **coordination traps**: encoder best-response gap = 0 (no profitable unilateral encoder deviation given the trained consumer), consumer gap = 0, yet joint gap = 0.125–0.25 against the exact class optimum. These are Nash-stable but jointly suboptimal equilibria — a training-procedure reliability problem, not evidence the channel is impossible. This is a genuinely useful, exactly-measured finding.

### What is NOT established

- **Training robustness.** A ~15–20% collapse rate at 5 development seeds fails any conceivable confirmatory reliability requirement. Per the protocol, seed selection to hide this would be disqualifying.
- **Confirmatory inference of any kind.** The seeds are development seeds (inspected during implementation); replay/retrain is reproducibility, not independent replication; engineering thresholds are uncalibrated placeholders; the audit command checks declarations, not outcomes; `license_claim` never fires in this release. The package says all of this itself, and the claims survive scrutiny.
- **A3 causal strength beyond policy response.** The intervention produces the predicted directional TV shift with preservation verified, but the additional task-reward contrast required for the intended interpretation (supported replacement + matched nuisance controls) is not yet quantified.
- **Scope beyond the constructed finite population.** Exact enumeration is valid for this population; any "learns from samples / generalizes" claim needs genuinely separated train/eval draws and held-out task structures, which do not exist yet.
- **Anything about metarepresentation, scarcity, or ecology.** E0-A even at full pass licenses only "a causally used internal-state monitoring channel exists" and E1 — explicitly not strict metarepresentation (that is E0-B), and not E0-B itself.

**Bottom line for E0-A:** the construct and the instrument are validated at engineering level; the *learning procedure* is the remaining weak link. E0-A status = **promising exploratory pass, confirmatory verdict not yet obtainable**.

---

## 3. Next steps to finalize E0-A (recommended sequence)

Ordered per the package's own NEXT_STEPS, with specifics added:

1. **Fix training robustness in a new, recorded development batch** (original batch untouched).
   - Diagnose: the collapses are stable coordination equilibria with zero unilateral best-response gap, so candidate fixes must act on the *joint* landscape: asymmetric learning rates or update ordering, consumer warm-start/commitment phases, entropy or information-shaped regularization, initialization distribution changes, longer/annealed schedules.
   - Pre-specify a *small* set of explicit revisions; evaluate on **fresh** development seeds under a frozen selection rule. If robustness stays poor → narrow the procedural claim rather than shop seeds.
2. **Strengthen A3 causal-application evidence**: quantify the task-reward contrast of supported replacements against matched nuisance controls; keep general/recurrent preservation as a separate, later implementation.
3. **Decide the claim's scope explicitly**: finite-population claim (exact enumeration suffices) vs. sample-learning/generalization claim (requires real train/eval separation and validated extended estimator). Do not add a decorative split.
4. **Calibrate and freeze thresholds** (δ_H, δ_m, κ, δ_D, e_min, A4 decline magnitudes) from measured task headroom with recorded rationale — only after 1–3, since a biased learner bakes bias into thresholds.
5. **Implement the confirmatory evaluator**: preregistration ingestion, independent seed inventory, uncertainty family / familywise decisions, precision & reliability requirements, pass/fail/inconclusive adjudication including missing-run rules. The current artifact audit is a declaration checker, not this.
6. **Run independent confirmation** on new seeds with everything frozen; report every outcome. Only that result can license E1.

## 4. E0-B go / no-go recommendation

**Conditional GO for building and validating E0-B fixtures in parallel — NO-GO for any confirmatory E0-B run now.**

Reasons:

- **No dependency violation:** the protocol gates E1 on E0-A and E2 on E0-B; E0-B does not require an E0-A pass, and E0-A success cannot establish E0-B. So E0-B design work may proceed now, and the package already ships the S1/RR1/P1 analytic panels with feasibility oracles.
- **But confirmatory readiness is far away:** each index (Shea / RR / Process) still needs a frozen executable predicate, validated discriminating controls that can actually separate B0/B1/B2 (RR1's parity counterexample and S1's identifiability warning show the authors know where the bodies are buried), frozen semantic interpretation, and its own learned manipulations with matched comparators.
- **Practical blocker shared with E0-A:** E0-B's learned candidates will hit the same training-reliability problem. Sequence the robustness fix first; it de-risks both.
- **Decision rule:** proceed to confirmatory E0-B only when (a) the E0-A training procedure is frozen post-robustness-fix, and (b) at least one E0-B index has validated controls demonstrating that its named simpler alternatives *can* fail it. Treat a reproducible Shea/RR/Process split verdict as a substantive finding, not a failure.

---

## 5. Caveats on this review

- Validation ran on macOS with Python 3.12.14; the TMPDIR symlink workaround (§1, note 1) was required for 7 tests — a portability issue to fix, not a correctness issue.
- Replay equality is established for this runtime within the package's declared tolerances; cross-runtime float behavior is only tolerance-compared, by design.
- I verified the frozen source documents from the in-package pinned snapshot (hash-verified against `SOURCE_MANIFEST.json`); they correspond to the documents served at sidus.quest.


---

# Addendum — v0.5 development batch re-validation (2026-09-06)

**Package:** `Sidus_E0_Experiment_v0.5.zip` (combined: unchanged adapter 0.4 + runbook 1.1 in `pinned_adapter/`, plus `development/` extension 0.5).

## Independent validation results — all pass

| Check | Result |
|---|---|
| `development integrity` (original tree, read-only) | exit 0, "Combined and pinned integrity clean" |
| Independent SHA-256 re-verification | **8 manifests, 3,044 entries, 0 mismatches**; sole unlisted on-disk file is the root manifest itself (as scoped) |
| `diff -r` pinned_adapter vs pristine v0.4 tree | **Zero differences** — "unchanged adapter 0.4 + runbook 1.1" verified byte-for-byte |
| Extension tests | 23/23 OK |
| `development verify` / `development replay` | exit 0 both; replay retrains all 240 runs + 1,936 grid runs and compares every artifact/checkpoint hash — zero errors |
| Pinned adapter | integrity clean; pilot verify/replay valid; 106 + 73 tests OK |
| Tamper test | one-byte edit to `development/training.py` → integrity **refuses with exit 2**; restored byte-exactly; manifest re-verified |
| Fresh `development run` | exit 0; reproduces the archived artifact manifest exactly; selects R1 |
| Evidence spot-audit | 240 attempts, 720/720 checkpoints hash-matched; 4 arms × 0 collapses; seeds 100–104 all pass A1–A4 at ρ=.5; joint gaps 0.0; 140/140 control expectations; R1/R2 share baseline initial kernels per-run; R3 inits are the exact affine map x→.25+(x−.1)·.5/.8 of baseline inits; grid 1,936 runs with diagonal-only collapses; A3 reward diagnostics (eligible drop 1, weighted drop 1−ρ, sham/non-target ≈ 0; noisy control .8/.18/.81/.01/TV .82) all confirmed numerically |
| failed_attempt_001 / PRE_NUMERIC_REPAIR.zip | all 720 failed-attempt checkpoints byte-match the final batch; pre-repair bundle contains the −1.11e-16 headroom record exactly as the erratum narrates |
| Chronology | DESIGN_FROZEN (13:05:40Z) precedes EXECUTION_STARTED (13:12:38Z); executed code hash matches manifest. Local attestation only — not independent preregistration, as the package itself states |

**The one portability note from v0.4 persists:** the macOS `/var`→`/private/var` tempdir symlink still requires a `TMPDIR` prefix; still not a logic defect.

## Assessment

1. **The robustness program was executed exactly as designed, and the batch is fully reproducible** — but its central finding is a *non-result*, and the package says so plainly: all four arms (including the unmodified baseline) achieved 0/20 collapses on fresh seeds 100–104, so **no candidate is shown to improve on the baseline**. R1 is a declared lexicographic tie-break, not a winner.
2. **The mechanism correction is the most valuable scientific content.** Reconstruction shows the v0.4 traps are *constrained boundary optima*: the encoder hits the [0,1] box at steps 5–10 with the raw gradient pointing outside the box and projection suppressing motion; the consumer action gap never reached zero. The earlier "consumer gap → encoder gradient vanishes" ordering is false; "both unilateral gaps zero, joint gap positive" stands. Reconstructed states are explicitly labeled as such.
3. **The A3 reward-contrast diagnostics match the intended design:** paired signed reward drops with no-op mass accounting, sham ≈ 0 in aggregate, non-target selectivity controls, and the signed-reward/TV dissociation demonstrated analytically (.8 drop vs .82 TV on the noisy control; inverted consumer: TV 1, drop −1). The context-mismatch control was correctly identified as non-discriminating for q(S|C) and **not** counted as evidence — the right call.
4. **What the seed evidence does and doesn't say:** pooling the two batches for the baseline gives 3 collapses / 40 sub-full-observability runs (~7.5%, descriptive only). If the true per-run collapse probability were ~0.15 (the v0.4 point estimate), 0/20 on fresh baseline seeds has probability ≈ 4% — mildly suggestive the v0.4 sample overstates the trap rate, but 10 seeds across two batches cannot support a reliability bound, and the package correctly refuses one.
5. **Standing judgment:** robustness across the initialization population remains unresolved; the simplest-learner principle (retain baseline unless a candidate proves a practical advantage) is the right default. E0-A/E0-B/E1 licenses correctly remain false.

## Updated next step (consistent with the package's own recommendation)

A **discriminating** development batch: (a) re-run the disclosed v0.4 failure seeds under each arm as pre-registered stress cases — escaping seed 3 @ ρ=.5 with the failure checkpoints retained would be positive evidence a mechanism actually dislodges boundary traps; (b) vary consumer inits jointly with encoder inits (the grid's public-optimal-consumer slice provably misses the failure mode); (c) size the seed set to a stated precision target — with 0 observed collapses, the one-sided 95% upper bound is ≈ 3/n, so n ≈ 60 runs bounds the rate at ~5% and n ≈ 300 at ~1%; (d) consider certified basin-volume estimation by adaptive grid refinement over the full init space as a complement to Monte Carlo seeds. Only after the procedure is settled: headroom-derived thresholds → freeze → confirmatory adjudicator → independent confirmation.


---

# Addendum 2 — v0.7 confirmation build review (2026-09-06)

**Package:** `Sidus_E0_Experiment_v0.7.zip` — new `confirmation/` layer (calibration draft, adjudicator, statistics, trusted-freeze contract) over byte-preserved history (v0.6 ⊃ v0.5 ⊃ adapter 0.4 ⊃ runbook 1.1). Four rehearsal seeds (9100–9103) executed; 500 confirmation seeds (10000–10499) reserved, none executed.

## Independent validation — all clean

- `confirmation integrity` exit 0; **24,847 manifest entries re-hashed independently across 6 manifests, zero mismatches**; root manifest hash-identical after all runs.
- History chain byte-identical: `diff -r` of the nested adapter vs the pristine v0.4 tree and of the development extension vs the v0.5 tree both empty. Runbook 73/73 and adapter pilot replay still pass inside history.
- 33/33 confirmation tests pass, matching `TEST_OUTPUT.txt`; the licensing-branch test is explicitly constructed mock orchestration (no reserved seed trained).
- `adjudicate` on the shipped rehearsal → **exit 3, inconclusive**: reliability 4/4, CP interval [0.334, 1.0] inconclusive; all three A4 Hoeffding intervals inconclusive at n=4; blockers list rehearsal-phase, absent trusted freeze, and failing criteria. `rehearse` + adjudicate of the fresh folder reproduces the same verdict class.
- Tamper: one byte in a rehearsal checkpoint → integrity exit 2 with the exact artifact named; restored byte-exactly and re-verified.

## The five review priorities

**1. Statistical ranges, intervals, 500-seed calculation — verified as computed, and justified as conservative.**
- Ranges check out from first principles: decline_m ∈ [0,1] (m ≤ H(C|I) ≤ 1 at ρ=0, = 0 at ρ=1); decline_B_class ∈ [0,.5]; decline_B_obs ∈ [−1.5,1.5] — at ρ=0 any I-only comparator scores exactly .5 so B_obs ∈ [−.5,.5], at ρ=1 both consumers see C so B_obs ∈ [−1,1]; the subtraction gives width 3 without assuming optimal training. ✓
- Hoeffding radius W·√(ln(2/α)/(2n)) with per-interval two-sided α = .025/3: minimum n for the ideal (.5) observed-benefit lower bound to clear .25 is **exactly 395** (radius(394) = .25019, radius(395) = .24988); `calibration.py` computes the same 395 from its own formula. 500 gives radius .2221 → ideal lower bound .2779, ~11% slack. ✓
- The CP side: all-pass at n=500 gives lower bound .9913 ≥ .95; the bound stays ≥ .95 down to roughly k≈485/500 — **so under the all-seed guard the ≥95% reliability layer is entirely non-binding** (the guard fails first on any single failure). It only acquires discriminating power if the guard is ever relaxed. The user's provisional reading — "every seed passing" is deliberately stricter than the ≥95% population requirement — is exactly what the code implements; the two layers are coherent, with the population layer currently redundant by design.
- 500 is **not** an intrinsic E0-A requirement: it is driven by the deliberately assumption-free width-3 B_obs range plus Bonferroni + two-sided allocation. Slack exists if Goal 4 wants it: one-sided Hoeffding tails would drop n_min from 395 to ~345; certifying optimization-error bounds (the joint-class-optimum machinery already exists) could shrink W itself. The other two intervals are nowhere near binding (radii .074/.037 vs margins .5/.25).
- The weakest inferential link is stated, not hidden: seed-level "draws" are deterministic hash-derived initializations; independence across seeds is an assumption that hashing cannot prove. Inference is over the initialization population, not over tasks.

**2. Thresholds vs implemented comparisons, boundary handling — agree exactly.**
`positive_clause` applies value ∓ 1e-10 enclosure: strict clauses pass only if low > threshold, fail only if high ≤ threshold, else inconclusive — a value exactly at threshold is **always inconclusive, never rounded into a pass**. Strict (`>`): A1 hiddenness/relevance, A2 transmission/rate, A3 TV/direction, reward superiority. Non-strict (`≥`): A2 adequacy (κ=.9), A3 eligibility (≥.4), A4 declines. All match the ledger. The calibration witnesses confirm against independent analytics within 1e-10 at all seven flip rates; the flip=.05 witness sits exactly on the adequacy boundary (observed 8.3e-17) and is reported **inconclusive**. Valid-failure precedence holds: a known-failed clause fails its gate even with missing companions (`reduce_gate` checks FAIL first).

**3. Can missing evidence, failed controls, or altered checkpoints produce acceptance? No — 12 adversarial paths exercised, all refused:**
removed seed row → inconclusive; duplicated seed → inconclusive; failed control → fail; corrupted gate clause vs claimed status → inconclusive (gates are recomputed from clauses); invalid sweep → all A4 intervals inconclusive; out-of-range observation (99.0 vs [−1.5,1.5]) → refused, never clipped; flipped checkpoint byte → artifact hash mismatch; forged gate string with consistently resealed manifest → caught by the full training/evaluation replay comparison. Acceptance requires recomputation from verified bytes — cached pass strings are never read.

**4. Confirmation blocked without a valid prior freeze? Yes.** Adjudication of a genuinely generated `frozen_confirmation`-phase outcome (real 52-attempt training in a copy) without freeze arguments → blocked ("trusted freeze digest absent"); wrong config binding → blocked; a fully correct self-made receipt + start record passes all binding checks, leaving only the scientific-criteria blocker. This proves the layering: license ⟸ real passing outcomes **and** binding freeze **and** out-of-band trusted digest. The security rests entirely on the out-of-band digest — a self-made receipt passes every internal binding check, as the package's own `trust_limit` states. One hardening note for Goal 4: `generate()` places no authorization check on *producing* confirmation-kind evidence; the gate exists only at adjudication. Defense-in-depth is adequate, but gating generation on a freeze receipt too would remove a class of accidents.

**5. Clean replay without manifest modification? Yes.** After tests + rehearse + adjudicate: integrity exit 0, all 8,411 root-manifest entries re-verified, manifest file itself hash-identical; `runs/` is outside manifest scope by construction.

## Bottom line for Goal 4

The calibration defines a demanding, coherent finite-task claim; the statistics are internally correct and conservative in the disclosed places; the acceptance machinery cannot be reached by fabrication short of defeating the out-of-band trust anchor. Reviewable choices remaining for Goal 4 are normative, not technical: the half-headroom effect sizes, whether to keep the redundant-but-harmless CP layer as insurance against a future guard relaxation, and whether 500 seeds (vs 395 minimum or ~345 one-sided) is the conservatism level you want to freeze. Nothing found here blocks proceeding to freeze; nothing in this package licenses E0-A, E1, or E0-B yet.
