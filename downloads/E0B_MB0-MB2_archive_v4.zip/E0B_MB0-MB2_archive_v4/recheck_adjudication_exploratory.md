H1 inconclusive
    ['S1a calibration', 0.00045, 0.00043, 0.00046, 0.00234, 'le', np.True_, np.False_]
    ['S1b kappa-retention R2', 0.01697, 0.00762, 0.02633, 0.01841, 'le', np.False_, np.False_]
    ['S1e gap 0.75', 0.00054, 0.00044, 0.00063, 0.00273, 'le', np.True_, np.False_]
    ['S1e gap 0.80', 0.00062, 0.00053, 0.00071, 0.00238, 'le', np.True_, np.False_]
    ['D11 agreement', 0.94345, 0.9355, 0.9514, 0.81687, 'ge', np.True_, np.False_]
    ['relay advantage over best rival', 0.02703, 0.02644, 0.02761, 0.01299, 'gt', np.True_, np.False_]
H2 confirmed
    ['D11 agreement <= 0.20', 0.02629, 0.00924, 0.04335]
    ['kappa-sensitivity >= 0.25', 0.54884, 0.52831, 0.56938]
    ['(descriptive) kappa R2', 0.32449, None, None]
H3 confirmed
    ['D11 agreement >= 0.30', 0.67945, 0.53661, 0.82229]
    ['kappa R2 >= 0.0984', 0.80338, 0.7615, 0.84525]
