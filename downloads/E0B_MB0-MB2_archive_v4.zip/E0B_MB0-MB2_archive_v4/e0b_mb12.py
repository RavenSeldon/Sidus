#!/usr/bin/env python3
"""E0-B MB1 + MB2 executor (R2.4 contract; v2.2 + Ledgers D, D-II; Completion Plan).

MB1  B1 contract audit: every witness code is checked to be a function of its DECLARED inputs only.
     B2 RR consumer ladder (exact): linear-argmax / one hidden threshold unit / unrestricted.
     B3 optimization gaps: gradient-trained consumers at each rung vs the exact rung optimum (float64).
MB2  Witness x predicate matrix at EXACT SCOPE (no sampling): Shea S1a-S1h, RR1b-RR1f, Process P1a-P1e.
     Exact-scope criterion: a clause passes when the witness attains the exact optimum / exact invariance the
     clause names (zero excess, full tracking, value strictly above the registered rival bound). Margins for
     learned systems remain [FRZ]; nothing here is a confirmatory result.

Requires numpy + scipy (LP realizability). Imports e0b_contracts.py and e0b_mb0.py.
"""
from fractions import Fraction as F
from collections import defaultdict
from itertools import product, combinations
from math import comb
import numpy as np
from scipy.optimize import linprog
import e0b_contracts as C
import e0b_mb0 as M0

D = C.D; OS = C.OS; FAM = C.FAM; fval = C.fval
A3 = ('accept', 'invert', 'defer')
def act(phi, d=D): return max(range(3), key=lambda j: (phi, 1 - phi, d)[j])
def pay3(L, d=D): return (F(L), F(1 - L), d)

# ================================================================== fixture (kappa-free U1, oracle mapping)
def phi_cf(r, o, T, f, p):
    q = C.QH if T == 0 else C.QL; s = r ^ f; px = lambda x: p if x else 1 - p
    pn0 = px(s) * q / (px(s) * q + px(1 - s) * (1 - q)); return pn0 if f == 0 else 1 - pn0
TH = {'xor': lambda a, b: a ^ b, 'z1': lambda a, b: a}
def world(theta='xor', p=C.P_X):
    out = []
    for x, z1, z2, n, o, wb in product((0, 1), (0, 1), (0, 1), (0, 1), OS, FAM):
        T = TH[theta](z1, z2); q = C.QH if T == 0 else C.QL
        pr = (p if x else 1 - p) * F(1, 4) * ((1 - q) if n else q) * F(1, 4) * F(1, 6)
        f = fval(wb, o); r = (x ^ n) ^ f
        out.append((pr, dict(x=x, z1=z1, z2=z2, n=n, o=o, wb=wb, f=f, r=r, T=T, L=int(r == x))))
    return out
TRAIN_IDS = [((0, 1), 1), ((1, 0), 0), ((1, 0), 1), ((1, 1), 1)]   # held-out identities: ((1,1),0), ((0,1),0)
HELDOUT_IDS = [((1, 1), 0), ((0, 1), 0)]
table = lambda wb: tuple(fval(wb, o) for o in OS)
def nearest_train(wb):
    if wb in TRAIN_IDS: return wb
    return min(TRAIN_IDS, key=lambda t: (sum(a != b for a, b in zip(table(t), table(wb))), TRAIN_IDS.index(t)))

# ================================================================== witnesses (Shea / RR context)
# ctx: theta, p, ka, ki. 'decl' lists the inputs each code may read (audited in MB1).
def Tth(s, c): return TH[c['theta']](s['z1'], s['z2'])
def PHI(s, c): return phi_cf(s['r'], s['o'], Tth(s, c), s['f'], c['p'])
W = {
 'W1 regime code (theta-coupled)': dict(decl=['z1', 'z2', 'theta'], code=lambda s, c: Tth(s, c), kind='free'),
 'W2 input parity (fixed)':        dict(decl=['z1', 'z2'], code=lambda s, c: s['z1'] ^ s['z2'], kind='free'),
 'W3 process model (truth table)': dict(decl=['wb'], code=lambda s, c: table(s['wb']), kind='free'),
 'W5 token-phi monitor':           dict(decl=['o', 'r', 'z1', 'z2', 'theta', 'f', 'p'], code=PHI, kind='free'),
 'W6a per-cell tracker':           dict(decl=['wb'], code=lambda s, c: table(s['wb'])[:3], kind='free'),
 'W6b identity classifier':        dict(decl=['wb'], code=lambda s, c: table(nearest_train(s['wb'])), kind='free'),
 'W7 bundle W1+W3+W5':             dict(decl=['o', 'r', 'z1', 'z2', 'theta', 'f', 'p', 'wb'],
                                        code=lambda s, c: (Tth(s, c), table(s['wb']), PHI(s, c)), kind='free'),
 'B1-scalar reliability q_T':      dict(decl=['z1', 'z2', 'theta'], code=lambda s, c: C.QH if Tth(s, c) == 0 else C.QL, kind='free'),
 'B1-accept-value':                dict(decl=['o', 'r', 'z1', 'z2', 'theta', 'f', 'p', 'ka'], code=lambda s, c: PHI(s, c) + c['ka'], kind='accept'),
 'B1-invert-value':                dict(decl=['o', 'r', 'z1', 'z2', 'theta', 'f', 'p', 'ki'], code=lambda s, c: 1 - PHI(s, c) + c['ki'], kind='invert'),
 'B1-action-vector':               dict(decl=['o', 'r', 'z1', 'z2', 'theta', 'f', 'p', 'ka', 'ki'],
                                        code=lambda s, c: (PHI(s, c) + c['ka'], 1 - PHI(s, c) + c['ki']), kind='vector'),
}
CTX0 = dict(theta='xor', p=C.P_X, ka=F(0), ki=F(0))
PRED = {  # predicted (Shea, RR, Process) per v2/v2.1 section 6 and Ledger D/D-II
 'W1 regime code (theta-coupled)': ('fail', 'pass', 'fail'),
 'W2 input parity (fixed)':        ('fail', 'fail', 'fail'),
 'W3 process model (truth table)': ('fail', 'fail', 'pass'),
 'W5 token-phi monitor':           ('pass', 'fail', 'fail'),
 'W6a per-cell tracker':           ('fail', 'fail', 'fail'),
 'W6b identity classifier':        ('fail', 'fail', 'fail'),
 'W7 bundle W1+W3+W5':             ('pass', 'pass', 'pass'),
 'B1-scalar reliability q_T':      ('fail', 'fail', 'fail'),
 'B1-accept-value':                ('fail', 'n/e', 'fail'),
 'B1-invert-value':                ('fail', 'n/e', 'fail'),
 'B1-action-vector':               ('fail', 'n/e', 'fail'),
}

# ================================================================== MB1-B1 contract audit
def audit(ws, S):
    out = {}
    ctxs = [dict(CTX0), dict(CTX0, ka=F(1, 2)), dict(CTX0, ki=F(1, 3)), dict(CTX0, theta='z1'), dict(CTX0, p=F(1, 2))]
    for name, w in ws.items():
        seen = {}; ok = True
        for c in ctxs:
            for _, s in S:
                full = dict(s, **c)
                key = tuple(full[k] for k in w['decl'])
                v = w['code'](s, c)
                if key in seen and seen[key] != v: ok = False; break
                seen[key] = v
            if not ok: break
        out[name] = ok
    return out

# ================================================================== decoding phi-hat from a message
ATOMS0 = M0.atoms_from(M0.states_with(None))   # (R, phi) -> (mass, correct mass), oracle, p=7/10
def decoder_free(w, S, c):
    g = defaultdict(lambda: [F(0), F(0)])
    for pr, s in S: a = g[(w['code'](s, c), s['r'])]; a[0] += pr; a[1] += pr * s['L']
    return lambda m, r: (g[(m, r)][1] / g[(m, r)][0]) if g[(m, r)][0] else None, g
def decoder_rival(kind):
    it = [(r, f, m, c) for (r, f), (m, c) in ATOMS0.items()]
    def live(mv, r):
        if kind == 'accept': L = [x for x in it if x[0] == r and x[1] <= mv <= x[1] + 1]
        elif kind == 'invert': L = [x for x in it if x[0] == r and 1 - x[1] <= mv <= 2 - x[1]]
        else: L = [x for x in it if x[0] == r and x[1] <= mv[0] <= x[1] + 1 and 1 - x[1] <= mv[1] <= 2 - x[1]]
        return L
    def dec(mv, r):
        L = live(mv, r); m = sum(x[2] for x in L)
        return (sum(x[3] for x in L) / m) if m else None
    return dec

def rival_integrals(kind, d=D):
    """value at defer payoff d and calibration excess E[(phi_bar - phi)^2] for kappa-continuous rivals (piecewise exact)."""
    it = [(r, f, m, c) for (r, f), (m, c) in ATOMS0.items()]
    if kind == 'vector':
        bx = sorted({f for _, f, _, _ in it} | {f + 1 for _, f, _, _ in it})
        by = sorted({1 - f for _, f, _, _ in it} | {2 - f for _, f, _, _ in it})
        cells = [((x0 + x1) / 2, (y0 + y1) / 2, (x1 - x0) * (y1 - y0)) for x0, x1 in zip(bx, bx[1:]) for y0, y1 in zip(by, by[1:])]
        livef = lambda cell, r: [x for x in it if x[0] == r and x[1] <= cell[0] <= x[1] + 1 and 1 - x[1] <= cell[1] <= 2 - x[1]]
    else:
        sh = (lambda f: f) if kind == 'accept' else (lambda f: 1 - f)
        bps = sorted({sh(f) for _, f, _, _ in it} | {sh(f) + 1 for _, f, _, _ in it})
        cells = [((lo + hi) / 2, None, hi - lo) for lo, hi in zip(bps, bps[1:])]
        livef = lambda cell, r: [x for x in it if x[0] == r and sh(x[1]) <= cell[0] <= sh(x[1]) + 1]
    val = F(0); exc = F(0)
    for cell in cells:
        for r in (0, 1):
            L = livef(cell, r)
            if not L: continue
            m = sum(x[2] for x in L); c = sum(x[3] for x in L); pb = c / m
            val += cell[2] * max(c, m - c, d * m)
            exc += cell[2] * sum(x[2] * (pb - x[1]) ** 2 for x in L)
    return val, exc

# ================================================================== Shea clauses
VECTOR_BOUND = M0.relay_rival(ATOMS0, 'vector')            # 0.804052...
def shea(name, w, S):
    kind = w['kind']; res = {}
    if kind == 'free':
        dec, g = decoder_free(w, S, CTX0)
        res['S1a calibration excess'] = sum(pr * (dec(w['code'](s, CTX0), s['r']) - PHI(s, CTX0)) ** 2 for pr, s in S)
        valR = sum(max(c, m - c, D * m) for m, c in g.values())
    else:
        dec = decoder_rival(kind)
        valR, res['S1a calibration excess'] = rival_integrals(kind)
    ok = {'S1a calibration excess': res['S1a calibration excess'] == 0}
    # S1b tracking (MU-1): flip z1 with x, n, o, wb fixed -> R, X fixed, regime and phi change
    idx = {(s['x'], s['z1'], s['z2'], s['n'], s['o'], s['wb']): s for _, s in S}
    elig = trk = F(0)
    kgrid = [(F(0), F(0)), (F(1, 2), F(1, 2))] if kind != 'free' else [(F(0), F(0))]
    for pr, s in S:
        s2 = idx[(s['x'], 1 - s['z1'], s['z2'], s['n'], s['o'], s['wb'])]
        d_phi = PHI(s2, CTX0) - PHI(s, CTX0)
        if d_phi == 0: continue
        for ka, ki in kgrid:
            c = dict(CTX0, ka=ka, ki=ki); a, b = dec(w['code'](s, c), s['r']), dec(w['code'](s2, c), s2['r'])
            elig += pr; trk += pr * (a is not None and b is not None and (b - a) * d_phi > 0)
    res['S1b tracking rate'] = trk / elig; ok['S1b tracking rate'] = trk == elig
    # S1b nuisance (MU-2): payoff contexts change, phi fixed -> message must not change
    nuis = sum(pr for pr, s in S if w['code'](s, CTX0) != w['code'](s, dict(CTX0, ka=F(1, 2), ki=F(1, 2))))
    res['S1b nuisance change mass'] = nuis; ok['S1b nuisance change mass'] = nuis == 0
    # S1c consumer causality (MU-3): substitute M from s' (same R, different optimal action); relay acts on decoded content
    tot = hit = F(0)
    for (p1, s1), (p2, s2) in product(S, S):
        if s1['r'] != s2['r'] or act(PHI(s1, CTX0)) == act(PHI(s2, CTX0)): continue
        m2 = w['code'](s2, CTX0); ph = dec(m2, s1['r'])
        tot += p1 * p2; hit += p1 * p2 * (ph is not None and act(ph) == act(PHI(s2, CTX0)))
    res['S1c directional substitution rate'] = hit / tot; ok['S1c directional substitution rate'] = hit == tot
    # S1d token transplant (D7): M-only relay; M taken from same (o, T, f) with opposite R
    gM = defaultdict(lambda: [F(0), F(0)])
    for pr, s in S: a = gM[w['code'](s, CTX0)]; a[0] += pr; a[1] += pr * s['L']
    decM = lambda m: gM[m][1] / gM[m][0] if gM[m][0] else None
    tx = F(0)
    for pr, s in S:
        partner = [t for _, t in S if t['o'] == s['o'] and t['T'] == s['T'] and t['f'] == s['f'] and t['r'] != s['r']]
        if not partner: continue
        m_own, m_tx = w['code'](s, CTX0), w['code'](partner[0], CTX0)
        if kind != 'free': m_own, m_tx = m_own, m_tx        # kappa fixed at 0 for both
        a1, a2 = decM(m_own), decM(m_tx)
        if a1 is not None and a2 is not None and act(a1) != act(a2): tx += pr
    res['S1d transplant action-change mass'] = tx; ok['S1d transplant action-change mass'] = tx > 0
    # S1e held-out defer payoff (D10): consumer refits at d' with M frozen; must reach the full-information optimum
    s1e = True; vals = []
    for dp in (F(45, 100), F(65, 100)):
        opt = sum(pr * max(PHI(s, CTX0), 1 - PHI(s, CTX0), dp) for pr, s in S)
        v = (sum(max(c, m - c, dp * m) for m, c in g.values()) if kind == 'free' else rival_integrals(kind, dp)[0])
        vals.append((float(v), float(opt))); s1e &= (v == opt)
    res['S1e held-out d (value, optimum)'] = vals; ok['S1e held-out d (value, optimum)'] = s1e
    # S1f endogenous misrepresentation (MU-9): world prior -> 1/2; frozen encoder (p=7/10) and frozen interpretation
    Snew = world(p=F(1, 2)); mis = F(0)
    for pr, s in Snew:
        m = w['code'](s, CTX0); ph = dec(m, s['r'])
        if ph is not None and act(ph) != act(phi_cf(s['r'], s['o'], s['T'], s['f'], F(1, 2))): mis += pr
    res['S1f misrepresentation mass'] = mis; ok['S1f misrepresentation mass'] = mis > 0
    # S1h value vs rival-family bound (relay observes M, R; kappas hidden)
    res['S1h relay value (bound 0.804052)'] = valR; ok['S1h relay value (bound 0.804052)'] = valR > VECTOR_BOUND
    # S1h D11 constructed kappa intervention: match the full action-value vector, phi differs with different optimal action
    pairs = sep = 0
    for (_, s1), (_, s2) in combinations(S, 2):
        if s1['r'] != s2['r']: continue
        f1, f2 = PHI(s1, CTX0), PHI(s2, CTX0)
        if act(f1) == act(f2): continue
        a1, i1 = max(F(0), f2 - f1), max(F(0), f1 - f2)
        c1 = dict(CTX0, ka=a1, ki=i1); c2 = dict(CTX0, ka=a1 + f1 - f2, ki=i1 + f2 - f1)
        pairs += 1; sep += w['code'](s1, c1) != w['code'](s2, c2)
    res['S1h D11 separation (pairs separated / pairs)'] = f"{sep}/{pairs}"; ok['S1h D11 separation (pairs separated / pairs)'] = sep == pairs
    return res, ok

# ================================================================== RR clauses (oracle subproblem per (o, f); relay payoff)
CELLS = list(product((0, 1), repeat=3))   # (R, Z1, Z2)
def enc(m):
    if isinstance(m, tuple):
        out = []
        for x in m: out.extend(enc(x))
        return out
    return [float(m)]
def lp_weights(policy_idx, feats):
    k = len(next(iter(feats.values()))) + 1; rows = []
    for cl, a in policy_idx.items():
        xv = np.array(feats[cl] + [1.0])
        for o in range(3):
            if o != a:
                row = np.zeros(3 * k); row[o*k:(o+1)*k] = xv; row[a*k:(a+1)*k] -= xv; rows.append(row)
    r = linprog(np.zeros(3 * k), A_ub=np.array(rows), b_ub=-np.ones(len(rows)), bounds=[(None, None)] * (3 * k), method='highs')
    return r.x.reshape(3, k) if r.status == 0 else None
def sub_tables(S, w, c):
    """per (o, f): cell -> (mass, correct mass, message)"""
    T_ = defaultdict(lambda: defaultdict(lambda: [F(0), F(0), None]))
    for pr, s in S:
        cl = (s['r'], s['z1'], s['z2']); a = T_[(s['o'], s['f'])][cl]; a[0] += pr; a[1] += pr * s['L']
        if w is not None: a[2] = w['code'](s, c)
    return T_
def best_linear(tab, use_msg):
    pay = {cl: (v[1], v[0] - v[1], D * v[0]) for cl, v in tab.items()}
    feats = {cl: list(cl) + (enc(v[2]) if use_msg else []) for cl, v in tab.items()}
    pols = sorted(product(range(3), repeat=len(CELLS)), key=lambda t: -sum(pay[cl][a] for cl, a in zip(CELLS, t)))
    for t in pols:
        Wt = lp_weights(dict(zip(CELLS, t)), feats)
        if Wt is not None: return sum(pay[cl][a] for cl, a in zip(CELLS, t)), Wt
def apply_w(Wt, feat): return int(np.argmax(Wt @ np.array(feat + [1.0])))
def rr(name, w, S):
    res, ok = {}, {}
    if w['kind'] != 'free':
        return {'note': 'not evaluated: kappa-continuous code; the RR consumer class is defined on the finite cell set'}, None
    pre = sub_tables(S, w, CTX0); raw_v = msg_v = F(0); weights = {}
    for key, tab in pre.items():
        v0, _ = best_linear(tab, False); v1, Wt = best_linear(tab, True); raw_v += v0; msg_v += v1; weights[key] = Wt
    opt = sum(max(c, m - c, D * m) for tab in pre.values() for m, c, _ in tab.values())
    res['RR1b linear value without / with M (unrestricted optimum)'] = (float(raw_v), float(msg_v), float(opt))
    ok['RR1b linear value without / with M (unrestricted optimum)'] = (msg_v == opt) and (msg_v > raw_v)
    # RR1c rewiring theta -> z1, consumer frozen, M recomputed by its own declared function
    Spost = world(theta='z1'); cpost = dict(CTX0, theta='z1'); post = sub_tables(Spost, w, cpost); pv = F(0)
    for key, tab in post.items():
        for cl, (m, c, msg) in tab.items():
            a = apply_w(weights[key], list(cl) + enc(msg)); pv += (c, m - c, D * m)[a]
    res['RR1c post-rewire value, frozen consumer (pre 0.825) [ONE admissible consumer; identification in e0b_mb2_diag.py X1]'] = float(pv)
    ok['RR1c post-rewire value, frozen consumer (pre 0.825) [ONE admissible consumer; identification in e0b_mb2_diag.py X1]'] = pv >= msg_v
    # RR1d selective causal use: substitute M from another cell of the same subproblem; first-order R preserved
    ch = tot = F(0)
    for key, tab in pre.items():
        msgs = {v[2] for v in tab.values()}
        for cl, (m, c, msg) in tab.items():
            for alt in msgs:
                if alt == msg: continue
                tot += m; ch += m * (apply_w(weights[key], list(cl) + enc(alt)) != apply_w(weights[key], list(cl) + enc(msg)))
    res['RR1d substitution action-change mass'] = float(ch / tot) if tot else 0.0
    ok['RR1d substitution action-change mass'] = ch > 0
    # RR1f code relabelling (negation of every message coordinate), consumer refit
    neg = lambda m: tuple(neg(x) for x in m) if isinstance(m, tuple) else -m
    w2 = dict(w, code=lambda s, c: neg(w['code'](s, c))); relv = F(0)
    for key, tab in sub_tables(S, w2, CTX0).items(): relv += best_linear(tab, True)[0]
    res['RR1f relabelled value'] = float(relv); ok['RR1f relabelled value'] = relv == msg_v
    return res, ok

# ================================================================== Process clauses (traces at 00, 01, 10; query f(11))
OBS = [(0, 0), (0, 1), (1, 0)]
def process_blocks(k, prior_ids=None):
    """blocks: (prob, wb, counts) with exact multinomial-binomial probabilities; posterior over FAM (structured prior)."""
    p = C.pS1; lik = lambda f, j: comb(k, j) * (p**j * (1-p)**(k-j) if f == 0 else (1-p)**j * p**(k-j))
    out = []
    for wb in FAM:
        for js in product(range(k + 1), repeat=3):
            pr = F(1, 6)
            for o, j in zip(OBS, js): pr *= lik(fval(wb, o), j)
            out.append((pr, wb, js))
    return out
def posterior(js, k, ids=FAM):
    p = C.pS1; L = {}
    for wb in ids:
        l = F(1)
        for o, j in zip(OBS, js): l *= p**j * (1-p)**(k-j) if fval(wb, o) == 0 else (1-p)**j * p**(k-j)
        L[wb] = l
    z = sum(L.values()); return {wb: v / z for wb, v in L.items()}
def pred11(post): return sum(v for wb, v in post.items() if fval(wb, (1, 1)) == 1)
PROC = {   # process-context codes; trial-level codes see a scored trial at an observed input
 'W1 regime code (theta-coupled)': ('trial', lambda blk, tr: tr['T']),
 'W2 input parity (fixed)':        ('trial', lambda blk, tr: tr['z1'] ^ tr['z2']),
 'W3 process model (truth table)': ('block', lambda blk, tr: pred11(blk['post'])),
 'W5 token-phi monitor':           ('trial', lambda blk, tr: tr['phi']),
 'W6a per-cell tracker':           ('block', lambda blk, tr: blk['cellbits']),
 'W6b identity classifier':        ('block', lambda blk, tr: fval(blk['idmap'], (1, 1))),
 'W7 bundle W1+W3+W5':             ('trial', lambda blk, tr: (tr['T'], pred11(blk['post']), tr['phi'])),
 'B1-scalar reliability q_T':      ('trial', lambda blk, tr: tr['T']),
}
_PS = {}
def proc_states(k, ids_filter=None):
    if (k, ids_filter) in _PS: return _PS[(k, ids_filter)]
    out = []
    for pr, wb, js in process_blocks(k):
        if ids_filter and wb not in ids_filter: continue
        post = posterior(js, k); m1 = {o: sum(v for v_wb, v in post.items() if fval(v_wb, o) == 1) for o in OBS}
        cellbits = tuple((0 if 2 * j > k else 1 if 2 * j < k else F(1, 2)) for j in js)   # per-cell MAP from that cell alone
        idpost = posterior(js, k, TRAIN_IDS); idmap = max(TRAIN_IDS, key=lambda t: (idpost[t], -TRAIN_IDS.index(t)))
        blk = dict(wb=wb, post=post, cellbits=cellbits, idmap=idmap, y=fval(wb, (1, 1)))
        for x, z1, z2, n, o in product((0, 1), (0, 1), (0, 1), (0, 1), OBS):
            T = z1 ^ z2; q = C.QH if T == 0 else C.QL
            tp = (C.P_X if x else 1 - C.P_X) * F(1, 4) * ((1 - q) if n else q) * F(1, 3)
            r = (x ^ n) ^ fval(wb, o)
            ph = (1 - m1[o]) * phi_cf(r, o, T, 0, C.P_X) + m1[o] * phi_cf(r, o, T, 1, C.P_X)
            out.append((pr * tp, blk, dict(x=x, z1=z1, z2=z2, T=T, o=o, r=r, phi=ph)))
    _PS[(k, ids_filter)] = out
    return out
def unrestricted_acc(St, code):
    g = defaultdict(lambda: [F(0), F(0)])
    for pr, blk, tr in St: a = g[code(blk, tr)]; a[0] += pr; a[1] += pr * blk['y']
    return sum(max(c, m - c) for m, c in g.values()), g
def linear_acc(St, code, fit_on=None):
    """best linear-threshold decoder M -> f(11): exhaustive over integer weights on the (few) message coordinates."""
    pts = defaultdict(lambda: [F(0), F(0)])
    for pr, blk, tr in (fit_on or St): a = pts[code(blk, tr)]; a[0] += pr; a[1] += pr * blk['y']
    keys = list(pts); X = [enc(kk) for kk in keys]; dim = len(X[0])
    best = None; bestrule = None
    grid = range(-3, 4) if dim <= 3 else range(-1, 2)
    for wv in product(grid, repeat=dim):
        s_ = sorted({sum(a * b for a, b in zip(wv, x)) for x in X})
        cuts = [s_[0] - 1] + [(a + b) / 2 for a, b in zip(s_, s_[1:])] + [s_[-1] + 1]
        for t in cuts:
            for sign in (1, -1):
                rule = lambda x, wv=wv, t=t, sign=sign: int(sign * (sum(a * b for a, b in zip(wv, x)) - t) > 0)
                v = sum((c if rule(xx) else m - c) for (m, c), xx in zip(pts.values(), X))
                if best is None or v > best: best, bestrule = v, rule
    tot = sum(m for m, c in pts.values())
    if fit_on is None: return best / tot, bestrule
    ev = defaultdict(lambda: [F(0), F(0)])
    for pr, blk, tr in St: a = ev[code(blk, tr)]; a[0] += pr; a[1] += pr * blk['y']
    tot2 = sum(m for m, c in ev.values())
    return sum((c if bestrule(enc(kk)) else m - c) for kk, (m, c) in ev.items()) / tot2, bestrule
def process(name, k=5):
    if name not in PROC:
        # kappa-continuous rivals are garblings of (phi, kappa) with kappa independent of f(11): by data processing their
        # unrestricted decoder accuracy is <= W5's unrestricted accuracy, which is < the Bayes bound -> P1a cannot be met
        St = proc_states(k); ub, _ = unrestricted_acc(St, PROC['W5 token-phi monitor'][1]); bayes, _ = unrestricted_acc(St, PROC['W3 process model (truth table)'][1])
        return ({'P1a upper bound via W5 (data processing) vs Bayes': (float(ub), float(bayes))},
                {'P1a upper bound via W5 (data processing) vs Bayes': ub == bayes})
    lvl, code = PROC[name]; St = proc_states(k); res, ok = {}, {}
    bayes, _ = unrestricted_acc(St, PROC['W3 process model (truth table)'][1])
    ua, _ = unrestricted_acc(St, code); la, rule = linear_acc(St, code)
    res['P1a linear-decoder accuracy / unrestricted / Bayes (prior 0.5)'] = (float(la), float(ua), float(bayes))
    ok['P1a linear-decoder accuracy / unrestricted / Bayes (prior 0.5)'] = la == bayes
    # P1b held-out identities: decoder fitted on training identities, evaluated on held-out identities
    Str = [x for x in St if x[1]['wb'] in TRAIN_IDS]; Sho = [x for x in St if x[1]['wb'] in HELDOUT_IDS]
    hb, _ = linear_acc(Sho, code, fit_on=Str)
    bayes_ho, _ = unrestricted_acc(Sho, PROC['W3 process model (truth table)'][1]); bayes_ho /= sum(x[0] for x in Sho)
    res['P1b held-out-identity accuracy (structured Bayes on held-out)'] = (float(hb), float(bayes_ho))
    ok['P1b held-out-identity accuracy (structured Bayes on held-out)'] = hb > F(1, 2)
    # P1c relabelling invariance: constructed witnesses encode truth-table content only (no parameter-dependent
    # encoding exists), so invariance holds by construction at exact scope; the clause is retained for learned systems.
    res['P1c relabel invariance'] = 'holds by construction (no parameter-dependent encoding in constructed witnesses)'
    ok['P1c relabel invariance'] = True
    # P1d consumer causality: substitute M from another block/trial; decoder prediction must change on some mass
    msgs = list({code(blk, tr) for _, blk, tr in St})
    preds = {mm: rule(enc(mm)) for mm in msgs}
    res['P1d prediction varies with M'] = len(set(preds.values())) > 1; ok['P1d prediction varies with M'] = len(set(preds.values())) > 1
    # P1e ambiguity rule: with k=0 traces the structured posterior equals the prior -> inconclusive(non_identified), not fail
    St0 = proc_states(0); a0, _ = unrestricted_acc(St0, PROC['W3 process model (truth table)'][1])
    res['P1e k=0 Bayes accuracy (must be labelled non_identified)'] = float(a0)
    return res, ok

# ================================================================== MB1-B2/B3 consumer ladder and optimization gaps
def ladder():
    S = world(); tabs = sub_tables(S, None, CTX0); out = {}
    lin = one = unr = F(0)
    thr3 = []   # threshold functions over (R,Z1,Z2)
    for wv in product(range(-2, 3), repeat=3):
        for b2 in range(-7, 8):
            h = tuple(int(sum(a * x for a, x in zip(wv, cl)) * 2 > b2) for cl in CELLS)
            if h not in thr3: thr3.append(h)
    for key, tab in tabs.items():
        lin += best_linear(tab, False)[0]
        pay = {cl: (v[1], v[0] - v[1], D * v[0]) for cl, v in tab.items()}
        unr += sum(max(p) for p in pay.values())
        pols = sorted(product(range(3), repeat=8), key=lambda t: -sum(pay[cl][a] for cl, a in zip(CELLS, t)))
        bestv = None
        for t in pols:
            v = sum(pay[cl][a] for cl, a in zip(CELLS, t))
            if bestv is not None and v <= bestv: break
            for h in thr3:
                feats = {cl: list(cl) + [hh] for cl, hh in zip(CELLS, h)}
                if lp_weights(dict(zip(CELLS, t)), feats) is not None: bestv = v; break
            if bestv == v: break
        one += bestv
    out['linear-argmax'] = lin; out['one hidden threshold unit'] = one; out['unrestricted'] = unr
    return out, tabs, len(thr3)
def train_gaps(tabs, seeds=20, steps=20000, lr=5.0):
    """full-batch gradient ascent on exact expected payoff (softmax policy), then evaluate the greedy policy exactly"""
    keys = list(tabs); res = {'linear': [], 'one-hidden': []}
    Xc = np.array([list(cl) for cl in CELLS], float)
    for model in res:
        for seed in range(seeds):
            rng = np.random.default_rng(seed); total = 0.0
            for key in keys:
                tab = tabs[key]; P = np.array([[float(tab[cl][1]), float(tab[cl][0] - tab[cl][1]), float(D * tab[cl][0])] for cl in CELLS])
                mass = float(sum(tab[cl][0] for cl in CELLS)); P = P / mass          # train on the conditional problem
                if model == 'linear':
                    Wt = rng.normal(0, 1.0, (3, 4))
                    for _ in range(steps):
                        Z = np.c_[Xc, np.ones(8)] @ Wt.T; Pi = np.exp(Z - Z.max(1, keepdims=True)); Pi /= Pi.sum(1, keepdims=True)
                        G = Pi * (P - (Pi * P).sum(1, keepdims=True)); Wt += lr * G.T @ np.c_[Xc, np.ones(8)]
                    a = (np.c_[Xc, np.ones(8)] @ Wt.T).argmax(1)
                else:
                    V = rng.normal(0, 1.0, (1, 4)); Wt = rng.normal(0, 1.0, (3, 5))
                    for _ in range(steps):
                        H = 1 / (1 + np.exp(-(np.c_[Xc, np.ones(8)] @ V.T))); Xa = np.c_[Xc, H, np.ones(8)]
                        Z = Xa @ Wt.T; Pi = np.exp(Z - Z.max(1, keepdims=True)); Pi /= Pi.sum(1, keepdims=True)
                        G = Pi * (P - (Pi * P).sum(1, keepdims=True))
                        gW = G.T @ Xa; gH = (G @ Wt[:, 4:5]) * H * (1 - H); gV = gH.T @ np.c_[Xc, np.ones(8)]
                        Wt += lr * gW; V += lr * gV
                    H = 1 / (1 + np.exp(-(np.c_[Xc, np.ones(8)] @ V.T))); a = (np.c_[Xc, H, np.ones(8)] @ Wt.T).argmax(1)
                total += mass * float(sum(P[i, a[i]] for i in range(8)))
            res[model].append(total)
    return res

if __name__ == '__main__':
    import sys
    S = world()
    print("# E0-B MB1 + MB2 execution log\n")
    print("## MB1-B1 Contract audit (code is a function of declared inputs only)\n")
    for kname, okv in audit(W, S).items(): print(f"- {kname}: {'PASS' if okv else 'VIOLATION'}")
    cheat = {'NEGATIVE CONTROL: declares (o,r,z1,z2,theta,p) but reads f': dict(decl=['o', 'r', 'z1', 'z2', 'theta', 'p'], code=PHI, kind='free')}
    for kname, okv in audit(cheat, S).items(): print(f"- {kname}: {'PASS (audit insensitive!)' if okv else 'VIOLATION detected (audit is sensitive)'}")
    print("\n## MB1-B2 RR consumer ladder (exact, mapping-oracle subproblem, relay payoff)\n")
    lad, tabs, nthr = ladder()
    for kk, v in lad.items(): print(f"- {kk}: {float(v):.6f}")
    print(f"  ({nthr} distinct hidden threshold units enumerated)")
    print("\n## MB1-B3 Optimization gaps (20 seeds, full-batch gradient ascent on exact expected payoff; greedy policy evaluated exactly)\n")
    gaps = train_gaps(tabs)
    for model, vals in gaps.items():
        target = float(lad['linear-argmax'] if model == 'linear' else lad['one hidden threshold unit'])
        hitn = sum(abs(v - target) < 1e-9 for v in vals); sv = sorted(vals)
        print(f"- {model}: rung optimum {target:.6f}; trained min {sv[0]:.6f} / median {sv[10]:.6f} / max {sv[-1]:.6f}; seeds reaching optimum {hitn}/20")
    print("\n## MB2 Witness x predicate matrix (exact scope)\n")
    summary = []
    for name, w in W.items():
        print(f"### {name}\n")
        rs, oks = shea(name, w, S); vS = 'pass' if all(oks.values()) else 'fail'
        for kk, v in rs.items(): print(f"- Shea {kk}: {v if isinstance(v, (str, list, tuple)) else float(v):} -> {'ok' if oks[kk] else 'NOT MET'}")
        rr_r, rr_ok = rr(name, w, S)
        if rr_ok is None: vR = 'n/e'; print(f"- RR: {rr_r['note']}")
        else:
            vR = 'pass' if all(rr_ok.values()) else 'fail'
            for kk, v in rr_r.items(): print(f"- RR {kk}: {v} -> {'ok' if rr_ok[kk] else 'NOT MET'}")
        pr_r, pr_ok = process(name)
        if pr_ok is None: vP = 'n/e'; print(f"- Process: {pr_r['note']}")
        else:
            vP = 'pass' if all(pr_ok.values()) else 'fail'
            for kk, v in pr_r.items(): print(f"- Process {kk}: {v}" + (f" -> {'ok' if pr_ok[kk] else 'NOT MET'}" if kk in pr_ok else ""))
        summary.append((name, (vS, vR, vP), PRED[name])); print()
    print("## MB2 summary: observed (predicted)\n")
    print("| witness | Shea | RR | Process | matches prediction |")
    print("|---|---|---|---|---|")
    for name, obs, pred in summary:
        print(f"| {name} | {obs[0]} ({pred[0]}) | {obs[1]} ({pred[1]}) | {obs[2]} ({pred[2]}) | {'yes' if obs == pred else 'NO'} |")
