#!/usr/bin/env python3
"""E0-B automated numerical assertions, environment record, and deterministic re-run check (Ledger E).
Exits non-zero on any failed assertion. Writes ENVIRONMENT.txt. Run from the archive directory."""
import sys, platform, hashlib, subprocess
from fractions import Fraction as F
import numpy, scipy
import e0b_contracts as C
import e0b_mb0 as M0
import e0b_r24 as R24
import e0b_mb12 as M
import e0b_ledgerE as E

fails = []
def check(label, got, want, tol=None):
    ok = (got == want) if tol is None else abs(float(got) - float(want)) <= tol
    print(f"[{'PASS' if ok else 'FAIL'}] {label}: got {got if tol is None else f'{float(got):.6f}'} want {want if tol is None else f'{float(want):.6f}'}")
    if not ok: fails.append(label)

A0 = M0.atoms_from(M0.states_with(None))
check('oracle phi relay value', M0.relay_phi(A0), F(33, 40))
check('oracle B1-action-vector bound', M0.relay_rival(A0, 'vector'), 0.804052, 5e-7)
check('oracle B1-accept bound', M0.relay_rival(A0, 'accept'), 0.773828, 5e-7)
check('oracle vector bound, eps=1/3', M0.relay_rival(A0, 'vector', F(1, 3)), 0.729936, 5e-7)
A10 = M0.atoms_from(M0.states_with(C.map_bit_dist(10)))
check('k=10 marginal-MAP phi relay value', M0.relay_phi(A10), 0.716503, 5e-7)
check('R2.3 acceptance optimum', R24.acc_ref(R24.atoms(None)), F(488329, 435200))
check('R2.4 acceptance optimum', R24.acc_ref_r24(R24.atoms(None)), F(99623285189, 71024640000))
full, informed = E.p1b_contract(5)
check('P1b reference, decoder not told held-out population', full, 0.596178, 5e-7)
check('P1b reference, decoder told held-out population', informed, 0.665140, 5e-7)
r1, _ = E.rr1e()
check('RR1e W1 gain', r1['W1 regime code (theta-coupled)'][1] - r1['W1 regime code (theta-coupled)'][0], F(3, 160))
check('RR1e same-target learner gain', r1['same-target feature learner'][1] - r1['same-target feature learner'][0], F(3, 160))
check('RR1e shuffled parity gain', r1['shuffled parity (matched support)'][1] - r1['shuffled parity (matched support)'][0], F(0))
S = M.world()
check('S1e vacuity: min max(phi,1-phi)', min(max(M.phi_cf(s['r'], s['o'], s['T'], s['f'], C.P_X), 1 - M.phi_cf(s['r'], s['o'], s['T'], s['f'], C.P_X)) for _, s in S), F(7, 10))
check('probability mass of U1 world', sum(pr for pr, _ in S), F(1))

env = (f"python {platform.python_version()} ({platform.platform()})\nnumpy {numpy.__version__}\nscipy {scipy.__version__}\n")
open('ENVIRONMENT.txt', 'w').write(env); print("\n" + env)

# deterministic re-run: fast scripts run twice, outputs must be byte-identical
def run(script):
    return hashlib.sha256(subprocess.run([sys.executable, script], capture_output=True, check=True).stdout).hexdigest()
for script in ('e0b_r24.py', 'e0b_mb1_lsq.py', 'e0b_ledgerE_s1e.py'):
    h1, h2 = run(script), run(script)
    check(f'deterministic re-run {script}', h1, h2)

print(f"\n{len(fails)} failed assertion(s)" + (": " + ", ".join(fails) if fails else ""))
sys.exit(1 if fails else 0)
