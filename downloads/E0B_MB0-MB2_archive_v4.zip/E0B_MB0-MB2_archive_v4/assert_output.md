[PASS] oracle phi relay value: got 33/40 want 33/40
[PASS] oracle B1-action-vector bound: got 0.804052 want 0.804052
[PASS] oracle B1-accept bound: got 0.773828 want 0.773828
[PASS] oracle vector bound, eps=1/3: got 0.729936 want 0.729936
[PASS] k=10 marginal-MAP phi relay value: got 0.716503 want 0.716503
[PASS] R2.3 acceptance optimum: got 488329/435200 want 488329/435200
[PASS] R2.4 acceptance optimum: got 99623285189/71024640000 want 99623285189/71024640000
[PASS] P1b reference, decoder not told held-out population: got 0.596178 want 0.596178
[PASS] P1b reference, decoder told held-out population: got 0.665140 want 0.665140
[PASS] RR1e W1 gain: got 3/160 want 3/160
[PASS] RR1e same-target learner gain: got 3/160 want 3/160
[PASS] RR1e shuffled parity gain: got 0 want 0
[PASS] S1e vacuity: min max(phi,1-phi): got 7/10 want 7/10
[PASS] probability mass of U1 world: got 1 want 1

python 3.13.16 (Linux-6.18.44-fc-v80-x86_64-with-glibc2.39)
numpy 2.5.3
scipy 1.18.1

[PASS] deterministic re-run e0b_r24.py: got 07661412b9ccccd72c1274e24b896ed7368f98d198b4fe2a165be683898e28b6 want 07661412b9ccccd72c1274e24b896ed7368f98d198b4fe2a165be683898e28b6
[PASS] deterministic re-run e0b_mb1_lsq.py: got e986a42425a61cc679ca902fe1db87e369e596e820470e2bc0efee6d67278b99 want e986a42425a61cc679ca902fe1db87e369e596e820470e2bc0efee6d67278b99
[PASS] deterministic re-run e0b_ledgerE_s1e.py: got c6fb1bf6fdcd4f34d297ce739d135c90b6d4ed721b20ab9242a1b63b133ff1a7 want c6fb1bf6fdcd4f34d297ce739d135c90b6d4ed721b20ab9242a1b63b133ff1a7

0 failed assertion(s)
