#!/usr/bin/env python3
"""E0-B MB2 diagnostics, part 2 (tie / admissibility robustness of the remaining consumer-dependent clauses).

X3  RR1d: does EVERY admissible pre-optimal linear consumer change its action under some M substitution?
    (infeasibility of 'optimal policy AND all substitutions leave the action unchanged' => robust)
X4  P1b: all train-optimal linear decoders (within the registered integer grid) and the range of their held-out accuracy.
X5  MB1-B3 optimisation gaps with strengthened training (20 seeds, 20000 steps, lr 5, init scale 1).
"""
from fractions import Fraction as F
from itertools import product
from collections import defaultdict
import e0b_mb12 as M
from e0b_mb2_diag import feasible, optimal_policies

def rr1d_robust(name):
    w = M.W[name]; pre = M.sub_tables(M.world(), w, M.CTX0); robust = True
    for key, tab in pre.items():
        feats = {cl: list(cl) + M.enc(v[2]) for cl, v in tab.items()}; k = len(next(iter(feats.values()))) + 1
        msgs = {v[2] for v in tab.values()}
        _, pols = optimal_policies(tab, feats)
        for t in pols:
            cons = [(feats[cl], a) for cl, a in zip(M.CELLS, t)]
            cons += [(list(cl) + M.enc(alt), a) for cl, a in zip(M.CELLS, t) for alt in msgs if alt != tab[cl][2]]
            if feasible(cons, k): robust = False
    return robust

def p1b_range(code, k=5):
    St = M.proc_states(k)
    Str = [x for x in St if x[1]['wb'] in M.TRAIN_IDS]; Sho = [x for x in St if x[1]['wb'] in M.HELDOUT_IDS]
    def pts(S):
        g = defaultdict(lambda: [F(0), F(0)])
        for pr, blk, tr in S: a = g[code(blk, tr)]; a[0] += pr; a[1] += pr * blk['y']
        return g
    ptr, pho = pts(Str), pts(Sho); keys = list(set(ptr) | set(pho)); X = {kk: M.enc(kk) for kk in keys}
    dim = len(next(iter(X.values()))); grid = range(-3, 4) if dim <= 3 else range(-1, 2)
    rules = []
    for wv in product(grid, repeat=dim):
        s_ = sorted({sum(a * b for a, b in zip(wv, X[kk])) for kk in keys})
        cuts = [s_[0] - 1] + [(a + b) / 2 for a, b in zip(s_, s_[1:])] + [s_[-1] + 1]
        for t in cuts:
            for sg in (1, -1):
                lab = {kk: int(sg * (sum(a * b for a, b in zip(wv, X[kk])) - t) > 0) for kk in keys}
                vtr = sum((c if lab[kk] else m - c) for kk, (m, c) in ptr.items())
                rules.append((vtr, lab))
    best = max(v for v, _ in rules); tied = {tuple(sorted(l.items())) for v, l in rules if v == best}
    tho = sum(m for m, c in pho.values())
    accs = [sum((c if dict(l)[kk] else m - c) for kk, (m, c) in pho.items()) / tho for l in tied]
    return len(tied), min(accs), max(accs)

if __name__ == '__main__':
    print("## X3 RR1d robustness over admissible consumers\n")
    for name in ['W1 regime code (theta-coupled)', 'W2 input parity (fixed)', 'W5 token-phi monitor', 'B1-scalar reliability q_T']:
        print(f"- {name}: every admissible optimal consumer uses M under substitution = {rr1d_robust(name)}")
    print("\n## X4 P1b: train-optimal decoders and held-out accuracy range (k = 5)\n")
    print("| witness | train-optimal decoder labelings | held-out accuracy min | max |")
    print("|---|---|---|---|")
    for name, (lvl, code) in M.PROC.items():
        n, lo, hi = p1b_range(code); print(f"| {name} | {n} | {float(lo):.6f} | {float(hi):.6f} |")
    print("\n## X5 MB1-B3 optimisation gaps (strengthened training)\n")
    S = M.world(); tabs = M.sub_tables(S, None, M.CTX0); lad = {'linear': 0.80625, 'one-hidden': 0.825}
    g = M.train_gaps(tabs)
    for model, vals in g.items():
        hit = sum(abs(v - lad[model]) < 1e-9 for v in vals); sv = sorted(vals)
        print(f"- {model}: rung optimum {lad[model]:.6f}; trained min {sv[0]:.6f} / median {sv[10]:.6f} / max {sv[-1]:.6f}; seeds reaching optimum {hit}/20")
