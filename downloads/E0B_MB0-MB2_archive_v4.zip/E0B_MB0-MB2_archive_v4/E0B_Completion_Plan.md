# E0-B — Completion Plan and Decision Record

**8 October 2026 · decisions by Ben, recorded verbatim in substance · applies to v2.2 + Ledgers D and D-II**

## 1. Decisions (approved by Ben, operational defaults)

These stand without another review cycle unless an implementation constraint contradicts them.

1. **Balanced input allocation.** All four public inputs are covered equally in each inference phase, in randomized order. Random allocation is kept as a secondary robustness condition.
2. **Separated phases.** Dedicated inference trials, then separate scoring trials. The encoder's mapping estimate is frozen before scoring, and no updating from scored trials is allowed.
3. **Budget identity.** \(B = B_{\text{trace}} + B_{\text{score}}\), and \(k = B_{\text{trace}}/4\).
4. **No numerical B yet.** B must come from the intended experiment, not be retrofitted to give a favourable gap.
5. **Scope.** E0-B is separately scoped and is **not a gate on E1**. E0-A already met E1's prerequisite.
6. **Finite scope.** One remaining MB0 freeze, two executable validation milestones (MB1, MB2), and one go/no-go decision on confirmation. No further theoretical repair unless witness tests expose a genuine, previously unidentified defect.
7. **No rescue redesign.** Once every declared witness has an explained result, the fixture is not redesigned merely because a favoured index fails.

## 2. Stopping criterion — E0-B is COMPLETE when

1. Every index has a frozen, executed, auditable test, **or** an explicit, justified determination that it cannot be identified under the authorized design.
2. Every reported conclusion survives its registered rival comparisons and uncertainty controls.
3. All discrepancies and cross-passes have documented dispositions.
4. The final record separates empirical findings from representational interpretations.
5. No necessary experiment remains unfinished, and the artifacts needed to reproduce the conclusions are archived.

Completion does not require any index to pass, nor a unified theory of metarepresentation.

**Approved by Ben, 8 Oct 2026:** this criterion is frozen together with the MB0 freeze. Afterwards it changes only through the amendment rule in §6.

## 3. Reference values closed in this round

R2.4 acceptance-consumer optimum, \(E[\max(\varphi+\kappa_a,\ 1-\varphi+\kappa_i,\ 0.55+\kappa_d)]\), independently reproduced by exact piecewise-polynomial integration (`e0b_r24.py`, E4):

| Information | Value |
|---|---|
| public observations only | 1.318554 |
| mapping from 40 traces per input (marginal MAP) | 1.376884 |
| mapping oracle | 1.402658 (= 99623285189 / 71024640000) |

These replace the R2.3 acceptance references for R2.4.

**Qualification recorded in the freeze.** R2.4 defeats codes derived **only** from the payoff-inclusive action-value vector. An encoder that also uses the payoff contexts it can see can subtract the bonuses and recover φ. The broader correctness / correctness-contingent-value equivalence therefore remains, as Ledger D-II §3 states.

## 4. Work packages and status

| Package | Contents | Status |
|---|---|---|
| **A. MB0 freeze** | register the R2.4 rival family and interpretation limits; channel-dependent reference tables; D11 empirical caliper rule; joint-MAP estimator; set B_trace / B_score, then margins | open: 5 items. Allocation and phase rules are now decided |
| **B. MB1** | execute and archive access-contract, consumer-ladder and optimization-gap checks | not started |
| **C. MB2** | execute the W1–W9 witness matrix against the Shea, RR and Process predicates with D1–D11; dispose of every cross-pass | not started; **the decisive milestone** |
| **D. Confirmation / closeout** | conditional on MB2: frozen learned-system runs, uncertainty and multiplicity controls, reason-coded outcomes; or a narrowed claim if the Shea rivals remain equivalent | conditional |

## 5. Risks to completion (auditor's notes)

1. **Scrutiny has been uneven.** The last three review rounds examined Shea almost exclusively. RR and Process were reproduced numerically but not attacked adversarially to the same depth. MB2 may surface defects there. Under §1.6 those count as legitimate new defects, not scope creep.
2. **RR may be underpowered — a prospective risk, not an established outcome.** Its noiseless reference gap is small: 0.019 with the mapping known and 0.002 at k = 10 (Contract Table). Power cannot be inferred from the reference gap alone, though. It also depends on the evaluation sample size, the variance and the registered decision rule. A power analysis is due once B_trace and B_score are fixed. `inconclusive(underpowered)` would be a valid completion outcome under §2. *(Wording corrected per Ben, 8 Oct 2026.)*
3. **Shea's ceiling is already known.** Even a clean S1h pass yields at most the functional finding in Ledger D-II §3. Interpretation beyond that is out of E0-B's reach by identity, not by effort.

## 6. Amendment rule (approved by Ben, 8 Oct 2026; part of the MB0 freeze)

Every change after the MB0 freeze records:
1. **Reason:** the new evidence, implementation constraint or genuine defect that requires it.
2. **Change:** the exact original and replacement requirements.
3. **Provenance:** date, authorizing decision, affected protocol version.
4. **Impact:** whether completed tests, reference values or interpretations are affected.
5. **Disposition:** whether affected results remain confirmatory, need re-evaluation, or must be labelled exploratory.

The original specification and results are always preserved. **An amendment cannot retroactively turn an unfavourable outcome into a pass.** If a defect is found after results are observed, the original outcome is recorded, and the corrected protocol is evaluated separately.

## 7. Governance status

**Closed (8 Oct 2026).**
- Success means resolving the registered questions, not obtaining positive results.
- Revision is controlled by the amendment rule.
- Scope is MB0–MB2 plus one conditional confirmation decision.
- The scientific ceiling is explicit: functional discrimination does not establish strict metarepresentation.

No further theoretical work is required before the remaining MB0 implementation tasks. **The next milestone is execution.**
