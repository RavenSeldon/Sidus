# E0-B power analysis (reference contrasts; float64 Monte Carlo moments + normal approximation)

Consistency check: simulated per-trial means vs exact reference gaps are printed below each k.

Blocks needed for power 0.80, one-sided; alpha 0.05 (and 0.05/3 Holm-conservative); margin = 0 or half the reference effect.

| index | k per input | mu (per trial / block) | sb2 | sw2 | B_score | N blocks, margin 0 | N blocks, margin mu/2 | N at alpha/3, margin mu/2 |
|---|---|---|---|---|---|---|---|---|
| (check k=10) | exact Shea gap 0.00977 vs simulated 0.01018 | | | | | | | |
| Shea S1h | 10 | 0.01018 | 1.03e-03 | 0.0302 | 20 | 152 | 606 | 864 |
| Shea S1h | 10 | 0.01018 | 1.03e-03 | 0.0302 | 50 | 98 | 390 | 556 |
| Shea S1h | 10 | 0.01018 | 1.03e-03 | 0.0302 | 100 | 80 | 318 | 453 |
| Shea S1h | 10 | 0.01018 | 1.03e-03 | 0.0302 | 200 | 71 | 282 | 401 |
| RR RR1b | 10 | 0.00143 | 8.53e-04 | 0.0250 | 20 | 6330 | 25319 | 36115 |
| RR RR1b | 10 | 0.00143 | 8.53e-04 | 0.0250 | 50 | 4072 | 16288 | 23234 |
| RR RR1b | 10 | 0.00143 | 8.53e-04 | 0.0250 | 100 | 3320 | 13278 | 18940 |
| RR RR1b | 10 | 0.00143 | 8.53e-04 | 0.0250 | 200 | 2944 | 11773 | 16793 |
| (check k=20) | exact Shea gap 0.02240 vs simulated 0.02195 | | | | | | | |
| Shea S1h | 20 | 0.02195 | 2.14e-03 | 0.0828 | 20 | 81 | 323 | 460 |
| Shea S1h | 20 | 0.02195 | 2.14e-03 | 0.0828 | 50 | 49 | 195 | 278 |
| Shea S1h | 20 | 0.02195 | 2.14e-03 | 0.0828 | 100 | 39 | 153 | 218 |
| Shea S1h | 20 | 0.02195 | 2.14e-03 | 0.0828 | 200 | 33 | 132 | 187 |
| RR RR1b | 20 | 0.00732 | 7.16e-04 | 0.0221 | 20 | 211 | 842 | 1201 |
| RR RR1b | 20 | 0.00732 | 7.16e-04 | 0.0221 | 50 | 134 | 536 | 764 |
| RR RR1b | 20 | 0.00732 | 7.16e-04 | 0.0221 | 100 | 109 | 433 | 618 |
| RR RR1b | 20 | 0.00732 | 7.16e-04 | 0.0221 | 200 | 96 | 382 | 545 |
| (check k=40) | exact Shea gap 0.02640 vs simulated 0.02644 | | | | | | | |
| Shea S1h | 40 | 0.02644 | 5.74e-04 | 0.0503 | 20 | 28 | 110 | 156 |
| Shea S1h | 40 | 0.02644 | 5.74e-04 | 0.0503 | 50 | 14 | 56 | 80 |
| Shea S1h | 40 | 0.02644 | 5.74e-04 | 0.0503 | 100 | 10 | 39 | 55 |
| Shea S1h | 40 | 0.02644 | 5.74e-04 | 0.0503 | 200 | 8 | 30 | 42 |
| RR RR1b | 40 | 0.01850 | 3.76e-04 | 0.0192 | 20 | 25 | 97 | 138 |
| RR RR1b | 40 | 0.01850 | 3.76e-04 | 0.0192 | 50 | 14 | 55 | 79 |
| RR RR1b | 40 | 0.01850 | 3.76e-04 | 0.0192 | 100 | 11 | 42 | 59 |
| RR RR1b | 40 | 0.01850 | 3.76e-04 | 0.0192 | 200 | 9 | 35 | 49 |
| Process P1a | 10 (3 inputs) | 0.13761 | 0.2311 (block) | - | - | 76 | 302 | 431 |
| Process P1a | 20 (3 inputs) | 0.20181 | 0.2093 (block) | - | - | 32 | 128 | 182 |
| Process P1a | 40 (3 inputs) | 0.29384 | 0.1637 (block) | - | - | 12 | 47 | 67 |

Validation: Shea, k=40, B_score=50, N=13 blocks -> simulated power 0.770 over 300 replications (target 0.80; t-statistic on block means).
