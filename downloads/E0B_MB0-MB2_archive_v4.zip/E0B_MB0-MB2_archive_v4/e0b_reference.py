#!/usr/bin/env python3
"""E0-B reference checks — exact rational arithmetic, no sampling.

Part A re-derives every [REF] value in the 7 Oct 2026 E0-B draft.
Part B derives the reference values for the proposed unified fixture U1 (E0-B v2 §3).
Requires: numpy, scipy (only for the linear-argmax realizability LPs in B5).
Run: python3 e0b_reference.py
"""
from fractions import Fraction as F
from itertools import product, combinations
from math import comb, log, ceil
import numpy as np
from scipy.optimize import linprog

def hdr(s): print("\n== " + s)

# ----------------------------------------------------------------------------- Part A
hdr("A1 spine (X fair, q_Z in {0.9,0.6}, d=0.75)")
d0 = F(3, 4); Q0 = {0: F(9, 10), 1: F(6, 10)}
def spine():
    for x, z, n in product((0, 1), repeat=3):
        q = Q0[z]; yield F(1, 4) * ((1 - q) if n else q), x, z, x ^ n
blind = max(sum(p for p, x, z, r in spine() if r == x), d0)
oracle = sum(F(1, 2) * max(Q0[z], d0) for z in (0, 1))
def noisy(flip):
    v = 0
    for m in (0, 1):
        pm = sum(F(1, 2) * ((1 - flip) if m == z else flip) for z in (0, 1))
        pc = sum(F(1, 2) * ((1 - flip) if m == z else flip) * Q0[z] for z in (0, 1))
        v += max(pc, d0 * pm)
    return v
minpair = min(sum(p for p, x, z, r in spine() if (x, r, z) == k) for k in product((0, 1), repeat=3))
print(f"regime-blind {blind}  oracle {oracle}={float(oracle)}  noisy(0.1) {float(noisy(F(1,10)))}  min pair mass {float(minpair)}")
print("token-dependence of phi in the spine: P(R=X | R=r, Z) =",
      {z: [str(Q0[z])] * 2 for z in (0, 1)}, "-> phi is a function of Z alone (bijection Z<->phi)")

hdr("A2 RR layer: best affine threshold on (Z1,Z2)")
cells2 = list(product((0, 1), repeat=2))
def lin_sep(S):
    return any(all(((a*z1 + b*z2 + c) > 0) == ((z1, z2) in S) for z1, z2 in cells2)
               for a, b, c in product(range(-3, 4), repeat=3))
subsets = [frozenset(s) for k in range(5) for s in combinations(cells2, k)]
seps = [S for S in subsets if lin_sep(S)]
val = lambda S: sum(F(1, 4) * (Q0[z1 ^ z2] if (z1, z2) in S else d0) for z1, z2 in cells2)
print(f"threshold functions {len(seps)}/16  best affine {float(max(map(val, seps)))}  unrestricted {float(max(map(val, subsets)))}")

hdr("A3 process layer")
tables = list(product((0, 1), repeat=4)); vs = [t for t in tables if t[0] == 0]
qa = F(sum(t[2] == 0 for t in vs), len(vs))
print(f"version space after 00->0: {len(vs)}/16; Bayes accuracy at (1,0): {max(qa, 1-qa)}")
for nm, f in (("F0=a", lambda a, b: a), ("F1=b", lambda a, b: b)):
    print(f"  {nm} accuracy vs a^b: {F(sum(f(a,b) == (a^b) for a, b in cells2), 4)}")

hdr("A4 statistics")
print(f"one-sided 95% exact lower bound at 3/3: {0.05**(1/3):.3f};  n needed (all successes) for L>=0.9: {ceil(log(0.05)/log(0.9))}")
z = 1.959964; print(f"Wilson 95% upper bound at 0/100: {z*z/(100+z*z):.4f}")

# ----------------------------------------------------------------------------- Part B
# U1: X~Bern(p); Z1,Z2 fair private; regime T=h(Z1,Z2) implemented implicitly by the first-order procedure;
# N~Bern(1-q_T); S=X^N; public input o in {0,1}^2 uniform; block-level process identity w in {01,10,11}
# (reliability-matched GF(2)-linear family); f=w.o mod 2; first-order report R=S^f, read as the claim X=R.
P_, QH, QL, D = F(7, 10), F(19, 20), F(1, 2), F(11, 20)
WF = [(0, 1), (1, 0), (1, 1)]; OS = list(product((0, 1), repeat=2))
hdr(f"B U1 at p={P_}, q_T0={QH}, q_T1={QL}, d={D}; consumer actions accept R / invert R / defer")
def states(p=P_, h=lambda a, b: a ^ b, wset=WF):
    for x, z1, z2, n, o, w in product((0, 1), (0, 1), (0, 1), (0, 1), OS, wset):
        T = h(z1, z2); q = QH if T == 0 else QL
        pr = (p if x else 1 - p) * F(1, 4) * ((1 - q) if n else q) * F(1, 4) * F(1, len(wset))
        f = (w[0]*o[0] + w[1]*o[1]) % 2; r = (x ^ n) ^ f
        yield pr, dict(x=x, z1=z1, z2=z2, T=T, n=n, o=o, w=w, f=f, r=r, L=int(r == x))
def value(info, **kw):
    g = {}
    for pr, s in states(**kw):
        a = g.setdefault(info(s), [0, 0]); a[0] += pr; a[1] += pr * s['L']
    return sum(max(pc, m - pc, D * m) for m, pc in g.values())
CL = {'B0-public (o,R)': lambda s: (s['o'], s['r']),
      'W1 regime (o,R,T)': lambda s: (s['o'], s['r'], s['T']),
      'W3 process (o,R,w)': lambda s: (s['o'], s['r'], s['w']),
      'no-token (o,T,w)': lambda s: (s['o'], s['w'], s['T']),
      'token phi (o,R,T,w)': lambda s: (s['o'], s['r'], s['T'], s['w'])}
hdr("B1 consumer value by information class")
for k, f in CL.items(): v = value(f); print(f"  {k:22s} {v} = {float(v):.4f}")
print("  aggregate accuracy of R per mapping:",
      {w: str(sum(pr*s['L'] for pr, s in states() if s['w'] == w) * 3) for w in WF}, "(reliability-matched)")

def phi(r, o, T, w, p=P_):
    q = QH if T == 0 else QL; f = (w[0]*o[0] + w[1]*o[1]) % 2; s = r ^ f
    px = lambda x: p if x else 1 - p
    pn0 = px(s) * q / (px(s) * q + px(1 - s) * (1 - q))
    return pn0 if f == 0 else 1 - pn0
act = lambda f: max((f, 'accept'), (1 - f, 'invert'), (D, 'defer'))[1]
hdr("B2 token dependence of phi (fixed regime and mapping, varying R)")
for T in (0, 1): print(f"  T={T}: phi(R=0)={phi(0,(0,0),T,(0,1))}  phi(R=1)={phi(1,(0,0),T,(0,1))}")
hdr("B3 D7 token transplant (M from same o,T,w but opposite R; R untouched)")
m = sum(pr for pr, s in states() if act(phi(s['r'], s['o'], s['T'], s['w'])) != act(phi(1-s['r'], s['o'], s['T'], s['w'])))
print(f"  token-phi consumer action-change mass {m};  regime-only message identical by construction -> 0")
hdr("B4 prior shift p 7/10 -> 1/2 with M frozen (endogenous misrepresentation)")
m = sum(pr for pr, s in states() if act(phi(s['r'], s['o'], s['T'], s['w'])) != act(phi(s['r'], s['o'], s['T'], s['w'], p=F(1, 2))))
print(f"  action-relevant misrepresentation mass {m}")

hdr("B5 RR accessibility, given (o,w): 3-action linear-argmax consumer over (R,Z1,Z2), with/without parity feature")
cells = list(product((0, 1), repeat=3)); A = ['accept', 'invert', 'defer']
def realizable(pol, fe):
    k = len(fe(cells[0])) + 1; rows = []
    for cl in cells:
        x = np.array(list(fe(cl)) + [1.0]); a = A.index(pol[cl])
        for o in range(3):
            if o != a:
                row = np.zeros(3*k); row[o*k:(o+1)*k] = x; row[a*k:(a+1)*k] -= x; rows.append(row)
    return linprog(np.zeros(3*k), A_ub=np.array(rows), b_ub=-np.ones(len(rows)),
                   bounds=[(None, None)] * (3*k), method='highs').status == 0
def rr(o, w):
    g = {cl: [F(0), F(0)] for cl in cells}
    for pr, s in states():
        if s['o'] == o and s['w'] == w:
            a = g[(s['r'], s['z1'], s['z2'])]; a[0] += pr; a[1] += pr * s['L']
    tot = sum(a[0] for a in g.values())
    pay = {cl: {'accept': a[1]/tot, 'invert': (a[0]-a[1])/tot, 'defer': D*a[0]/tot} for cl, a in g.items()}
    pols = sorted(product(A, repeat=8), key=lambda t: -sum(pay[cl][a] for cl, a in zip(cells, t)))
    out = {'unrestricted': sum(pay[cl][a] for cl, a in zip(cells, pols[0]))}
    for nm, fe in (('affine raw', lambda cl: cl), ('affine + parity', lambda cl: (*cl, cl[1] ^ cl[2]))):
        out[nm] = next(sum(pay[cl][a] for cl, a in zip(cells, t)) for t in pols if realizable(dict(zip(cells, t)), fe))
    return out
res = {(o, w): rr(o, w) for o in OS for w in WF}
distinct = {tuple(v.values()) for v in res.values()}
print(f"  identical across all 12 (o,w) cells: {len(distinct) == 1}")
for k, v in next(iter(res.values())).items(): print(f"  {k:16s} {v} = {float(v):.5f}")

hdr("B6 RR provenance: procedure rewired T=Z1^Z2 -> T'=Z1, outcome feedback withheld")
def post(report):
    v = F(0)
    for pr, s in states(h=lambda a, b: a):
        a = act(phi(s['r'], s['o'], report(s), s['w']))
        v += pr * (s['L'] if a == 'accept' else 1 - s['L'] if a == 'invert' else D)
    return v
print(f"  procedure-coupled code {float(post(lambda s: s['T'])):.4f}   input-wired parity code {float(post(lambda s: s['z1'] ^ s['z2'])):.4f}")

hdr("B7 process: inferring an inversion bit f(o) for one cell from k unlabeled R (T unobserved)")
pS = P_ * (QH + QL) / 2 + (1 - P_) * (1 - (QH + QL) / 2)
print(f"  P(S=1) = {pS}")
print("     k   cell-bit Bayes acc a   held-out o=11, plug-in a^2+(1-a)^2 (not full Bayes)   per-cell tracker at unseen cell")
for k in (10, 20, 40, 80, 160):
    a = sum(max(comb(k, j)*pS**j*(1-pS)**(k-j), comb(k, j)*(1-pS)**j*pS**(k-j)) / 2 for j in range(k + 1))
    print(f"   {k:4d}   {float(a):.4f}               {float(a*a + (1-a)*(1-a)):.4f}                                  0.5")
print("  held-out identity: id-classifier trained on w in {01,10} cannot emit 11; a linear-structure model predicts f_11(o)=o1^o2")

# ----------------------------------------------------------------------------- Part C (v2.1 audit)
# Checks the second external review's findings against U1 and computes the v2.1 repairs.
# Parts A-B are kept unchanged as the v2 record; where Part C corrects a Part B reading, it says so.
hdr("C1 RR1a: linear decodability of T = Z1^Z2 from raw (Z1,Z2)  [v2 said 'at chance' - wrong]")
best = max(sum(F(1, 4) for z1, z2 in cells2 if (((a*z1 + b*z2 + c) > 0) == bool(z1 ^ z2)))
           for a, b, c in product(range(-3, 4), repeat=3))
print(f"  best linear threshold accuracy for T: {best} (chance = 1/2, perfect = 1)")

hdr("C2a Shea vs action-value: phi equals E[payoff of accept | o,R,T,w] in U1")
ok = all(abs(phi(s['r'], s['o'], s['T'], s['w']) -
             sum(pr2*s2['L'] for pr2, s2 in states() if (s2['o'], s2['r'], s2['T'], s2['w']) == (s['o'], s['r'], s['T'], s['w'])) /
             sum(pr2 for pr2, s2 in states() if (s2['o'], s2['r'], s2['T'], s2['w']) == (s['o'], s['r'], s['T'], s['w']))) == 0
         for pr, s in states())
print(f"  identity holds on every cell: {ok}")
print(f"  [v2 comparator correction] regime+process WITH R, i.e. (o,R,T,w): {float(value(CL['token phi (o,R,T,w)']))} "
      f"- the same information set as the 'token phi' row; the 0.075 gap was against a class that withheld R")

hdr("C2b Repair: payoff context kappa decouples acceptance payoff from correctness")
BETA = F(2, 5)   # bonus for ACCEPTING when R=0 under kappa=1; chosen so an exact matched-Q pair exists and relay actions move
def Q(r, o, T, w, kappa): return phi(r, o, T, w) + BETA * kappa * (r == 0)
A_ = ((1, (0, 0), 1, (0, 1)), 0)   # T=1, f=0, R=1, kappa=0
B_ = ((0, (0, 0), 1, (0, 1)), 1)   # T=1, f=0, R=0, kappa=1
for nm, (args, k) in (("cell A", A_), ("cell B", B_)):
    print(f"  {nm}: phi={phi(*args)}  Q_accept={Q(*args, k)}")
print("  matched-Q / different-phi pair (A,B): correctness code differs, action-value code identical")
print(f"  matched-phi / different-Q pair (B at kappa 0 vs 1): phi {phi(*B_[0])} both; Q {Q(*B_[0],0)} vs {Q(*B_[0],1)}")
def relay_value(msg):   # second consumer paid on correctness only, reads M as a correctness probability
    v = F(0)
    for pr, s in states():
        for kappa in (0, 1):
            a = act(min(max(msg(s, kappa), F(0)), F(1)))
            v += pr * F(1, 2) * (s['L'] if a == 'accept' else 1 - s['L'] if a == 'invert' else D)
    return v
rp = relay_value(lambda s, k: phi(s['r'], s['o'], s['T'], s['w']))
rq = relay_value(lambda s, k: Q(s['r'], s['o'], s['T'], s['w'], k))
print(f"  correctness-only relay consumer: phi-code {rp} = {float(rp):.4f}  vs action-value code {rq} = {float(rq):.4f}  (kappa fair)")

hdr("C3 W5: is T recoverable from the scalar phi code?")
vals = {T: sorted({phi(s['r'], s['o'], T, s['w']) for _, s in states() if s['T'] == T}) for T in (0, 1)}
for T in (0, 1): print(f"  T={T}: {[round(float(v), 4) for v in vals[T]]}")
print(f"  disjoint: {not set(vals[0]) & set(vals[1])} -> interval decoder recovers T perfectly [v2 'no accessible T code' - wrong as stated]")
masses = {}
for pr, s in states():
    k = phi(s['r'], s['o'], s['T'], s['w']); masses.setdefault(k, [0, 0])[s['T']] += pr
xs = sorted(masses)
best1 = max(sum((masses[x][1] if (x > t) == up else masses[x][0]) for x in xs)
            for t in [F(0)] + xs for up in (True, False))
print(f"  best single-threshold (linear) decoder of T from phi: {best1} = {float(best1)}")

hdr("C4a v2 process family {01,10,11}: f_w(11) is label-imbalanced")
print(f"  f_w(11): { {w: (w[0]+w[1]) % 2 for w in WF} }  -> always-1, no traces: {F(2,3)}")
def bayes_heldout(family, trace_cells, query, k):
    # exact trace-conditioned Bayes accuracy for f(query); k i.i.d. R samples per trace cell, T and X unobserved
    lik = lambda f, j: pS**j * (1 - pS)**(k - j) if f == 0 else (1 - pS)**j * pS**(k - j)  # j = #(R=1)
    fval = lambda wb, o: ((wb[0][0]*o[0] + wb[0][1]*o[1]) + wb[1]) % 2
    acc = F(0)
    for js in product(range(k + 1), repeat=len(trace_cells)):
        mult = 1
        for j in js: mult *= comb(k, j)
        post = {0: F(0), 1: F(0)}
        for wb in family:
            l = F(1, len(family)) * mult
            for o, j in zip(trace_cells, js): l *= lik(fval(wb, o), j)
            post[fval(wb, query)] += l
        acc += max(post.values())
    return acc
fam_v2 = [(w, 0) for w in WF]
for k in (5, 10, 20, 40):
    print(f"  k={k:3d}  exact Bayes {float(bayes_heldout(fam_v2, [(0,1),(1,0)], (1,1), k)):.4f}   prior-optimal 0.6667")

hdr("C4b Repair: affine reliability-matched family f(o)=w.o+b, w!=00, b in {0,1} (6 mappings)")
fam_aff = [(w, b) for w in WF for b in (0, 1)]
fv = lambda wb, o: ((wb[0][0]*o[0] + wb[0][1]*o[1]) + wb[1]) % 2
print("  balanced over o for every mapping:", all(sum(fv(wb, o) for o in OS) == 2 for wb in fam_aff))
print("  f(11) label balance under uniform prior:", F(sum(fv(wb, (1, 1)) for wb in fam_aff), 6))
print("  traces at 00,01,10 identify f(11)=f(00)^f(01)^f(10):",
      all(fv(wb, (1, 1)) == fv(wb, (0, 0)) ^ fv(wb, (0, 1)) ^ fv(wb, (1, 0)) for wb in fam_aff))
for k in (5, 10, 20, 40):
    print(f"  k={k:3d}  exact Bayes {float(bayes_heldout(fam_aff, [(0,0),(0,1),(1,0)], (1,1), k)):.4f}   prior-optimal 0.5000   per-cell tracker 0.5")

hdr("C5 Outcome-5 counterexample: positive association AND reproducible splits")
pop = [((1, 1, 1), F(1, 2)), ((1, 0, 0), F(1, 4)), ((0, 0, 0), F(1, 4))]
P1 = [sum(m for v, m in pop if v[i]) for i in range(3)]
for i, j in ((0, 1), (0, 2), (1, 2)):
    pij = sum(m for v, m in pop if v[i] and v[j])
    print(f"  index {i}&{j}: P(both)={pij}  product={P1[i]*P1[j]}  positive={pij > P1[i]*P1[j]}")
print("  split systems (Shea pass, RR/Process fail) mass:", F(1, 4))

hdr("C6 False-fail inflation when any of m clauses can declare fail at level alpha")
for m in (3, 6, 10): print(f"  m={m:2d}: worst-case {1 - 0.95**m:.3f} (independent), bound {min(1, 0.05*m):.2f}")

hdr("C7 Stochastic channel: token-phi message replaced by an independent state's phi with prob eps")
def noisy_value(eps):
    cellm = {}
    for pr, s in states():
        k = phi(s['r'], s['o'], s['T'], s['w']); cellm.setdefault(k, F(0)); cellm[k] += pr
    g = {}
    for pr, s in states():
        true = phi(s['r'], s['o'], s['T'], s['w'])
        for msg, mm in cellm.items():
            w_ = pr * ((1 - eps) * (msg == true) + eps * mm)
            a = g.setdefault(msg, [0, 0]); a[0] += w_; a[1] += w_ * s['L']
    return sum(max(pc, m - pc, D * m) for m, pc in g.values())
for eps in (F(0), F(1, 10), F(1, 5), F(1, 3)):
    print(f"  eps={str(eps):5s} value {float(noisy_value(eps)):.4f}  (B0-public 0.7083)")

hdr("C8 U1 reference table recomputed under the v2.1 AFFINE family (6 mappings, uniform)")
def states_aff(p=P_, h=lambda a, b: a ^ b):
    for x, z1, z2, n, o, wb in product((0, 1), (0, 1), (0, 1), (0, 1), OS, fam_aff):
        T = h(z1, z2); q = QH if T == 0 else QL
        pr = (p if x else 1 - p) * F(1, 4) * ((1 - q) if n else q) * F(1, 4) * F(1, 6)
        f = fv(wb, o); r = (x ^ n) ^ f
        yield pr, dict(x=x, z1=z1, z2=z2, T=T, o=o, f=f, wb=wb, r=r, L=int(r == x))
def value_aff(info, **kw):
    g = {}
    for pr, s in states_aff(**kw):
        a = g.setdefault(info(s), [0, 0]); a[0] += pr; a[1] += pr * s['L']
    return sum(max(pc, m - pc, D * m) for m, pc in g.values())
def phi_f(r, f, T, p=P_):
    q = QH if T == 0 else QL; s = r ^ f; px = lambda x: p if x else 1 - p
    pn0 = px(s) * q / (px(s) * q + px(1 - s) * (1 - q)); return pn0 if f == 0 else 1 - pn0
for nm, f in (('B0-public (o,R)', lambda s: (s['o'], s['r'])), ('regime (o,R,T)', lambda s: (s['o'], s['r'], s['T'])),
              ('process (o,R,f)', lambda s: (s['o'], s['r'], s['wb'])), ('full (o,R,T,f)', lambda s: (s['o'], s['r'], s['T'], s['wb']))):
    v = value_aff(f); print(f"  {nm:18s} {v} = {float(v):.4f}")
print("  aggregate accuracy per mapping:", {str(wb): str(6*sum(pr*s['L'] for pr, s in states_aff() if s['wb'] == wb)) for wb in fam_aff})
m7 = sum(pr for pr, s in states_aff() if act(phi_f(s['r'], s['f'], s['T'])) != act(phi_f(1 - s['r'], s['f'], s['T'])))
m9 = sum(pr for pr, s in states_aff() if act(phi_f(s['r'], s['f'], s['T'])) != act(phi_f(s['r'], s['f'], s['T'], p=F(1, 2))))
print(f"  D7 transplant mass {m7};  prior-shift misrepresentation mass {m9}")
def post_aff(report):
    v = F(0)
    for pr, s in states_aff(h=lambda a, b: a):
        a = act(phi_f(s['r'], s['f'], report(s)))
        v += pr * (s['L'] if a == 'accept' else 1 - s['L'] if a == 'invert' else D)
    return v
print(f"  D8 rewiring: theta-using {float(post_aff(lambda s: s['T'])):.4f}  theta-ignoring parity {float(post_aff(lambda s: s['z1'] ^ s['z2'])):.4f}")
def relay_aff(msg):
    v = F(0)
    for pr, s in states_aff():
        for kappa in (0, 1):
            a = act(min(max(msg(s, kappa), F(0)), F(1)))
            v += pr * F(1, 2) * (s['L'] if a == 'accept' else 1 - s['L'] if a == 'invert' else D)
    return v
print(f"  relay: phi-code {float(relay_aff(lambda s,k: phi_f(s['r'],s['f'],s['T']))):.4f}  "
      f"Q-code {float(relay_aff(lambda s,k: phi_f(s['r'],s['f'],s['T']) + BETA*k*(s['r']==0))):.4f}")
cellm = {}
for pr, s in states_aff():
    k_ = phi_f(s['r'], s['f'], s['T']); cellm[k_] = cellm.get(k_, F(0)) + pr
for eps in (F(1, 10), F(1, 5), F(1, 3)):
    g = {}
    for pr, s in states_aff():
        tr = phi_f(s['r'], s['f'], s['T'])
        for msg, mm in cellm.items():
            w_ = pr * ((1 - eps) * (msg == tr) + eps * mm); a = g.setdefault(msg, [0, 0]); a[0] += w_; a[1] += w_ * s['L']
    print(f"  channel eps={eps}: {float(sum(max(pc, m - pc, D*m) for m, pc in g.values())):.4f}")
# RR conditional sub-problem depends only on f(o) in {0,1}; identical to B5 by the same symmetry
