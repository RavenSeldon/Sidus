# Sīdus E0-A — frozen plan F1 on build v0.7

This is the complete handoff: the original complete v0.7 ZIP (including all preserved history), frozen configuration, freeze receipt, seed provenance, independent review, review adjudication and read-only preflight. F1 is a plan identifier, not a new code version. No confirmation has been run for these seeds.

Read DECISIONS.md first. FROZEN_CONFIG.json supersedes the draft phase and reserved seed inventory for this execution; every other configuration value matches the reviewed draft. The older 10000–10499 reservation is retired because external review execution left its exposure status uncertain.

## Trust record

Retain the FREEZE_RECEIPT.json digest published in the accompanying conversation in a separate pre-execution record. FREEZE_SHA256.txt is a convenient copy, not independent authentication by itself. Do not derive the supposedly trusted digest from a future outcome bundle. Preserve this packet and the trusted digest before starting. This is a recorded pre-execution commitment, not third-party authentication of every local event.

## Read-only preflight

Extract the included Sidus_E0_Experiment_v0.7.zip into a separate working location; its root is Sidus_E0_Confirmation_v0.7. Keep this F1 folder separate from the extracted build so its extra files do not change the original release inventory. Python 3.10+ and the standard library suffice.

From this F1 folder, substituting the actual build path and independently retained digest:

```bash
python3 preflight.py --build /absolute/path/Sidus_E0_Confirmation_v0.7 --trusted-freeze-sha256 TRUSTED_DIGEST
```

Expected exit 0 means the binding and build checks passed; it does not run training or establish scientific validity. Exit 2 means stop and inspect the reported error.

## Next stage: execute once, then independently adjudicate

These are future operator instructions; neither command was run during F1 preparation. From the extracted build root:

```bash
python3 -m confirmation run-confirmation --config /absolute/path/F1/FROZEN_CONFIG.json --freeze /absolute/path/F1/FREEZE_RECEIPT.json --trusted-freeze-sha256 TRUSTED_DIGEST
```

The schedule has 6,500 attempts: 500 seeds × (5 learned reveal conditions + 8 controls). There is no early success stop. Exit 0 from generation means all attempts completed, not that the experiment passed. Exit 3 means incomplete attempts. Preserve every outcome either way. The supported runner creates an exclusive start sidecar and consumed-freeze record before training; do not bypass or delete them. If interrupted, retain the partial tree and diagnose it without silently rerunning or substituting seeds.

Record the outcome folder printed by the runner, then:

```bash
python3 -m confirmation adjudicate --folder /absolute/path/outcome --freeze /absolute/path/F1/FREEZE_RECEIPT.json --trusted-freeze-sha256 TRUSTED_DIGEST
```

Adjudication retrains and reevaluates the complete recorded protocol. Exit 0 means the implemented scoped acceptance criteria and trust checks passed; exit 3 means no license (inspect fail/inconclusive evidence); invocation/integrity errors may return 2. Preserve the outcome directory, its sibling .start.json, consumed-freeze ledger, F1 packet and trusted digest together. Reproduction is not a second independent sample.

Use the supported CLI for the initial run. Low-level generate is also a replay kernel and does not independently authorize a new experiment. This boundary is documented rather than changed after review.

F1 freezes a demanding finite-task experiment, not the truth of Sīdus. Report every result. E0-B remains unlicensed and requires its own definition-indexed experiments.
