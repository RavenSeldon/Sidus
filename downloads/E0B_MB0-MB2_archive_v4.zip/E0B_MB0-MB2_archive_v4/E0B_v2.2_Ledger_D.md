# E0-B v2.2 — Correction Ledger D (response to the independent audit)

**8 October 2026 · targeted ledger; v2.2 is retained unchanged as the record · scope MB0–MB2 · S1h remains NOT validated**

All values come from `e0b_shea_repair.py` (sections D1–D7), which imports `e0b_contracts.py`. Exact rational arithmetic is used throughout, except D7, which uses float64.

---

## 1. Verification of the audit

| Audit § | Claim | Reproduced | Disposition |
|---|---|---|---|
| 1 | Seven principal reference rows | ✔ | stands |
| 2 | 3,654 contiguous 4-bin Q partitions, 422 acceptance-optimal; relay over those ties ranges 0.769083–0.797222; φ advantage only 0.027778 against the strongest tie | ✔ D1 | **upheld** |
| 3 | Full-trace Bayes values 0.734616 / 0.762713 / 0.794698 (k = 10/20/40) | ✔ D7 | **upheld** |
| 3 | Per-cell MAP bits can violate the affine constraint | ✔ D5: probability **0.2171** at k = 10 | **upheld**, with magnitude added |
| 4 | k = 40 strongest tied Q: 0.764660 (ε=0), 0.751284 (0.1), 0.721624 (1/3) | ✔ D2 | numbers upheld |
| 4 | At ε = 1/3 an admissible Q code beats the optimized φ code (−0.010974) | ✔ as computed, **qualified** | see §2 |
| 5 | D11 matched-Q/different-φ arm is empty in the graded fixture (oracle, k = 10, k = 40) | ✔ D4: 0 / 0 / 0 classes | **upheld** |
| 6 | A 3-label non-contiguous Q-measurable code attains both optima (0.825000 / 0.914444) | ✔ D3 (found by graph colouring; no 2-label code exists) | **upheld** |
| 7 | RR and Process references | ✔ previously | stands |
| 7 | Continuous κ breaks unlimited-capacity equivalence: 0.799414 | ✔ D6 | **upheld**, and adopted as the basis of the repair (§3) |
| 7 | Source-of-truth claim too broad | ✔ | **upheld**; corrected in §5 |
| 7 | Independence 0.265 vs union bound 0.30 | ✔ | stands |

## 2. The one qualification: the sign reversal comes from asymmetric tie-breaking

The audit compared the **strongest** tied Q code against the **implementation's** φ code. Under the channel, the implementation's φ code turns out to be the **weakest** of the 134 relay-optimal φ partitions. When both sides are given their full tie sets (D2), the result is:

| k = 40, ε | φ ties | Q ties | gap range [φ_min − Q_max, φ_max − Q_min] | best vs best |
|---|---|---|---|---|
| 0 | 0.789530 | 0.744765–0.764660 | [+0.0249, +0.0448] | +0.0249 |
| 0.1 | 0.760577–0.773835 | 0.734152–0.751284 | [+0.0093, +0.0397] | +0.0226 |
| 1/3 | 0.710649–0.737213 | 0.710155–0.721624 | **[−0.0110, +0.0271]** | +0.0156 |

The audit's conclusion holds: **neither the effect size nor the sign is invariant under admissible choices** (the interval straddles zero at ε = 1/3). "An admissible Q code beats φ" is true only for worst-φ against best-Q. With symmetric treatment the gap stays positive. Both facts are recorded, and neither validates S1h.

## 3. Repair adopted for MB0 testing: continuous payoff context

The audit's findings in §2, §4, §5 and §6 share one root cause. With a finite κ grid, φ is a **function of Q** (D3: no Q value maps to two φ values). Any separation therefore had to come from restrictions on code organization: contiguity, tie-breaking, capacity.

**Candidate R2.3 contract.** κ ~ Uniform[0, 1], visible to both encoders and the acceptance consumer, hidden from the relay. The acceptance consumer earns \(L + \kappa\) for accepting (any R), \(1 - L\) for inverting, \(d\) for deferring. Then \(Q = \varphi + \kappa\) has overlapping supports across φ classes, so φ is **not** Q-measurable.

**Why this removes the comparator problems in the noiseless case.** Exact Q is the strongest Q-measurable code for the relay. Any coarsening, contiguous or not, at any capacity, is a garbling of Q and cannot do better (data processing). There is no tie set to choose from and no organizational restriction to justify.

| Access | ε | Relay (M, R): φ code | Relay (M, R): exact Q | Gap | D11 matched-Q / different-action mass |
|---|---|---|---|---|---|
| mapping oracle | 0 | 0.825000 | 0.773828 | **+0.0512** | 0.3149 |
| mapping oracle | 0.1 | 0.809300 | 0.756539 | +0.0528 | |
| mapping oracle | 1/3 | 0.772667 | 0.718331 | +0.0543 | |
| k = 40 traces | 0 | 0.789530 | 0.740914 | **+0.0486** | 0.4634 |
| k = 40 traces | 0.1 | 0.777093 | 0.728253 | +0.0488 | |
| k = 40 traces | 1/3 | 0.748074 | 0.705762 | +0.0423 | |

D11's empty arm is also repaired: matched-Q / different-φ cases now have **positive mass**, and because κ is continuous they persist when φ is estimated rather than known.

**What this does not settle (open, MB0):**
1. **Under the channel**, exact Q is not proven to be the strongest Q-measurable code. A coarser Q code might survive replacement better. The channel-optimal Q-measurable rival must be searched for, or bounded, before any noisy-channel margin is set. The ε > 0 rows above are against exact Q only.
2. **Empirical D11.** With continuous κ, exact matches have probability zero in sampled data. D11 therefore needs a caliper eligibility rule (|ΔQ| ≤ δ, relay-relevant φ difference), registered with its eligibility mass. Zero eligible mass → `inconclusive(empty_clause_set)`.
3. **Changed semantics.** The bonus now applies to accepting under either R. This changes the acceptance consumer from v2.2, and the comparator set must be re-derived under it.
4. **The interpretation step.** Even if the gap survives, a relay-value difference shows that the code tracks the correctness relation where it diverges from acceptance payoff. Whether that licenses the Shea reading is still the interpretation decision recorded in v2.1 §0. If not, the narrower functional finding is retained.

## 4. Estimator labels (audit §3)

- The current trace encoder is a **marginal-MAP-bit** estimator: four separate MAP decisions, which are not jointly constrained to the family (outside the family with probability 0.217 at k = 10). It stays as the **hard-MAP reference condition**.
- Added: a **full-posterior reference** (D7: 0.734616 / 0.762713 / 0.794698). Loss attributable to discarding evidence = full-posterior minus marginal-MAP (0.018 / 0.012 / 0.005 at k = 10/20/40).
- Not yet added: a **joint-MAP mapping** estimator. Required before any estimator is described as "MAP mapping".

## 5. Source-of-truth correction

v2.2's note "every value in this version comes from `e0b_contracts.py`" is withdrawn. The correct provenance:

| Values | Script |
|---|---|
| v2 draft references, U1 linear-family rows, D7/D8/D9 in v2 | `e0b_reference.py` Parts A–B |
| v2.1 audit checks (C1–C8), affine-family process Bayes | `e0b_reference.py` Part C |
| binary-κ contract rows, trace sweep, graded-κ quantizer rows, RR trace rows | `e0b_contracts.py` |
| Ledger D (ties, witness, D11 eligibility, marginal-MAP, continuous κ, full-trace) | `e0b_shea_repair.py` |

## 6. Witness register additions (MB2)

- **W8 — non-contiguous Q-measurable code** (D3). It attains both optima in the graded-κ fixture. It must **fail** S1h under the R2.3 contract, and if it does not, R2.3 is not discriminating.
- **W9 — strongest tied Q quantizer** (D1/D2), kept as the comparator for any contiguous-code arm.

## 7. Revised MB0 order

1. Adopt R2.3 provisionally. Re-derive the comparator set and witness predictions under it.
2. Search for or bound the channel-optimal Q-measurable rival. Fix whether codes are optimized before or after the registered channel (both sides symmetrically).
3. Register the D11 caliper rule and report its eligibility mass.
4. Add the joint-MAP estimator; keep hard-MAP and full-posterior as reference conditions.
5. **Fix k from the actual trace budget** (needs the block-length decision below), then set margins.

## 8. Decision needed from Ben

The audit is right that k cannot be chosen by where the gap looks large. Three facts are needed:
- the **block length** \(B\), i.e. trials during which the mapping is fixed;
- whether the four inputs are **allocated equally by design** (\(k = B/4\)) or **sampled randomly** (variable per-cell counts, so the fixed-k tables are not exact operational benchmarks);
- whether the **trials used to infer the mapping are separate** from the trials evaluated.
