#!/usr/bin/env python3
"""EXPLORATORY (not adopted; for the external audit): would adding the constant mappings (w = 00, b in {0,1}) make the
Process contrast structural? With all 8 affine maps, every observed pattern is possible, f(11) = parity of the 3 observed
bits, and parity of 3 bits is NOT a threshold function. Cost: the constant maps break reliability matching. MC, float64."""
import numpy as np
from itertools import product
OS = [(0, 0), (0, 1), (1, 0), (1, 1)]
P_X, QH, QL = 0.7, 0.95, 0.5; pS = P_X * (QH + QL) / 2 + (1 - P_X) * (1 - (QH + QL) / 2)
def fam(include_const):
    ws = [(0, 1), (1, 0), (1, 1)] + ([(0, 0)] if include_const else [])
    return np.array([[((w[0] * o[0] + w[1] * o[1]) + b) % 2 for o in OS] for w in ws for b in (0, 1)])
thr = set()
for wv in product(range(-3, 4), repeat=3):
    for t in np.arange(-6.5, 7, 1.0):
        thr.add(tuple(int(np.dot(wv, x) > t) for x in product((0, 1), repeat=3)))
pats = list(product((0, 1), repeat=3))
for include in (False, True):
    TAB = fam(include)
    for kp in (5, 20):
        rng = np.random.default_rng(7); n = 400000
        wb = rng.integers(0, len(TAB), n); f = TAB[wb]; cnt = rng.binomial(kp, np.where(f[:, :3] == 0, pS, 1 - pS))
        ll = np.stack([np.where(TAB[v, :3] == 0, cnt * np.log(pS) + (kp - cnt) * np.log(1 - pS), cnt * np.log(1 - pS) + (kp - cnt) * np.log(pS)).sum(1) for v in range(len(TAB))], 1)
        post = np.exp(ll - ll.max(1, keepdims=True)); post /= post.sum(1, keepdims=True); p11 = post @ TAB[:, 3]
        y = f[:, 3]; bayes = np.where(np.isclose(p11, .5), .5, (p11 > .5) == (y == 1)).mean()
        bits = np.where(2 * cnt > kp, 0, np.where(2 * cnt < kp, 1, rng.integers(0, 2, cnt.shape)))
        idx = bits[:, 0] * 4 + bits[:, 1] * 2 + bits[:, 2]
        best_lin = max(((np.array(h)[idx] == y).mean()) for h in thr)
        unres = sum(max((y[idx == i] == 1).sum(), (y[idx == i] == 0).sum()) for i in range(8)) / n
        accs = [(TAB[v] == np.array([1 if i != 3 else 0 for i in range(4)])).mean() for v in range(len(TAB))]
        print(f"family {'8 maps (with constants)' if include else '6 maps (v2.1)'}  k={kp}: structured Bayes {bayes:.4f} | per-cell bits: best LINEAR readout {best_lin:.4f}, best UNRESTRICTED readout {unres:.4f}")
    rel = [float(np.mean(TAB[v])) for v in range(len(TAB))]
    print(f"   inversion rate per mapping (reliability matching requires all equal): {rel}")
