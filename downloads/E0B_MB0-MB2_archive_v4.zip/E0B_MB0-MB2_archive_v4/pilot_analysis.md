# Pilot P0 analysis (pre-specified rules)

## Per-system summaries (median [min, max] over 10 pilot seeds)

| system | E1 relay | E2 calib excess | E3 kappa-sens | E4 D11 agreement | E5 S1e gap 0.75 | E5 S1e gap 0.80 |
|---|---|---|---|---|---|---|
| C-end | 0.7700 [0.7635, 0.7758] | 0.0168 [0.0154, 0.0200] | 0.5408 [0.5140, 0.6165] | 0.0129 [0.0000, 0.1486] | 0.0218 [0.0196, 0.0244] | 0.0240 [0.0223, 0.0258] |
| C-sup | 0.7941 [0.7927, 0.7964] | 0.0004 [0.0004, 0.0005] | 0.0137 [0.0120, 0.0196] | 0.9433 [0.9205, 0.9679] | 0.0005 [0.0003, 0.0008] | 0.0006 [0.0003, 0.0008] |
| B0-am | 0.7864 [0.7806, 0.7941] | 0.0085 [0.0020, 0.0118] | 1.9268 [1.8530, 2.0109] | 0.7169 [0.3583, 0.9167] | 0.0120 [0.0011, 0.0176] | 0.0116 [0.0009, 0.0167] |
| R-vec | 0.7675 [0.7643, 0.7696] | 0.0203 [0.0194, 0.0212] | 1.2108 [1.1954, 1.2290] | 0.0092 [0.0001, 0.0403] | 0.0285 [0.0259, 0.0299] | 0.0326 [0.0313, 0.0335] |
| R-acc | 0.7467 [0.7429, 0.7491] | 0.0316 [0.0306, 0.0330] | 0.7738 [0.7617, 0.7932] | 0.0076 [0.0001, 0.0287] | 0.0393 [0.0370, 0.0418] | 0.0415 [0.0393, 0.0425] |

ideal phi_post relay (same test sets): median 0.7943

## Direction-adjusted effects vs the best rival (paired by seed) and the pre-specified margin rule

| candidate | measure | effect median | 10th percentile | margin (half of P10) | status |
|---|---|---|---|---|---|
| C-end | E1_relay | +0.00372 | -0.00041 | +nan | NOT reliably achieved at pilot scale |
| C-end | E2_calib_excess | +0.00350 | +0.00197 | +0.00098 | positive margin defensible |
| C-end | E3_kappa_sens | +0.23300 | +0.19435 | +0.09717 | positive margin defensible |
| C-end | E4_D11_agreement | +0.00324 | -0.02878 | +nan | NOT reliably achieved at pilot scale |
| C-end | E5_S1e_gap_0.75 | +0.00630 | +0.00512 | +0.00256 | positive margin defensible |
| C-end | E5_S1e_gap_0.8 | +0.00845 | +0.00759 | +0.00380 | positive margin defensible |
| C-sup | E1_relay | +0.02683 | +0.02597 | +0.01299 | positive margin defensible |
| C-sup | E2_calib_excess | +0.01985 | +0.01920 | +0.00960 | positive margin defensible |
| C-sup | E3_kappa_sens | +0.75820 | +0.75030 | +0.37515 | positive margin defensible |
| C-sup | E4_D11_agreement | +0.93181 | +0.91772 | +0.45886 | positive margin defensible |
| C-sup | E5_S1e_gap_0.75 | +0.02796 | +0.02631 | +0.01316 | positive margin defensible |
| C-sup | E5_S1e_gap_0.8 | +0.03198 | +0.03147 | +0.01573 | positive margin defensible |
| B0-am | E1_relay | +0.02020 | +0.01335 | +0.00667 | positive margin defensible |
| B0-am | E2_calib_excess | +0.01177 | +0.00970 | +0.00485 | positive margin defensible |
| B0-am | E3_kappa_sens | -1.14112 | -1.20911 | +nan | NOT reliably achieved at pilot scale |
| B0-am | E4_D11_agreement | +0.70821 | +0.44052 | +0.22026 | positive margin defensible |
| B0-am | E5_S1e_gap_0.75 | +0.01626 | +0.01301 | +0.00650 | positive margin defensible |
| B0-am | E5_S1e_gap_0.8 | +0.02119 | +0.01697 | +0.00848 | positive margin defensible |

## Optimization reliability (relay >= 95% of ideal relay on the same test set)

- C-end: 10/10
- C-sup: 10/10
- B0-am: 10/10
- R-vec: 10/10
- R-acc: 0/10

## Block budget (pre-specified rule: primary contrast E1, T-end candidate)

- E1 10th-percentile effect is not positive: no block budget can be derived for the T-end candidate under the rule.

## Process arm (k_p = 20; held-out identities)

- identity-blind Bayes bound (MC): 0.7041
- P-struct: median 0.4298 [0.4132, 0.4357]
- P-cell-lin: median 0.6634 [0.6627, 0.6636]
- P-cell-mlp: median 0.3551 [0.3499, 0.3606]
