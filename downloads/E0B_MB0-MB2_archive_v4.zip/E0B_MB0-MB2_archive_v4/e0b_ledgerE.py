#!/usr/bin/env python3
"""E0-B Ledger E — corrections required by the independent audit of the Final-State Report.

E1  RR1e matched transformations (previously not executed): does a matched transformation reproduce the full
    RR1b accessibility gain? Comparators: same-target feature learner (Bayes feature for T from raw Z1,Z2),
    fixed parity W2, shuffled parity with matched support (independent trial's parity).
E2  Process P1c as an actual relabelling intervention (permute the family's parameter labels, including the
    order used for tie-breaking) and P1d as a controlled substitution (block held fixed, message replaced by
    another block's message; does the prediction follow the substituted content?).
E3  Process P1b information contract: (a) decoder NOT told the held-out population (full structured prior)
    vs (b) decoder told the held-out population is {((1,1),0), ((0,1),0)}.
E4  Trace-compliant Shea witness: phi computed from k-trace marginal-MAP estimates (no oracle mapping access);
    all Shea clauses re-run with contract-relative targets, against trace-built rivals. k = 10 and k = 40.
E5  Strengthened access audit: classify every witness by mapping access (oracle feasibility vs trace-compliant).
Exact rational arithmetic (estimator distributions float-derived for k > 10). Imports e0b_contracts, e0b_mb0, e0b_mb12.
"""
from fractions import Fraction as F
from collections import defaultdict
from itertools import product, combinations, permutations
import e0b_contracts as C
import e0b_mb0 as M0
import e0b_mb12 as M

D = C.D; act = M.act; CELLS = M.CELLS

# ================================================================== E1 RR1e
def rr1e():
    S = M.world(); out = {}
    # same-target feature learner: Bayes-optimal predictor of T from raw (Z1, Z2) under the training world (= parity)
    g = defaultdict(lambda: [F(0), F(0)])
    for pr, s in S: a = g[(s['z1'], s['z2'])]; a[0] += pr; a[1] += pr * s['T']
    learner = {kz: int(v[1] / v[0] > F(1, 2)) for kz, v in g.items()}
    # shuffled parity with matched support: deterministic derangement of the parity code across (z1, z2) cells that
    # preserves the code's marginal distribution but breaks its relation to the cell (z -> parity of (1-z1, z2))
    cands = {
        'W1 regime code (theta-coupled)': M.W['W1 regime code (theta-coupled)'],
        'same-target feature learner':     dict(decl=['z1', 'z2'], code=lambda s, c: learner[(s['z1'], s['z2'])], kind='free'),
        'W2 fixed parity':                 M.W['W2 input parity (fixed)'],
    }
    # shuffled parity with matched support: an independent fair bit u (the parity of an independent trial), i.e. the
    # same marginal distribution as the parity code but no relation to this trial's regime
    Su = [(pr / 2, dict(s, u=u)) for pr, s in S for u in (0, 1)]
    shuffled = dict(decl=['u'], code=lambda s, c: s['u'], kind='free')
    cands['shuffled parity (matched support)'] = shuffled
    for name, w in cands.items():
        SS = Su if name.startswith('shuffled') else S
        tabs = M.sub_tables(SS, w, M.CTX0); raw = withm = F(0)
        for key, tab in tabs.items():
            raw += M.best_linear(tab, False)[0]; withm += M.best_linear(tab, True)[0]
        out[name] = (raw, withm)
    return out, learner

# ================================================================== E2/E3 Process interventions
def p1c_intervention(k=5):
    """Relabel the parameter names of the family by every one of 720 permutations applied to the TRAIN_IDS ordering /
    FAM ordering used inside the codes, recompute each block's code, and compare predictions."""
    base_ids = list(M.TRAIN_IDS)
    # direct recomputation over count vectors
    p = C.pS1; res = {}
    from math import comb
    def idmap(js, order):
        post = M.posterior(js, k, order)
        return max(order, key=lambda t: (post[t], -order.index(t)))
    js_all = list(product(range(k + 1), repeat=3))
    w6b_changes = 0; w3_changes = 0
    for perm in permutations(range(4)):
        order = [base_ids[i] for i in perm]
        for js in js_all:
            if M.fval(idmap(js, order), (1, 1)) != M.fval(idmap(js, base_ids), (1, 1)): w6b_changes += 1; break
        fam_perm = [M.FAM[i] for i in (perm + (4, 5))]
        for js in js_all:
            post_a = M.posterior(js, k, M.FAM); post_b = M.posterior(js, k, fam_perm)
            if M.pred11(post_a) != M.pred11(post_b): w3_changes += 1; break
    res['W6b permutations (of 24) changing any f(11) prediction'] = w6b_changes
    res['W3 permutations (of 24) changing any f(11) prediction'] = w3_changes
    # mass-weighted effect for W6b under the worst permutation
    worst = 0; worst_mass = F(0)
    for perm in permutations(range(4)):
        order = [base_ids[i] for i in perm]; mass = F(0)
        for pr, wb, js in M.process_blocks(k):
            if M.fval(idmap(js, order), (1, 1)) != M.fval(idmap(js, base_ids), (1, 1)): mass += pr
        if mass > worst_mass: worst_mass = mass
    res['W6b worst-case prediction-change mass under relabelling'] = worst_mass
    return res

def p1d_controlled(name, k=5):
    """controlled substitution: the block (truth) is held fixed; the message is replaced by the message of another
    block; the frozen decoder's prediction is scored against the SOURCE block's label and against the HOST block's.
    Causal use = predictions follow the source (substituted) content."""
    lvl, code = M.PROC[name]; St = M.proc_states(k)
    acc, rule = M.linear_acc(St, code)
    # distinct messages with their source-label distribution
    src = defaultdict(lambda: [F(0), F(0)])
    for pr, blk, tr in St: a = src[code(blk, tr)]; a[0] += pr; a[1] += pr * blk['y']
    msgs = list(src); tot = sum(v[0] for v in src.values())
    # pair every host state with every source message (independent draw): host label y_h, source label distribution
    host = defaultdict(F)
    for pr, blk, tr in St: host[blk['y']] += pr
    follow_src = sum((src[m][1] if rule(M.enc(m)) else src[m][0] - src[m][1]) for m in msgs) / tot
    follow_host = sum(host[y] * sum(src[m][0] * (rule(M.enc(m)) == y) for m in msgs) / tot for y in (0, 1))
    return follow_src, follow_host, acc

def p1b_contract(k=5):
    St = M.proc_states(k); Sho = [x for x in St if x[1]['wb'] in M.HELDOUT_IDS]
    tot = sum(x[0] for x in Sho)
    full = M.unrestricted_acc(Sho, M.PROC['W3 process model (truth table)'][1])[0] / tot
    # identity-informed decoder: posterior restricted to the held-out population
    acc = F(0); totb = F(0)
    for pr, wb, js in M.process_blocks(k):
        if wb not in M.HELDOUT_IDS: continue
        post = M.posterior(js, k, M.HELDOUT_IDS); p11 = M.pred11(post)
        y = M.fval(wb, (1, 1)); acc += pr * (F(1, 2) if p11 == F(1, 2) else (1 if (p11 > F(1, 2)) == (y == 1) else 0)); totb += pr
    return full, acc / totb

# ================================================================== E4 trace-compliant Shea
def trace_world(k):
    mb = C.map_bit_dist(k) if k <= 10 else C.map_bit_dist_float(k); out = []
    for pr, s in M.world():
        p1 = mb[(s['wb'], s['o'])]
        for fh, pf in ((1, p1), (0, 1 - p1)):
            if pf: out.append((pr * pf, dict(s, fhat=fh)))
    return out

def shea_trace(k):
    S = trace_world(k)
    phit = C.encode(S, 'L', ['o', 'r', 'T', 'fhat'])              # ideal trace-compliant encoder (declared inputs only)
    PH = lambda s: phit(s)
    atoms = M0.atoms_from([(pr, s) for pr, s in S])
    bound = M0.relay_rival(atoms, 'vector')
    it = [(r, f, m, c) for (r, f), (m, c) in atoms.items()]
    def rival_dec(kind):
        def dec(mv, r):
            if kind == 'accept': L = [x for x in it if x[0] == r and x[1] <= mv <= x[1] + 1]
            elif kind == 'invert': L = [x for x in it if x[0] == r and 1 - x[1] <= mv <= 2 - x[1]]
            else: L = [x for x in it if x[0] == r and x[1] <= mv[0] <= x[1] + 1 and 1 - x[1] <= mv[1] <= 2 - x[1]]
            m = sum(x[2] for x in L); return (sum(x[3] for x in L) / m) if m else None
        return dec
    WT = {
        'W5t token-phi (trace-compliant)': ('free', lambda s, c: PH(s)),
        'W1 regime code':                  ('free', lambda s, c: s['T']),
        'B1t-accept-value':                ('accept', lambda s, c: PH(s) + c['ka']),
        'B1t-invert-value':                ('invert', lambda s, c: 1 - PH(s) + c['ki']),
        'B1t-action-vector':               ('vector', lambda s, c: (PH(s) + c['ka'], 1 - PH(s) + c['ki'])),
    }
    C0 = dict(ka=F(0), ki=F(0)); results = {}
    idx = {(s['x'], s['z1'], s['z2'], s['n'], s['o'], s['wb'], s['fhat']): s for _, s in S}
    oracle_phi = lambda s: M.phi_cf(s['r'], s['o'], s['T'], s['f'], C.P_X)
    for name, (kind, code) in WT.items():
        res = {}; ok = {}
        if kind == 'free':
            g = defaultdict(lambda: [F(0), F(0)])
            for pr, s in S: a = g[(code(s, C0), s['r'])]; a[0] += pr; a[1] += pr * s['L']
            dec = lambda m, r, g=g: (g[(m, r)][1] / g[(m, r)][0]) if g[(m, r)][0] else None
            exc = sum(pr * (dec(code(s, C0), s['r']) - PH(s)) ** 2 for pr, s in S)
            val = sum(max(c, m - c, D * m) for m, c in g.values())
            vals_d = [sum(max(c, m - c, dp * m) for m, c in g.values()) for dp in (F(45, 100), F(65, 100))]
        else:
            dec = rival_dec(kind)
            # piecewise integrals with trace atoms
            if kind == 'vector':
                bx = sorted({f for _, f, _, _ in it} | {f + 1 for _, f, _, _ in it}); by = sorted({1 - f for _, f, _, _ in it} | {2 - f for _, f, _, _ in it})
                cells = [((a + b) / 2, (c_ + d_) / 2, (b - a) * (d_ - c_)) for a, b in zip(bx, bx[1:]) for c_, d_ in zip(by, by[1:])]
                livef = lambda cl, r: [x for x in it if x[0] == r and x[1] <= cl[0] <= x[1] + 1 and 1 - x[1] <= cl[1] <= 2 - x[1]]
            else:
                sh = (lambda f: f) if kind == 'accept' else (lambda f: 1 - f)
                bp = sorted({sh(f) for _, f, _, _ in it} | {sh(f) + 1 for _, f, _, _ in it})
                cells = [((a + b) / 2, None, b - a) for a, b in zip(bp, bp[1:])]
                livef = lambda cl, r: [x for x in it if x[0] == r and sh(x[1]) <= cl[0] <= sh(x[1]) + 1]
            val = F(0); exc = F(0); vals_d = [F(0), F(0)]
            for cl in cells:
                for r in (0, 1):
                    L = livef(cl, r)
                    if not L: continue
                    m = sum(x[2] for x in L); c = sum(x[3] for x in L); pb = c / m
                    val += cl[2] * max(c, m - c, D * m); exc += cl[2] * sum(x[2] * (pb - x[1]) ** 2 for x in L)
                    for i, dp in enumerate((F(45, 100), F(65, 100))): vals_d[i] += cl[2] * max(c, m - c, dp * m)
        res['S1a calibration excess vs contract target'] = exc; ok['S1a calibration excess vs contract target'] = exc == 0
        # S1b tracking (MU-1) and nuisance
        elig = trk = F(0)
        kg = [(F(0), F(0)), (F(1, 2), F(1, 2))] if kind != 'free' else [(F(0), F(0))]
        for pr, s in S:
            s2 = idx[(s['x'], 1 - s['z1'], s['z2'], s['n'], s['o'], s['wb'], s['fhat'])]
            dphi = PH(s2) - PH(s)
            if dphi == 0: continue
            for ka, ki in kg:
                cc = dict(ka=ka, ki=ki); a, b = dec(code(s, cc), s['r']), dec(code(s2, cc), s2['r'])
                elig += pr; trk += pr * (a is not None and b is not None and (b - a) * dphi > 0)
        res['S1b tracking rate'] = trk / elig; ok['S1b tracking rate'] = trk == elig
        nu = sum(pr for pr, s in S if code(s, C0) != code(s, dict(ka=F(1, 2), ki=F(1, 2))))
        res['S1b nuisance change mass'] = nu; ok['S1b nuisance change mass'] = nu == 0
        # S1c directional substitution (consumer acts on decoded content of the substituted message)
        tot = hit = F(0)
        for (p1, s1), (p2, s2) in product(S, S):
            if s1['r'] != s2['r'] or act(PH(s1)) == act(PH(s2)): continue
            ph = dec(code(s2, C0), s1['r']); tot += p1 * p2; hit += p1 * p2 * (ph is not None and act(ph) == act(PH(s2)))
        res['S1c directional substitution rate'] = hit / tot; ok['S1c directional substitution rate'] = hit == tot
        # S1d transplant (M-only relay), partner = same (o, T, fhat), opposite R
        gM = defaultdict(lambda: [F(0), F(0)])
        for pr, s in S: a = gM[code(s, C0)]; a[0] += pr; a[1] += pr * s['L']
        decM = lambda m: gM[m][1] / gM[m][0] if gM[m][0] else None
        part = {}
        for _, t in S: part.setdefault((t['o'], t['T'], t['fhat'], t['r']), t)
        tx = sum(pr for pr, s in S if (s['o'], s['T'], s['fhat'], 1 - s['r']) in part
                 and act(decM(code(s, C0))) != act(decM(code(part[(s['o'], s['T'], s['fhat'], 1 - s['r'])], C0))))
        res['S1d transplant action-change mass'] = tx; ok['S1d transplant action-change mass'] = tx > 0
        # S1e held-out d' vs the contract optimum
        opts = [sum(pr * max(PH(s), 1 - PH(s), dp) for pr, s in S) for dp in (F(45, 100), F(65, 100))]
        res['S1e held-out d (value, contract optimum)'] = [(float(v), float(o)) for v, o in zip(vals_d, opts)]
        ok['S1e held-out d (value, contract optimum)'] = all(v == o for v, o in zip(vals_d, opts))
        # S1f endogenous misrepresentation: the system's own inference errors (fhat != f) vs oracle correctness probability
        mis = sum(pr for pr, s in S if dec(code(s, C0), s['r']) is not None and act(dec(code(s, C0), s['r'])) != act(oracle_phi(s)))
        res['S1f endogenous misrepresentation mass (vs oracle phi)'] = mis; ok['S1f endogenous misrepresentation mass (vs oracle phi)'] = mis > 0
        res[f'S1h relay value (trace bound {float(bound):.6f})'] = val; ok[f'S1h relay value (trace bound {float(bound):.6f})'] = val > bound
        pairs = sep = 0
        for (_, s1), (_, s2) in combinations(S, 2):
            if s1['r'] != s2['r']: continue
            f1, f2 = PH(s1), PH(s2)
            if act(f1) == act(f2): continue
            a1, i1 = max(F(0), f2 - f1), max(F(0), f1 - f2)
            pairs += 1; sep += code(s1, dict(ka=a1, ki=i1)) != code(s2, dict(ka=a1 + f1 - f2, ki=i1 + f2 - f1))
        res['S1h D11 separation'] = f"{sep}/{pairs}"; ok['S1h D11 separation'] = sep == pairs
        results[name] = (res, ok)
    return results, bound

# ================================================================== E5 access audit
ACCESS = {  # declared mapping access per witness in the Shea/RR context
 'W1 regime code (theta-coupled)': 'none (theta access only)', 'W2 input parity (fixed)': 'none',
 'W3 process model (truth table)': 'ORACLE (wb)', 'W5 token-phi monitor': 'ORACLE (f)', 'W6a per-cell tracker': 'ORACLE (wb)',
 'W6b identity classifier': 'ORACLE (wb)', 'W7 bundle W1+W3+W5': 'ORACLE (f, wb)', 'B1-scalar reliability q_T': 'none',
 'B1-accept-value': 'ORACLE (f)', 'B1-invert-value': 'ORACLE (f)', 'B1-action-vector': 'ORACLE (f)'}
def access_audit():
    out = {}
    for name, w in M.W.items():
        oracle = any(v in w['decl'] for v in ('f', 'wb'))
        out[name] = ('oracle feasibility only' if oracle else 'trace-compliant', ACCESS[name])
    return out

if __name__ == '__main__':
    print("# E0-B Ledger E execution log\n")
    print("## E1 RR1e matched transformations (mapping-oracle subproblem; linear-argmax consumer)\n")
    r1, learner = rr1e()
    print(f"same-target feature learner (Bayes predictor of T from raw Z1,Z2): {learner}  (= parity)\n")
    print("| code | linear without M | linear with M | gain |")
    print("|---|---|---|---|")
    for nm, (a, b) in r1.items(): print(f"| {nm} | {float(a):.6f} | {float(b):.6f} | {float(b - a):+.6f} |")
    print("\n## E2 Process P1c relabelling intervention and P1d controlled substitution (k = 5)\n")
    for kk, v in p1c_intervention().items(): print(f"- {kk}: {v if isinstance(v, int) else float(v)}")
    print("\n| witness | prediction follows SOURCE label | follows HOST label | own accuracy |")
    print("|---|---|---|---|")
    for nm in M.PROC:
        fs, fh, ac = p1d_controlled(nm); print(f"| {nm} | {float(fs):.6f} | {float(fh):.6f} | {float(ac):.6f} |")
    print("\n## E3 P1b information contract (k = 5, held-out identities)\n")
    full, informed = p1b_contract()
    print(f"- (a) decoder not told the held-out population (full structured prior): {float(full):.6f}")
    print(f"- (b) decoder told the held-out population {M.HELDOUT_IDS}: {float(informed):.6f}")
    print("\n## E5 Access audit\n")
    for nm, (cls, acc) in access_audit().items(): print(f"- {nm}: {cls} [{acc}]")
    for k in (10, 40):
        print(f"\n## E4 Trace-compliant Shea witnesses, k = {k} (marginal-MAP traces; contract-relative targets)\n")
        res, bound = shea_trace(k)
        for nm, (rs, oks) in res.items():
            verdict = 'PASS' if all(oks.values()) else 'fail'
            print(f"### {nm}: {verdict}")
            for kk, v in rs.items(): print(f"- {kk}: {v if isinstance(v, (str, list)) else float(v)} -> {'ok' if oks[kk] else 'NOT MET'}")
            print()
