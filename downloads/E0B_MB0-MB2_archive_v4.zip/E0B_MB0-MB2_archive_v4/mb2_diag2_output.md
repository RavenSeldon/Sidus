## X3 RR1d robustness over admissible consumers

- W1 regime code (theta-coupled): every admissible optimal consumer uses M under substitution = True
- W2 input parity (fixed): every admissible optimal consumer uses M under substitution = True
- W5 token-phi monitor: every admissible optimal consumer uses M under substitution = True
- B1-scalar reliability q_T: every admissible optimal consumer uses M under substitution = True

## X4 P1b: train-optimal decoders and held-out accuracy range (k = 5)

| witness | train-optimal decoder labelings | held-out accuracy min | max |
|---|---|---|---|
| W1 regime code (theta-coupled) | 4 | 0.500000 | 0.500000 |
| W2 input parity (fixed) | 4 | 0.500000 | 0.500000 |
| W3 process model (truth table) | 1 | 0.596178 | 0.596178 |
| W5 token-phi monitor | 2 | 0.517643 | 0.517643 |
| W6a per-cell tracker | 2 | 0.518517 | 0.518517 |
| W6b identity classifier | 1 | 0.463034 | 0.463034 |
| W7 bundle W1+W3+W5 | 1 | 0.596178 | 0.596178 |
| B1-scalar reliability q_T | 4 | 0.500000 | 0.500000 |

## X5 MB1-B3 optimisation gaps (strengthened training)

- linear: rung optimum 0.806250; trained min 0.745313 / median 0.757812 / max 0.768969; seeds reaching optimum 0/20
- one-hidden: rung optimum 0.825000; trained min 0.746875 / median 0.759594 / max 0.771813; seeds reaching optimum 0/20
