#!/usr/bin/env python3
"""E0-B MB1 supplement: a least-squares action-value consumer (alternative training rule) vs the exact rung optima."""
import sys; sys.path.insert(0, '.')
import numpy as np, e0b_mb12 as M
S = M.world(); tabs = M.sub_tables(S, None, M.CTX0); tw = M.sub_tables(S, M.W['W1 regime code (theta-coupled)'], M.CTX0)
for label, T_, feat in (('raw (R,Z1,Z2)', tabs, lambda cl, v: list(cl)), ('with parity M', tw, lambda cl, v: list(cl) + [float(v[2])])):
    tot = 0.0
    for key, tab in T_.items():
        X = np.array([feat(cl, tab[cl]) + [1.0] for cl in M.CELLS]); wts = np.array([float(tab[cl][0]) for cl in M.CELLS])
        P = np.array([[float(tab[cl][1]), float(tab[cl][0]-tab[cl][1]), float(M.D*tab[cl][0])] for cl in M.CELLS]) / wts[:, None]
        Wsq = np.sqrt(wts)[:, None]
        B = np.linalg.lstsq(X * Wsq, P * Wsq, rcond=None)[0]          # weighted least-squares action values
        a = (X @ B).argmax(1); tot += float(sum(wts[i] * P[i, a[i]] for i in range(8)))
    print(f"linear least-squares action-value consumer, {label}: greedy value {tot:.6f}")
