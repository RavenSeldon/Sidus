# E0-B v2.2 — Correction Ledger D-II (response to the review of Ledger D)

**8 October 2026 · additive to Ledger D, which is retained unchanged · scope MB0–MB2 · S1h remains NOT validated**

New values come from `e0b_r24.py`, which runs in about 2 seconds, uses exact rational arithmetic and imports `e0b_contracts.py`.

---

## 1. Dispositions

| Review item | Checked | Disposition |
|---|---|---|
| Exact Q dominates every Q-derived code under the marginal-replacement channel (coupling + data processing) | Proof read and accepted. Conditions: replacement draws from the code's own marginal, independently of the state; any encoder randomness is independent | **Ledger D §3 item 1 closed for the registered channel.** It reopens if the channel changes (alphabet-dependent or per-bit noise). The same coupling argument covers vector-valued codes (used in §3 below) |
| B1-invert-value \(M = 1-\varphi\) is equivalent to φ | ✔ E1: 0.825000 = 0.825000 (oracle); 0.789530 = 0.789530 (k=40) | **upheld**; registered as a rival |
| R2.3 acceptance optimum \(488329/435200 \approx 1.122080\); public-only 1.040000 | ✔ E2 (k = 40 marginal-MAP: 1.095826) | **upheld**; added to the reference set |
| D11 masses are population-level ambiguity, not empirical eligibility | ✔ | relabelled: *population ambiguity mass (different relay-optimal actions)*. Empirical eligibility awaits the caliper rule |
| W8 must be extended to continuous Q before being run | ✔ | W8 is Q-measurable, so the dominance bound already covers it analytically. An extension needs specifying only if W8 is run as a *learned* witness |
| \(k = B_{\text{trace}}/4\), not \(B/4\) | ✔ | Ledger D §8's phrasing is corrected |

## 2. The rival R2.3 leaves standing, and a candidate fix (R2.4)

R2.3 perturbs only the accept payoff, so \(Q_{\text{invert}} = 1-\varphi\) stays an invertible relabel of φ. The review's suggestion was to vary the payoffs of *every* action independently while keeping the correctness target fixed.

**R2.4 candidate contract.** Accept pays \(L+\kappa_a\), invert pays \((1-L)+\kappa_i\), defer pays \(d+\kappa_d\), with \(\kappa_a, \kappa_i, \kappa_d \sim U[0,1]\) independent. The κ's are visible to the encoders and the acceptance consumer and hidden from the relay, which observes M and R.

| Code (relay observes M, R) | Mapping oracle | k = 40 traces |
|---|---|---|
| φ | **0.825000** | **0.789530** |
| scalar \(Q_{\text{accept}} = \varphi+\kappa_a\) | 0.773828 | 0.740914 |
| scalar \(Q_{\text{invert}} = 1-\varphi+\kappa_i\) | 0.773828 | 0.740914 |
| **full action-value vector** \((Q_{\text{accept}}, Q_{\text{invert}})\) | 0.804052 | 0.763131 |
| φ advantage over the full vector | **+0.0209** | **+0.0264** |

\(Q_{\text{defer}} = d+\kappa_d\) is independent of φ and of the other components, so adding it changes nothing.

By data processing, and by the coupling argument for the registered channel, the vector row is an upper bound for **every code that is a function of the first-order action-value vector**. That includes advantages, softmax policies and argmax actions, contiguous or not, at any capacity. R2.4 therefore defeats the whole registered action-value rival family, not one member of it.

## 3. A limit that no payoff design can remove

The relay is itself a correctness-paid consumer, so its own accept-value **is** φ. More generally, for any consumer whose payoff depends on the world only through \(L\), every action value is an affine function of φ, and so an invertible relabel of it. Within this design family φ is therefore identifiable only **up to invertible transformation**. "Represents correctness probability" and "represents the value of a correctness-contingent action" make identical predictions for every consumer of that kind. This is an identity, not a gap a better fixture could close.

**What R2.4 can at most establish (proposed wording):** *M carries a statistic sufficient for correctness-contingent consumers, and that statistic is invariant to independently varied, non-correctness payoff contexts that the code had access to.* Whether that warrants the Shea attribution stays the interpretation decision recorded in v2.1 §0. If the decision is negative, this functional finding is the result.

## 4. Block design

| Decision | Status |
|---|---|
| \(B = B_{\text{trace}} + B_{\text{score}}\); \(k = B_{\text{trace}}/4\) under balanced allocation | adopted as the definition |
| Equal allocation across the four inputs, randomized order (random allocation as a secondary robustness arm) | **recommended for freezing, pending Ben's approval** |
| Separate inference and scoring phases; no updating from scored trials | **recommended for freezing, pending Ben's approval** |
| Numerical \(B\) (hence \(k\)) | **unresolved; not to be invented.** Margins wait on it |

## 5. Revised MB0 order

1. Adopt R2.4 provisionally in place of R2.3. Register B1-accept-value, B1-invert-value and B1-action-vector as rivals, with their exact bounds (§2).
2. Re-derive the acceptance-consumer references under R2.4 (the R2.3 references in §1 do not carry over).
3. Register the D11 caliper rule. Report empirical eligibility separately from population ambiguity mass.
4. Add the joint-MAP estimator (Ledger D §4).
5. Fix \(B_{\text{trace}}\), then \(k\), then margins.
6. Record the §3 identification limit in the interpretation register before any S1h result is read.
