## X1 RR1c identification under admissible frozen consumers

| witness | some admissible consumer retains the post-rewire optimum (all subproblems) | some admissible consumer loses value | RR1c status |
|---|---|---|---|
| W1 regime code (theta-coupled) | True | True | NOT IDENTIFIED (depends on which admissible consumer is frozen) |
| W2 input parity (fixed) | False | True | robust fail |
| W5 token-phi monitor | True | True | NOT IDENTIFIED (depends on which admissible consumer is frozen) |
| W7 bundle W1+W3+W5 | True | True | NOT IDENTIFIED (depends on which admissible consumer is frozen) |
| B1-scalar reliability q_T | True | True | NOT IDENTIFIED (depends on which admissible consumer is frozen) |

## X2 P1b against the normalised held-out Bayes bound (k = 5)

| witness | held-out accuracy | held-out structured Bayes | original criterion (> 1/2) | exact-scope criterion (attains bound) |
|---|---|---|---|---|
| W1 regime code (theta-coupled) | 0.500000 | 0.596178 | fail | fail |
| W2 input parity (fixed) | 0.500000 | 0.596178 | fail | fail |
| W3 process model (truth table) | 0.596178 | 0.596178 | pass | pass |
| W5 token-phi monitor | 0.517643 | 0.596178 | pass | fail |
| W6a per-cell tracker | 0.518517 | 0.596178 | pass | fail |
| W6b identity classifier | 0.463034 | 0.596178 | fail | fail |
| W7 bundle W1+W3+W5 | 0.596178 | 0.596178 | pass | pass |
| B1-scalar reliability q_T | 0.500000 | 0.596178 | fail | fail |
