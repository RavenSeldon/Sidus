linear least-squares action-value consumer, raw (R,Z1,Z2): greedy value 0.733000
linear least-squares action-value consumer, with parity M: greedy value 0.825000
