family 6 maps (v2.1)  k=5: structured Bayes 0.5968 | per-cell bits: best LINEAR readout 0.5929, best UNRESTRICTED readout 0.5929
family 6 maps (v2.1)  k=20: structured Bayes 0.7021 | per-cell bits: best LINEAR readout 0.6941, best UNRESTRICTED readout 0.6941
   inversion rate per mapping (reliability matching requires all equal): [0.5, 0.5, 0.5, 0.5, 0.5, 0.5]
family 8 maps (with constants)  k=5: structured Bayes 0.5174 | per-cell bits: best LINEAR readout 0.5095, best UNRESTRICTED readout 0.5174
family 8 maps (with constants)  k=20: structured Bayes 0.5959 | per-cell bits: best LINEAR readout 0.5486, best UNRESTRICTED readout 0.5957
   inversion rate per mapping (reliability matching requires all equal): [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.0, 1.0]
