"""Read-only F1 binding check. Never trains, starts, or adjudicates a run."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', required=True)
    parser.add_argument('--trusted-freeze-sha256', required=True)
    args = parser.parse_args()
    packet = Path(__file__).resolve().parent
    receipt_path = packet / 'FREEZE_RECEIPT.json'
    actual_hash = hashlib.sha256(receipt_path.read_bytes()).hexdigest()
    if actual_hash != args.trusted_freeze_sha256:
        raise ValueError('Receipt differs from independently retained trusted digest')
    root = Path(args.build).resolve()
    sys.path.insert(0, str(root))
    from confirmation import ROOT
    from confirmation.contract import validate, hash_json, source_identity, portable_manifest_errors
    from runbook_reference.reference.integrity import verify_release, strict_json, digest
    if ROOT != root:
        raise ValueError('Imported a different build')
    errors = verify_release(root)
    errors += portable_manifest_errors(
        {'path': 'EXECUTABLE_MANIFEST.json', 'sha256': digest(root / 'EXECUTABLE_MANIFEST.json')}, root)
    if errors:
        raise ValueError(str(errors))
    cfg = validate(strict_json((packet / 'FROZEN_CONFIG.json').read_text()))
    receipt = strict_json(receipt_path.read_text())
    if set(receipt) != {'schema', 'config_sha256', 'source', 'created_utc'}:
        raise ValueError('Unexpected receipt fields')
    if receipt['schema'] != 'sidus-confirmation-freeze-v1':
        raise ValueError('Unexpected receipt schema')
    if cfg['phase'] != 'frozen_confirmation' or len(cfg['seeds']) != 500:
        raise ValueError('F1 requires the frozen 500-seed configuration')
    if receipt['config_sha256'] != hash_json(cfg) or receipt['source'] != source_identity():
        raise ValueError('Receipt does not bind this configuration and build')
    created = datetime.fromisoformat(receipt['created_utc'])
    if created.tzinfo is None or created > datetime.now(timezone.utc):
        raise ValueError('Invalid or future freeze time')
    archive = packet / 'Sidus_E0_Experiment_v0.7.zip'
    if digest(archive) != 'd26a3fbeff7fbbd8dfdf2ba878fdb3dcc1bec37f0dffc2212e4637b878d93bed':
        raise ValueError('Reviewed v0.7 archive differs')
    print(json.dumps({'freeze_binding_valid': True, 'seed_count': 500,
                      'training_executed_by_preflight': False,
                      'scientific_license': False, 'freeze_sha256': actual_hash}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError, TypeError, ImportError) as exc:
        print(json.dumps({'freeze_binding_valid': False, 'error': str(exc)}))
        raise SystemExit(2)
